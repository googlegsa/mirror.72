/* listing.h   header file for listing.c
 *
 * The Netwide Assembler is copyright (C) 1996 Simon Tatham and
 * Julian Hall. All rights reserved. The software is
 * redistributable under the license given in the file "LICENSE"
 * distributed in the NASM archive.
 */

#ifndef NASM_LISTING_H
#define NASM_LISTING_H

extern ListGen nasmlist;
extern int user_nolist;         /* fbk - 9/1/00 */

#endif
