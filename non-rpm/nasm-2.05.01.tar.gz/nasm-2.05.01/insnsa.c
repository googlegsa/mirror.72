/* This file auto-generated from insns.dat by insns.pl - don't edit it */

#include "nasm.h"
#include "insns.h"

static const struct itemplate instrux_AAA[] = {
    {I_AAA, 0, {0,0,0,0,0}, nasm_bytecodes+19631, IF_8086|IF_NOLONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_AAD[] = {
    {I_AAD, 0, {0,0,0,0,0}, nasm_bytecodes+18547, IF_8086|IF_NOLONG},
    {I_AAD, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+18551, IF_8086|IF_SB|IF_NOLONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_AAM[] = {
    {I_AAM, 0, {0,0,0,0,0}, nasm_bytecodes+18555, IF_8086|IF_NOLONG},
    {I_AAM, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+18559, IF_8086|IF_SB|IF_NOLONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_AAS[] = {
    {I_AAS, 0, {0,0,0,0,0}, nasm_bytecodes+19634, IF_8086|IF_NOLONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_ADC[] = {
    {I_ADC, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+18563, IF_8086|IF_SM},
    {I_ADC, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+18563, IF_8086},
    {I_ADC, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+16672, IF_8086|IF_SM},
    {I_ADC, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+16672, IF_8086},
    {I_ADC, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+16677, IF_386|IF_SM},
    {I_ADC, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+16677, IF_386},
    {I_ADC, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+16682, IF_X64|IF_SM},
    {I_ADC, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+16682, IF_X64},
    {I_ADC, 2, {REG8,MEMORY,0,0,0}, nasm_bytecodes+11174, IF_8086|IF_SM},
    {I_ADC, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+11174, IF_8086},
    {I_ADC, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+16687, IF_8086|IF_SM},
    {I_ADC, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+16687, IF_8086},
    {I_ADC, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+16692, IF_386|IF_SM},
    {I_ADC, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+16692, IF_386},
    {I_ADC, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+16697, IF_X64|IF_SM},
    {I_ADC, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+16697, IF_X64},
    {I_ADC, 2, {RM_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13138, IF_8086},
    {I_ADC, 2, {RM_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13144, IF_386},
    {I_ADC, 2, {RM_GPR|BITS64,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13150, IF_X64},
    {I_ADC, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+18567, IF_8086|IF_SM},
    {I_ADC, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+16702, IF_8086|IF_SM},
    {I_ADC, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+16707, IF_386|IF_SM},
    {I_ADC, 2, {REG_RAX,IMMEDIATE,0,0,0}, nasm_bytecodes+16712, IF_X64|IF_SM},
    {I_ADC, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+16717, IF_8086|IF_SM},
    {I_ADC, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+13156, IF_8086|IF_SM},
    {I_ADC, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+13162, IF_386|IF_SM},
    {I_ADC, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+13168, IF_X64|IF_SM},
    {I_ADC, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+16717, IF_8086|IF_SM},
    {I_ADC, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+13156, IF_8086|IF_SM},
    {I_ADC, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+13162, IF_386|IF_SM},
    ITEMPLATE_END
};

static const struct itemplate instrux_ADD[] = {
    {I_ADD, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+18571, IF_8086|IF_SM},
    {I_ADD, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+18571, IF_8086},
    {I_ADD, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+16722, IF_8086|IF_SM},
    {I_ADD, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+16722, IF_8086},
    {I_ADD, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+16727, IF_386|IF_SM},
    {I_ADD, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+16727, IF_386},
    {I_ADD, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+16732, IF_X64|IF_SM},
    {I_ADD, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+16732, IF_X64},
    {I_ADD, 2, {REG8,MEMORY,0,0,0}, nasm_bytecodes+11825, IF_8086|IF_SM},
    {I_ADD, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+11825, IF_8086},
    {I_ADD, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+16737, IF_8086|IF_SM},
    {I_ADD, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+16737, IF_8086},
    {I_ADD, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+16742, IF_386|IF_SM},
    {I_ADD, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+16742, IF_386},
    {I_ADD, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+16747, IF_X64|IF_SM},
    {I_ADD, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+16747, IF_X64},
    {I_ADD, 2, {RM_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13174, IF_8086},
    {I_ADD, 2, {RM_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13180, IF_386},
    {I_ADD, 2, {RM_GPR|BITS64,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13186, IF_X64},
    {I_ADD, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+18575, IF_8086|IF_SM},
    {I_ADD, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+16752, IF_8086|IF_SM},
    {I_ADD, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+16757, IF_386|IF_SM},
    {I_ADD, 2, {REG_RAX,IMMEDIATE,0,0,0}, nasm_bytecodes+16762, IF_X64|IF_SM},
    {I_ADD, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+16767, IF_8086|IF_SM},
    {I_ADD, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+13192, IF_8086|IF_SM},
    {I_ADD, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+13198, IF_386|IF_SM},
    {I_ADD, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+13204, IF_X64|IF_SM},
    {I_ADD, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+16767, IF_8086|IF_SM},
    {I_ADD, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+13192, IF_8086|IF_SM},
    {I_ADD, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+13198, IF_386|IF_SM},
    ITEMPLATE_END
};

static const struct itemplate instrux_ADDPD[] = {
    {I_ADDPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15088, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_ADDPS[] = {
    {I_ADDPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14368, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_ADDSD[] = {
    {I_ADDSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15094, IF_WILLAMETTE|IF_SSE2|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_ADDSS[] = {
    {I_ADDSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14374, IF_KATMAI|IF_SSE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_ADDSUBPD[] = {
    {I_ADDSUBPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15382, IF_PRESCOTT|IF_SSE3|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_ADDSUBPS[] = {
    {I_ADDSUBPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15388, IF_PRESCOTT|IF_SSE3|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_AESDEC[] = {
    {I_AESDEC, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9673, IF_WESTMERE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_AESDECLAST[] = {
    {I_AESDECLAST, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9680, IF_WESTMERE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_AESENC[] = {
    {I_AESENC, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9659, IF_WESTMERE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_AESENCLAST[] = {
    {I_AESENCLAST, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9666, IF_WESTMERE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_AESIMC[] = {
    {I_AESIMC, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9687, IF_WESTMERE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_AESKEYGENASSIST[] = {
    {I_AESKEYGENASSIST, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6422, IF_WESTMERE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_AND[] = {
    {I_AND, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+18579, IF_8086|IF_SM},
    {I_AND, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+18579, IF_8086},
    {I_AND, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+16772, IF_8086|IF_SM},
    {I_AND, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+16772, IF_8086},
    {I_AND, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+16777, IF_386|IF_SM},
    {I_AND, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+16777, IF_386},
    {I_AND, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+16782, IF_X64|IF_SM},
    {I_AND, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+16782, IF_X64},
    {I_AND, 2, {REG8,MEMORY,0,0,0}, nasm_bytecodes+12112, IF_8086|IF_SM},
    {I_AND, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+12112, IF_8086},
    {I_AND, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+16787, IF_8086|IF_SM},
    {I_AND, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+16787, IF_8086},
    {I_AND, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+16792, IF_386|IF_SM},
    {I_AND, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+16792, IF_386},
    {I_AND, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+16797, IF_X64|IF_SM},
    {I_AND, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+16797, IF_X64},
    {I_AND, 2, {RM_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13210, IF_8086},
    {I_AND, 2, {RM_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13216, IF_386},
    {I_AND, 2, {RM_GPR|BITS64,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13222, IF_X64},
    {I_AND, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+18583, IF_8086|IF_SM},
    {I_AND, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+16802, IF_8086|IF_SM},
    {I_AND, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+16807, IF_386|IF_SM},
    {I_AND, 2, {REG_RAX,IMMEDIATE,0,0,0}, nasm_bytecodes+16812, IF_X64|IF_SM},
    {I_AND, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+16817, IF_8086|IF_SM},
    {I_AND, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+13228, IF_8086|IF_SM},
    {I_AND, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+13234, IF_386|IF_SM},
    {I_AND, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+13240, IF_X64|IF_SM},
    {I_AND, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+16817, IF_8086|IF_SM},
    {I_AND, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+13228, IF_8086|IF_SM},
    {I_AND, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+13234, IF_386|IF_SM},
    ITEMPLATE_END
};

static const struct itemplate instrux_ANDNPD[] = {
    {I_ANDNPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15100, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_ANDNPS[] = {
    {I_ANDNPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14380, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_ANDPD[] = {
    {I_ANDPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15106, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_ANDPS[] = {
    {I_ANDPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14386, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_ARPL[] = {
    {I_ARPL, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+18587, IF_286|IF_PROT|IF_SM|IF_NOLONG},
    {I_ARPL, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+18587, IF_286|IF_PROT|IF_NOLONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_BB0_RESET[] = {
    {I_BB0_RESET, 0, {0,0,0,0,0}, nasm_bytecodes+18591, IF_PENT|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_BB1_RESET[] = {
    {I_BB1_RESET, 0, {0,0,0,0,0}, nasm_bytecodes+18595, IF_PENT|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_BLENDPD[] = {
    {I_BLENDPD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6110, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_BLENDPS[] = {
    {I_BLENDPS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6118, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_BLENDVPD[] = {
    {I_BLENDVPD, 3, {XMMREG,RM_XMM,XMM0,0,0}, nasm_bytecodes+8420, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_BLENDVPS[] = {
    {I_BLENDVPS, 3, {XMMREG,RM_XMM,XMM0,0,0}, nasm_bytecodes+8427, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_BOUND[] = {
    {I_BOUND, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+16822, IF_186|IF_NOLONG},
    {I_BOUND, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+16827, IF_386|IF_NOLONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_BSF[] = {
    {I_BSF, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+13246, IF_386|IF_SM},
    {I_BSF, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+13246, IF_386},
    {I_BSF, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+13252, IF_386|IF_SM},
    {I_BSF, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+13252, IF_386},
    {I_BSF, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+13258, IF_X64|IF_SM},
    {I_BSF, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+13258, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_BSR[] = {
    {I_BSR, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+13264, IF_386|IF_SM},
    {I_BSR, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+13264, IF_386},
    {I_BSR, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+13270, IF_386|IF_SM},
    {I_BSR, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+13270, IF_386},
    {I_BSR, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+13276, IF_X64|IF_SM},
    {I_BSR, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+13276, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_BSWAP[] = {
    {I_BSWAP, 1, {REG32,0,0,0,0}, nasm_bytecodes+13282, IF_486},
    {I_BSWAP, 1, {REG64,0,0,0,0}, nasm_bytecodes+13288, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_BT[] = {
    {I_BT, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+13294, IF_386|IF_SM},
    {I_BT, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+13294, IF_386},
    {I_BT, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+13300, IF_386|IF_SM},
    {I_BT, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+13300, IF_386},
    {I_BT, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+13306, IF_X64|IF_SM},
    {I_BT, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+13306, IF_X64},
    {I_BT, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+7230, IF_386|IF_SB},
    {I_BT, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+7237, IF_386|IF_SB},
    {I_BT, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+7244, IF_X64|IF_SB},
    ITEMPLATE_END
};

static const struct itemplate instrux_BTC[] = {
    {I_BTC, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+13312, IF_386|IF_SM},
    {I_BTC, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+13312, IF_386},
    {I_BTC, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+13318, IF_386|IF_SM},
    {I_BTC, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+13318, IF_386},
    {I_BTC, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+13324, IF_X64|IF_SM},
    {I_BTC, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+13324, IF_X64},
    {I_BTC, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+7251, IF_386|IF_SB},
    {I_BTC, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+7258, IF_386|IF_SB},
    {I_BTC, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+7265, IF_X64|IF_SB},
    ITEMPLATE_END
};

static const struct itemplate instrux_BTR[] = {
    {I_BTR, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+13330, IF_386|IF_SM},
    {I_BTR, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+13330, IF_386},
    {I_BTR, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+13336, IF_386|IF_SM},
    {I_BTR, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+13336, IF_386},
    {I_BTR, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+13342, IF_X64|IF_SM},
    {I_BTR, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+13342, IF_X64},
    {I_BTR, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+7272, IF_386|IF_SB},
    {I_BTR, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+7279, IF_386|IF_SB},
    {I_BTR, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+7286, IF_X64|IF_SB},
    ITEMPLATE_END
};

static const struct itemplate instrux_BTS[] = {
    {I_BTS, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+13348, IF_386|IF_SM},
    {I_BTS, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+13348, IF_386},
    {I_BTS, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+13354, IF_386|IF_SM},
    {I_BTS, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+13354, IF_386},
    {I_BTS, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+13360, IF_X64|IF_SM},
    {I_BTS, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+13360, IF_X64},
    {I_BTS, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+7293, IF_386|IF_SB},
    {I_BTS, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+7300, IF_386|IF_SB},
    {I_BTS, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+7307, IF_X64|IF_SB},
    ITEMPLATE_END
};

static const struct itemplate instrux_CALL[] = {
    {I_CALL, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+16832, IF_8086},
    {I_CALL, 1, {IMMEDIATE|NEAR,0,0,0,0}, nasm_bytecodes+16832, IF_8086},
    {I_CALL, 1, {IMMEDIATE|FAR,0,0,0,0}, nasm_bytecodes+13366, IF_8086|IF_NOLONG},
    {I_CALL, 1, {IMMEDIATE|BITS16,0,0,0,0}, nasm_bytecodes+16837, IF_8086},
    {I_CALL, 1, {IMMEDIATE|BITS16|NEAR,0,0,0,0}, nasm_bytecodes+16837, IF_8086},
    {I_CALL, 1, {IMMEDIATE|BITS16|FAR,0,0,0,0}, nasm_bytecodes+13372, IF_8086|IF_NOLONG},
    {I_CALL, 1, {IMMEDIATE|BITS32,0,0,0,0}, nasm_bytecodes+16842, IF_386},
    {I_CALL, 1, {IMMEDIATE|BITS32|NEAR,0,0,0,0}, nasm_bytecodes+16842, IF_386},
    {I_CALL, 1, {IMMEDIATE|BITS32|FAR,0,0,0,0}, nasm_bytecodes+13378, IF_386|IF_NOLONG},
    {I_CALL, 2, {IMMEDIATE|COLON,IMMEDIATE,0,0,0}, nasm_bytecodes+13384, IF_8086|IF_NOLONG},
    {I_CALL, 2, {IMMEDIATE|BITS16|COLON,IMMEDIATE,0,0,0}, nasm_bytecodes+13390, IF_8086|IF_NOLONG},
    {I_CALL, 2, {IMMEDIATE|COLON,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+13390, IF_8086|IF_NOLONG},
    {I_CALL, 2, {IMMEDIATE|BITS32|COLON,IMMEDIATE,0,0,0}, nasm_bytecodes+13396, IF_386|IF_NOLONG},
    {I_CALL, 2, {IMMEDIATE|COLON,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+13396, IF_386|IF_NOLONG},
    {I_CALL, 1, {MEMORY|FAR,0,0,0,0}, nasm_bytecodes+16847, IF_8086|IF_NOLONG},
    {I_CALL, 1, {MEMORY|FAR,0,0,0,0}, nasm_bytecodes+16852, IF_X64},
    {I_CALL, 1, {MEMORY|BITS16|FAR,0,0,0,0}, nasm_bytecodes+16857, IF_8086},
    {I_CALL, 1, {MEMORY|BITS32|FAR,0,0,0,0}, nasm_bytecodes+16862, IF_386},
    {I_CALL, 1, {MEMORY|BITS64|FAR,0,0,0,0}, nasm_bytecodes+16852, IF_X64},
    {I_CALL, 1, {MEMORY|NEAR,0,0,0,0}, nasm_bytecodes+16867, IF_8086},
    {I_CALL, 1, {MEMORY|BITS16|NEAR,0,0,0,0}, nasm_bytecodes+16872, IF_8086},
    {I_CALL, 1, {MEMORY|BITS32|NEAR,0,0,0,0}, nasm_bytecodes+16877, IF_386|IF_NOLONG},
    {I_CALL, 1, {MEMORY|BITS64|NEAR,0,0,0,0}, nasm_bytecodes+16882, IF_X64},
    {I_CALL, 1, {REG16,0,0,0,0}, nasm_bytecodes+16872, IF_8086},
    {I_CALL, 1, {REG32,0,0,0,0}, nasm_bytecodes+16877, IF_386|IF_NOLONG},
    {I_CALL, 1, {REG64,0,0,0,0}, nasm_bytecodes+16887, IF_X64},
    {I_CALL, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+16867, IF_8086},
    {I_CALL, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+16872, IF_8086},
    {I_CALL, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+16877, IF_386|IF_NOLONG},
    {I_CALL, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+16887, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_CBW[] = {
    {I_CBW, 0, {0,0,0,0,0}, nasm_bytecodes+18599, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_CDQ[] = {
    {I_CDQ, 0, {0,0,0,0,0}, nasm_bytecodes+18603, IF_386},
    ITEMPLATE_END
};

static const struct itemplate instrux_CDQE[] = {
    {I_CDQE, 0, {0,0,0,0,0}, nasm_bytecodes+18607, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_CLC[] = {
    {I_CLC, 0, {0,0,0,0,0}, nasm_bytecodes+18319, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_CLD[] = {
    {I_CLD, 0, {0,0,0,0,0}, nasm_bytecodes+19637, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_CLFLUSH[] = {
    {I_CLFLUSH, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18492, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_CLGI[] = {
    {I_CLGI, 0, {0,0,0,0,0}, nasm_bytecodes+16892, IF_X64|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_CLI[] = {
    {I_CLI, 0, {0,0,0,0,0}, nasm_bytecodes+19640, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_CLTS[] = {
    {I_CLTS, 0, {0,0,0,0,0}, nasm_bytecodes+18611, IF_286|IF_PRIV},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMC[] = {
    {I_CMC, 0, {0,0,0,0,0}, nasm_bytecodes+19643, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMP[] = {
    {I_CMP, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+18615, IF_8086|IF_SM},
    {I_CMP, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+18615, IF_8086},
    {I_CMP, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+16897, IF_8086|IF_SM},
    {I_CMP, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+16897, IF_8086},
    {I_CMP, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+16902, IF_386|IF_SM},
    {I_CMP, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+16902, IF_386},
    {I_CMP, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+16907, IF_X64|IF_SM},
    {I_CMP, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+16907, IF_X64},
    {I_CMP, 2, {REG8,MEMORY,0,0,0}, nasm_bytecodes+12070, IF_8086|IF_SM},
    {I_CMP, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+12070, IF_8086},
    {I_CMP, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+16912, IF_8086|IF_SM},
    {I_CMP, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+16912, IF_8086},
    {I_CMP, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+16917, IF_386|IF_SM},
    {I_CMP, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+16917, IF_386},
    {I_CMP, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+16922, IF_X64|IF_SM},
    {I_CMP, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+16922, IF_X64},
    {I_CMP, 2, {RM_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13402, IF_8086},
    {I_CMP, 2, {RM_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13408, IF_386},
    {I_CMP, 2, {RM_GPR|BITS64,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13414, IF_X64},
    {I_CMP, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+18619, IF_8086|IF_SM},
    {I_CMP, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+16927, IF_8086|IF_SM},
    {I_CMP, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+16932, IF_386|IF_SM},
    {I_CMP, 2, {REG_RAX,IMMEDIATE,0,0,0}, nasm_bytecodes+16937, IF_X64|IF_SM},
    {I_CMP, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+16942, IF_8086|IF_SM},
    {I_CMP, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+13420, IF_8086|IF_SM},
    {I_CMP, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+13426, IF_386|IF_SM},
    {I_CMP, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+13432, IF_X64|IF_SM},
    {I_CMP, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+16942, IF_8086|IF_SM},
    {I_CMP, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+13420, IF_8086|IF_SM},
    {I_CMP, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+13426, IF_386|IF_SM},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPEQPD[] = {
    {I_CMPEQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5934, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPEQPS[] = {
    {I_CMPEQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5750, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPEQSD[] = {
    {I_CMPEQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5942, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPEQSS[] = {
    {I_CMPEQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5758, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPLEPD[] = {
    {I_CMPLEPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5950, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPLEPS[] = {
    {I_CMPLEPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5766, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPLESD[] = {
    {I_CMPLESD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5958, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPLESS[] = {
    {I_CMPLESS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5774, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPLTPD[] = {
    {I_CMPLTPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5966, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPLTPS[] = {
    {I_CMPLTPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5782, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPLTSD[] = {
    {I_CMPLTSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5974, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPLTSS[] = {
    {I_CMPLTSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5790, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPNEQPD[] = {
    {I_CMPNEQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5982, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPNEQPS[] = {
    {I_CMPNEQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5798, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPNEQSD[] = {
    {I_CMPNEQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5990, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPNEQSS[] = {
    {I_CMPNEQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5806, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPNLEPD[] = {
    {I_CMPNLEPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5998, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPNLEPS[] = {
    {I_CMPNLEPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5814, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPNLESD[] = {
    {I_CMPNLESD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+6006, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPNLESS[] = {
    {I_CMPNLESS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5822, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPNLTPD[] = {
    {I_CMPNLTPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+6014, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPNLTPS[] = {
    {I_CMPNLTPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5830, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPNLTSD[] = {
    {I_CMPNLTSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+6022, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPNLTSS[] = {
    {I_CMPNLTSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5838, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPORDPD[] = {
    {I_CMPORDPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+6030, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPORDPS[] = {
    {I_CMPORDPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5846, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPORDSD[] = {
    {I_CMPORDSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+6038, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPORDSS[] = {
    {I_CMPORDSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5854, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPPD[] = {
    {I_CMPPD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+8126, IF_WILLAMETTE|IF_SSE2|IF_SM2|IF_SB|IF_AR2},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPPS[] = {
    {I_CMPPS, 3, {XMMREG,MEMORY,IMMEDIATE,0,0}, nasm_bytecodes+7860, IF_KATMAI|IF_SSE|IF_SB|IF_AR2},
    {I_CMPPS, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+7860, IF_KATMAI|IF_SSE|IF_SB|IF_AR2},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPSB[] = {
    {I_CMPSB, 0, {0,0,0,0,0}, nasm_bytecodes+18623, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPSD[] = {
    {I_CMPSD, 0, {0,0,0,0,0}, nasm_bytecodes+16947, IF_386},
    {I_CMPSD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+8133, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR2},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPSQ[] = {
    {I_CMPSQ, 0, {0,0,0,0,0}, nasm_bytecodes+16952, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPSS[] = {
    {I_CMPSS, 3, {XMMREG,MEMORY,IMMEDIATE,0,0}, nasm_bytecodes+7867, IF_KATMAI|IF_SSE|IF_SB|IF_AR2},
    {I_CMPSS, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+7867, IF_KATMAI|IF_SSE|IF_SB|IF_AR2},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPSW[] = {
    {I_CMPSW, 0, {0,0,0,0,0}, nasm_bytecodes+16957, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPUNORDPD[] = {
    {I_CMPUNORDPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+6046, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPUNORDPS[] = {
    {I_CMPUNORDPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5862, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPUNORDSD[] = {
    {I_CMPUNORDSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+6054, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPUNORDSS[] = {
    {I_CMPUNORDSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5870, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPXCHG[] = {
    {I_CMPXCHG, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+16962, IF_PENT|IF_SM},
    {I_CMPXCHG, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+16962, IF_PENT},
    {I_CMPXCHG, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+13438, IF_PENT|IF_SM},
    {I_CMPXCHG, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+13438, IF_PENT},
    {I_CMPXCHG, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+13444, IF_PENT|IF_SM},
    {I_CMPXCHG, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+13444, IF_PENT},
    {I_CMPXCHG, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+13450, IF_X64|IF_SM},
    {I_CMPXCHG, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+13450, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPXCHG16B[] = {
    {I_CMPXCHG16B, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+13468, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPXCHG486[] = {
    {I_CMPXCHG486, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+16967, IF_486|IF_SM|IF_UNDOC},
    {I_CMPXCHG486, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+16967, IF_486|IF_UNDOC},
    {I_CMPXCHG486, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+13456, IF_486|IF_SM|IF_UNDOC},
    {I_CMPXCHG486, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+13456, IF_486|IF_UNDOC},
    {I_CMPXCHG486, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+13462, IF_486|IF_SM|IF_UNDOC},
    {I_CMPXCHG486, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+13462, IF_486|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMPXCHG8B[] = {
    {I_CMPXCHG8B, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+13469, IF_PENT},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMEQPD[] = {
    {I_COMEQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+180, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMEQPS[] = {
    {I_COMEQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+36, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMEQSD[] = {
    {I_COMEQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+468, IF_SSE5|IF_AMD|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMEQSS[] = {
    {I_COMEQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+324, IF_SSE5|IF_AMD|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMFALSEPD[] = {
    {I_COMFALSEPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+279, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMFALSEPS[] = {
    {I_COMFALSEPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+135, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMFALSESD[] = {
    {I_COMFALSESD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+567, IF_SSE5|IF_AMD|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMFALSESS[] = {
    {I_COMFALSESS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+423, IF_SSE5|IF_AMD|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMISD[] = {
    {I_COMISD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15112, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMISS[] = {
    {I_COMISS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14392, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMLEPD[] = {
    {I_COMLEPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+198, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMLEPS[] = {
    {I_COMLEPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+54, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMLESD[] = {
    {I_COMLESD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+486, IF_SSE5|IF_AMD|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMLESS[] = {
    {I_COMLESS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+342, IF_SSE5|IF_AMD|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMLTPD[] = {
    {I_COMLTPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+189, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMLTPS[] = {
    {I_COMLTPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+45, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMLTSD[] = {
    {I_COMLTSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+477, IF_SSE5|IF_AMD|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMLTSS[] = {
    {I_COMLTSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+333, IF_SSE5|IF_AMD|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMNEQPD[] = {
    {I_COMNEQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+288, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMNEQPS[] = {
    {I_COMNEQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+144, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMNEQSD[] = {
    {I_COMNEQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+576, IF_SSE5|IF_AMD|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMNEQSS[] = {
    {I_COMNEQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+432, IF_SSE5|IF_AMD|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMNLEPD[] = {
    {I_COMNLEPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+306, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMNLEPS[] = {
    {I_COMNLEPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+162, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMNLESD[] = {
    {I_COMNLESD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+594, IF_SSE5|IF_AMD|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMNLESS[] = {
    {I_COMNLESS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+450, IF_SSE5|IF_AMD|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMNLTPD[] = {
    {I_COMNLTPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+297, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMNLTPS[] = {
    {I_COMNLTPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+153, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMNLTSD[] = {
    {I_COMNLTSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+585, IF_SSE5|IF_AMD|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMNLTSS[] = {
    {I_COMNLTSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+441, IF_SSE5|IF_AMD|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMORDPD[] = {
    {I_COMORDPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+243, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMORDPS[] = {
    {I_COMORDPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+99, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMORDSD[] = {
    {I_COMORDSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+531, IF_SSE5|IF_AMD|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMORDSS[] = {
    {I_COMORDSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+387, IF_SSE5|IF_AMD|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMPD[] = {
    {I_COMPD, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6286, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMPS[] = {
    {I_COMPS, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6278, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMSD[] = {
    {I_COMSD, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6302, IF_SSE5|IF_AMD|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMSS[] = {
    {I_COMSS, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6294, IF_SSE5|IF_AMD|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMTRUEPD[] = {
    {I_COMTRUEPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+315, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMTRUEPS[] = {
    {I_COMTRUEPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+171, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMTRUESD[] = {
    {I_COMTRUESD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+603, IF_SSE5|IF_AMD|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMTRUESS[] = {
    {I_COMTRUESS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+459, IF_SSE5|IF_AMD|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMUEQPD[] = {
    {I_COMUEQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+252, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMUEQPS[] = {
    {I_COMUEQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+108, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMUEQSD[] = {
    {I_COMUEQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+540, IF_SSE5|IF_AMD|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMUEQSS[] = {
    {I_COMUEQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+396, IF_SSE5|IF_AMD|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMULEPD[] = {
    {I_COMULEPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+270, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMULEPS[] = {
    {I_COMULEPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+126, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMULESD[] = {
    {I_COMULESD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+558, IF_SSE5|IF_AMD|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMULESS[] = {
    {I_COMULESS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+414, IF_SSE5|IF_AMD|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMULTPD[] = {
    {I_COMULTPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+261, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMULTPS[] = {
    {I_COMULTPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+117, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMULTSD[] = {
    {I_COMULTSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+549, IF_SSE5|IF_AMD|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMULTSS[] = {
    {I_COMULTSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+405, IF_SSE5|IF_AMD|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMUNEQPD[] = {
    {I_COMUNEQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+216, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMUNEQPS[] = {
    {I_COMUNEQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+72, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMUNEQSD[] = {
    {I_COMUNEQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+504, IF_SSE5|IF_AMD|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMUNEQSS[] = {
    {I_COMUNEQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+360, IF_SSE5|IF_AMD|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMUNLEPD[] = {
    {I_COMUNLEPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+234, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMUNLEPS[] = {
    {I_COMUNLEPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+90, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMUNLESD[] = {
    {I_COMUNLESD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+522, IF_SSE5|IF_AMD|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMUNLESS[] = {
    {I_COMUNLESS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+378, IF_SSE5|IF_AMD|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMUNLTPD[] = {
    {I_COMUNLTPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+225, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMUNLTPS[] = {
    {I_COMUNLTPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+81, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMUNLTSD[] = {
    {I_COMUNLTSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+513, IF_SSE5|IF_AMD|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMUNLTSS[] = {
    {I_COMUNLTSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+369, IF_SSE5|IF_AMD|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMUNORDPD[] = {
    {I_COMUNORDPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+207, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMUNORDPS[] = {
    {I_COMUNORDPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+63, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMUNORDSD[] = {
    {I_COMUNORDSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+495, IF_SSE5|IF_AMD|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_COMUNORDSS[] = {
    {I_COMUNORDSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+351, IF_SSE5|IF_AMD|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_CPUID[] = {
    {I_CPUID, 0, {0,0,0,0,0}, nasm_bytecodes+18627, IF_PENT},
    ITEMPLATE_END
};

static const struct itemplate instrux_CPU_READ[] = {
    {I_CPU_READ, 0, {0,0,0,0,0}, nasm_bytecodes+18631, IF_PENT|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_CPU_WRITE[] = {
    {I_CPU_WRITE, 0, {0,0,0,0,0}, nasm_bytecodes+18635, IF_PENT|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_CQO[] = {
    {I_CQO, 0, {0,0,0,0,0}, nasm_bytecodes+18639, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_CRC32[] = {
    {I_CRC32, 2, {REG32,RM_GPR|BITS8,0,0,0}, nasm_bytecodes+6231, IF_SSE42},
    {I_CRC32, 2, {REG32,RM_GPR|BITS16,0,0,0}, nasm_bytecodes+6214, IF_SSE42},
    {I_CRC32, 2, {REG32,RM_GPR|BITS32,0,0,0}, nasm_bytecodes+6222, IF_SSE42},
    {I_CRC32, 2, {REG64,RM_GPR|BITS8,0,0,0}, nasm_bytecodes+6230, IF_SSE42|IF_X64},
    {I_CRC32, 2, {REG64,RM_GPR|BITS64,0,0,0}, nasm_bytecodes+6238, IF_SSE42|IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_CVTDQ2PD[] = {
    {I_CVTDQ2PD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15118, IF_WILLAMETTE|IF_SSE2|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_CVTDQ2PS[] = {
    {I_CVTDQ2PS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15124, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_CVTPD2DQ[] = {
    {I_CVTPD2DQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15130, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_CVTPD2PI[] = {
    {I_CVTPD2PI, 2, {MMXREG,RM_XMM,0,0,0}, nasm_bytecodes+15136, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_CVTPD2PS[] = {
    {I_CVTPD2PS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15142, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_CVTPH2PS[] = {
    {I_CVTPH2PS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9498, IF_SSE5|IF_AMD|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_CVTPI2PD[] = {
    {I_CVTPI2PD, 2, {XMMREG,RM_MMX,0,0,0}, nasm_bytecodes+15148, IF_WILLAMETTE|IF_SSE2|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_CVTPI2PS[] = {
    {I_CVTPI2PS, 2, {XMMREG,RM_MMX,0,0,0}, nasm_bytecodes+14398, IF_KATMAI|IF_SSE|IF_MMX|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_CVTPS2DQ[] = {
    {I_CVTPS2DQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15154, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_CVTPS2PD[] = {
    {I_CVTPS2PD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15160, IF_WILLAMETTE|IF_SSE2|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_CVTPS2PH[] = {
    {I_CVTPS2PH, 2, {RM_XMM,XMMREG,0,0,0}, nasm_bytecodes+9505, IF_SSE5|IF_AMD|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_CVTPS2PI[] = {
    {I_CVTPS2PI, 2, {MMXREG,RM_XMM,0,0,0}, nasm_bytecodes+14404, IF_KATMAI|IF_SSE|IF_MMX|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_CVTSD2SI[] = {
    {I_CVTSD2SI, 2, {REG32,XMMREG,0,0,0}, nasm_bytecodes+8141, IF_WILLAMETTE|IF_SSE2|IF_SQ|IF_AR1},
    {I_CVTSD2SI, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+8141, IF_WILLAMETTE|IF_SSE2|IF_SQ|IF_AR1},
    {I_CVTSD2SI, 2, {REG64,XMMREG,0,0,0}, nasm_bytecodes+8140, IF_X64|IF_SSE2|IF_SQ|IF_AR1},
    {I_CVTSD2SI, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+8140, IF_X64|IF_SSE2|IF_SQ|IF_AR1},
    ITEMPLATE_END
};

static const struct itemplate instrux_CVTSD2SS[] = {
    {I_CVTSD2SS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15166, IF_WILLAMETTE|IF_SSE2|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_CVTSI2SD[] = {
    {I_CVTSI2SD, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+8148, IF_WILLAMETTE|IF_SSE2|IF_SD|IF_AR1},
    {I_CVTSI2SD, 2, {XMMREG,RM_GPR|BITS32,0,0,0}, nasm_bytecodes+8148, IF_WILLAMETTE|IF_SSE2|IF_SD|IF_AR1},
    {I_CVTSI2SD, 2, {XMMREG,RM_GPR|BITS64,0,0,0}, nasm_bytecodes+8147, IF_X64|IF_SSE2|IF_SQ|IF_AR1},
    ITEMPLATE_END
};

static const struct itemplate instrux_CVTSI2SS[] = {
    {I_CVTSI2SS, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+7875, IF_KATMAI|IF_SSE|IF_SD|IF_AR1},
    {I_CVTSI2SS, 2, {XMMREG,RM_GPR|BITS32,0,0,0}, nasm_bytecodes+7875, IF_KATMAI|IF_SSE|IF_SD|IF_AR1},
    {I_CVTSI2SS, 2, {XMMREG,RM_GPR|BITS64,0,0,0}, nasm_bytecodes+7874, IF_X64|IF_SSE|IF_SQ|IF_AR1},
    ITEMPLATE_END
};

static const struct itemplate instrux_CVTSS2SD[] = {
    {I_CVTSS2SD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15172, IF_WILLAMETTE|IF_SSE2|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_CVTSS2SI[] = {
    {I_CVTSS2SI, 2, {REG32,XMMREG,0,0,0}, nasm_bytecodes+7882, IF_KATMAI|IF_SSE|IF_SD|IF_AR1},
    {I_CVTSS2SI, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+7882, IF_KATMAI|IF_SSE|IF_SD|IF_AR1},
    {I_CVTSS2SI, 2, {REG64,XMMREG,0,0,0}, nasm_bytecodes+7881, IF_X64|IF_SSE|IF_SD|IF_AR1},
    {I_CVTSS2SI, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+7881, IF_X64|IF_SSE|IF_SD|IF_AR1},
    ITEMPLATE_END
};

static const struct itemplate instrux_CVTTPD2DQ[] = {
    {I_CVTTPD2DQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15184, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_CVTTPD2PI[] = {
    {I_CVTTPD2PI, 2, {MMXREG,RM_XMM,0,0,0}, nasm_bytecodes+15178, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_CVTTPS2DQ[] = {
    {I_CVTTPS2DQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15190, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_CVTTPS2PI[] = {
    {I_CVTTPS2PI, 2, {MMXREG,RM_XMM,0,0,0}, nasm_bytecodes+14410, IF_KATMAI|IF_SSE|IF_MMX|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_CVTTSD2SI[] = {
    {I_CVTTSD2SI, 2, {REG32,XMMREG,0,0,0}, nasm_bytecodes+8155, IF_WILLAMETTE|IF_SSE2|IF_SQ|IF_AR1},
    {I_CVTTSD2SI, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+8155, IF_WILLAMETTE|IF_SSE2|IF_SQ|IF_AR1},
    {I_CVTTSD2SI, 2, {REG64,XMMREG,0,0,0}, nasm_bytecodes+8154, IF_X64|IF_SSE2|IF_SQ|IF_AR1},
    {I_CVTTSD2SI, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+8154, IF_X64|IF_SSE2|IF_SQ|IF_AR1},
    ITEMPLATE_END
};

static const struct itemplate instrux_CVTTSS2SI[] = {
    {I_CVTTSS2SI, 2, {REG32,RM_XMM,0,0,0}, nasm_bytecodes+7889, IF_KATMAI|IF_SSE|IF_SD|IF_AR1},
    {I_CVTTSS2SI, 2, {REG64,RM_XMM,0,0,0}, nasm_bytecodes+7888, IF_X64|IF_SSE|IF_SD|IF_AR1},
    ITEMPLATE_END
};

static const struct itemplate instrux_CWD[] = {
    {I_CWD, 0, {0,0,0,0,0}, nasm_bytecodes+18643, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_CWDE[] = {
    {I_CWDE, 0, {0,0,0,0,0}, nasm_bytecodes+18647, IF_386},
    ITEMPLATE_END
};

static const struct itemplate instrux_DAA[] = {
    {I_DAA, 0, {0,0,0,0,0}, nasm_bytecodes+19646, IF_8086|IF_NOLONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_DAS[] = {
    {I_DAS, 0, {0,0,0,0,0}, nasm_bytecodes+19649, IF_8086|IF_NOLONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_DB[] = {
    ITEMPLATE_END
};

static const struct itemplate instrux_DD[] = {
    ITEMPLATE_END
};

static const struct itemplate instrux_DEC[] = {
    {I_DEC, 1, {REG16,0,0,0,0}, nasm_bytecodes+18651, IF_8086|IF_NOLONG},
    {I_DEC, 1, {REG32,0,0,0,0}, nasm_bytecodes+18655, IF_386|IF_NOLONG},
    {I_DEC, 1, {RM_GPR|BITS8,0,0,0,0}, nasm_bytecodes+18659, IF_8086},
    {I_DEC, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16972, IF_8086},
    {I_DEC, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16977, IF_386},
    {I_DEC, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16982, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_DIV[] = {
    {I_DIV, 1, {RM_GPR|BITS8,0,0,0,0}, nasm_bytecodes+18663, IF_8086},
    {I_DIV, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16987, IF_8086},
    {I_DIV, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16992, IF_386},
    {I_DIV, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16997, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_DIVPD[] = {
    {I_DIVPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15196, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_DIVPS[] = {
    {I_DIVPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14416, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_DIVSD[] = {
    {I_DIVSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15202, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_DIVSS[] = {
    {I_DIVSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14422, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_DMINT[] = {
    {I_DMINT, 0, {0,0,0,0,0}, nasm_bytecodes+18667, IF_P6|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_DO[] = {
    ITEMPLATE_END
};

static const struct itemplate instrux_DPPD[] = {
    {I_DPPD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6126, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_DPPS[] = {
    {I_DPPS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6134, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_DQ[] = {
    ITEMPLATE_END
};

static const struct itemplate instrux_DT[] = {
    ITEMPLATE_END
};

static const struct itemplate instrux_DW[] = {
    ITEMPLATE_END
};

static const struct itemplate instrux_DY[] = {
    ITEMPLATE_END
};

static const struct itemplate instrux_EMMS[] = {
    {I_EMMS, 0, {0,0,0,0,0}, nasm_bytecodes+18671, IF_PENT|IF_MMX},
    ITEMPLATE_END
};

static const struct itemplate instrux_ENTER[] = {
    {I_ENTER, 2, {IMMEDIATE,IMMEDIATE,0,0,0}, nasm_bytecodes+17002, IF_186},
    ITEMPLATE_END
};

static const struct itemplate instrux_EQU[] = {
    {I_EQU, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+5948, IF_8086},
    {I_EQU, 2, {IMMEDIATE|COLON,IMMEDIATE,0,0,0}, nasm_bytecodes+5948, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_EXTRACTPS[] = {
    {I_EXTRACTPS, 3, {RM_GPR|BITS32,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+1, IF_SSE41},
    {I_EXTRACTPS, 3, {REG64,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+0, IF_SSE41|IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_EXTRQ[] = {
    {I_EXTRQ, 3, {XMMREG,IMMEDIATE,IMMEDIATE,0,0}, nasm_bytecodes+6094, IF_SSE4A|IF_AMD},
    {I_EXTRQ, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+15454, IF_SSE4A|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_F2XM1[] = {
    {I_F2XM1, 0, {0,0,0,0,0}, nasm_bytecodes+18675, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FABS[] = {
    {I_FABS, 0, {0,0,0,0,0}, nasm_bytecodes+18679, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FADD[] = {
    {I_FADD, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18683, IF_8086|IF_FPU},
    {I_FADD, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+18687, IF_8086|IF_FPU},
    {I_FADD, 1, {FPUREG|TO,0,0,0,0}, nasm_bytecodes+17007, IF_8086|IF_FPU},
    {I_FADD, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17012, IF_8086|IF_FPU},
    {I_FADD, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17007, IF_8086|IF_FPU},
    {I_FADD, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17017, IF_8086|IF_FPU},
    {I_FADD, 0, {0,0,0,0,0}, nasm_bytecodes+18691, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FADDP[] = {
    {I_FADDP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17022, IF_8086|IF_FPU},
    {I_FADDP, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17022, IF_8086|IF_FPU},
    {I_FADDP, 0, {0,0,0,0,0}, nasm_bytecodes+18691, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FBLD[] = {
    {I_FBLD, 1, {MEMORY|BITS80,0,0,0,0}, nasm_bytecodes+18695, IF_8086|IF_FPU},
    {I_FBLD, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18695, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FBSTP[] = {
    {I_FBSTP, 1, {MEMORY|BITS80,0,0,0,0}, nasm_bytecodes+18699, IF_8086|IF_FPU},
    {I_FBSTP, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18699, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FCHS[] = {
    {I_FCHS, 0, {0,0,0,0,0}, nasm_bytecodes+18703, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FCLEX[] = {
    {I_FCLEX, 0, {0,0,0,0,0}, nasm_bytecodes+17027, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FCMOVB[] = {
    {I_FCMOVB, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17032, IF_P6|IF_FPU},
    {I_FCMOVB, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17037, IF_P6|IF_FPU},
    {I_FCMOVB, 0, {0,0,0,0,0}, nasm_bytecodes+18707, IF_P6|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FCMOVBE[] = {
    {I_FCMOVBE, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17042, IF_P6|IF_FPU},
    {I_FCMOVBE, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17047, IF_P6|IF_FPU},
    {I_FCMOVBE, 0, {0,0,0,0,0}, nasm_bytecodes+18711, IF_P6|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FCMOVE[] = {
    {I_FCMOVE, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17052, IF_P6|IF_FPU},
    {I_FCMOVE, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17057, IF_P6|IF_FPU},
    {I_FCMOVE, 0, {0,0,0,0,0}, nasm_bytecodes+18715, IF_P6|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FCMOVNB[] = {
    {I_FCMOVNB, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17062, IF_P6|IF_FPU},
    {I_FCMOVNB, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17067, IF_P6|IF_FPU},
    {I_FCMOVNB, 0, {0,0,0,0,0}, nasm_bytecodes+18719, IF_P6|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FCMOVNBE[] = {
    {I_FCMOVNBE, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17072, IF_P6|IF_FPU},
    {I_FCMOVNBE, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17077, IF_P6|IF_FPU},
    {I_FCMOVNBE, 0, {0,0,0,0,0}, nasm_bytecodes+18723, IF_P6|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FCMOVNE[] = {
    {I_FCMOVNE, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17082, IF_P6|IF_FPU},
    {I_FCMOVNE, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17087, IF_P6|IF_FPU},
    {I_FCMOVNE, 0, {0,0,0,0,0}, nasm_bytecodes+18727, IF_P6|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FCMOVNU[] = {
    {I_FCMOVNU, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17092, IF_P6|IF_FPU},
    {I_FCMOVNU, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17097, IF_P6|IF_FPU},
    {I_FCMOVNU, 0, {0,0,0,0,0}, nasm_bytecodes+18731, IF_P6|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FCMOVU[] = {
    {I_FCMOVU, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17102, IF_P6|IF_FPU},
    {I_FCMOVU, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17107, IF_P6|IF_FPU},
    {I_FCMOVU, 0, {0,0,0,0,0}, nasm_bytecodes+18735, IF_P6|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FCOM[] = {
    {I_FCOM, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18739, IF_8086|IF_FPU},
    {I_FCOM, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+18743, IF_8086|IF_FPU},
    {I_FCOM, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17112, IF_8086|IF_FPU},
    {I_FCOM, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17117, IF_8086|IF_FPU},
    {I_FCOM, 0, {0,0,0,0,0}, nasm_bytecodes+18747, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FCOMI[] = {
    {I_FCOMI, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17122, IF_P6|IF_FPU},
    {I_FCOMI, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17127, IF_P6|IF_FPU},
    {I_FCOMI, 0, {0,0,0,0,0}, nasm_bytecodes+18751, IF_P6|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FCOMIP[] = {
    {I_FCOMIP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17132, IF_P6|IF_FPU},
    {I_FCOMIP, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17137, IF_P6|IF_FPU},
    {I_FCOMIP, 0, {0,0,0,0,0}, nasm_bytecodes+18755, IF_P6|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FCOMP[] = {
    {I_FCOMP, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18759, IF_8086|IF_FPU},
    {I_FCOMP, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+18763, IF_8086|IF_FPU},
    {I_FCOMP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17142, IF_8086|IF_FPU},
    {I_FCOMP, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17147, IF_8086|IF_FPU},
    {I_FCOMP, 0, {0,0,0,0,0}, nasm_bytecodes+18767, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FCOMPP[] = {
    {I_FCOMPP, 0, {0,0,0,0,0}, nasm_bytecodes+18771, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FCOS[] = {
    {I_FCOS, 0, {0,0,0,0,0}, nasm_bytecodes+18775, IF_386|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FDECSTP[] = {
    {I_FDECSTP, 0, {0,0,0,0,0}, nasm_bytecodes+18779, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FDISI[] = {
    {I_FDISI, 0, {0,0,0,0,0}, nasm_bytecodes+17152, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FDIV[] = {
    {I_FDIV, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18783, IF_8086|IF_FPU},
    {I_FDIV, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+18787, IF_8086|IF_FPU},
    {I_FDIV, 1, {FPUREG|TO,0,0,0,0}, nasm_bytecodes+17157, IF_8086|IF_FPU},
    {I_FDIV, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17162, IF_8086|IF_FPU},
    {I_FDIV, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17157, IF_8086|IF_FPU},
    {I_FDIV, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17167, IF_8086|IF_FPU},
    {I_FDIV, 0, {0,0,0,0,0}, nasm_bytecodes+18791, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FDIVP[] = {
    {I_FDIVP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17172, IF_8086|IF_FPU},
    {I_FDIVP, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17172, IF_8086|IF_FPU},
    {I_FDIVP, 0, {0,0,0,0,0}, nasm_bytecodes+18791, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FDIVR[] = {
    {I_FDIVR, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18795, IF_8086|IF_FPU},
    {I_FDIVR, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+18799, IF_8086|IF_FPU},
    {I_FDIVR, 1, {FPUREG|TO,0,0,0,0}, nasm_bytecodes+17177, IF_8086|IF_FPU},
    {I_FDIVR, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17177, IF_8086|IF_FPU},
    {I_FDIVR, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17182, IF_8086|IF_FPU},
    {I_FDIVR, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17187, IF_8086|IF_FPU},
    {I_FDIVR, 0, {0,0,0,0,0}, nasm_bytecodes+18803, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FDIVRP[] = {
    {I_FDIVRP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17192, IF_8086|IF_FPU},
    {I_FDIVRP, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17192, IF_8086|IF_FPU},
    {I_FDIVRP, 0, {0,0,0,0,0}, nasm_bytecodes+18803, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FEMMS[] = {
    {I_FEMMS, 0, {0,0,0,0,0}, nasm_bytecodes+18807, IF_PENT|IF_3DNOW},
    ITEMPLATE_END
};

static const struct itemplate instrux_FENI[] = {
    {I_FENI, 0, {0,0,0,0,0}, nasm_bytecodes+17197, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FFREE[] = {
    {I_FFREE, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17202, IF_8086|IF_FPU},
    {I_FFREE, 0, {0,0,0,0,0}, nasm_bytecodes+18811, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FFREEP[] = {
    {I_FFREEP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17207, IF_286|IF_FPU|IF_UNDOC},
    {I_FFREEP, 0, {0,0,0,0,0}, nasm_bytecodes+18815, IF_286|IF_FPU|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_FIADD[] = {
    {I_FIADD, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18819, IF_8086|IF_FPU},
    {I_FIADD, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18823, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FICOM[] = {
    {I_FICOM, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18827, IF_8086|IF_FPU},
    {I_FICOM, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18831, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FICOMP[] = {
    {I_FICOMP, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18835, IF_8086|IF_FPU},
    {I_FICOMP, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18839, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FIDIV[] = {
    {I_FIDIV, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18843, IF_8086|IF_FPU},
    {I_FIDIV, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18847, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FIDIVR[] = {
    {I_FIDIVR, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18851, IF_8086|IF_FPU},
    {I_FIDIVR, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18855, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FILD[] = {
    {I_FILD, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18859, IF_8086|IF_FPU},
    {I_FILD, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18863, IF_8086|IF_FPU},
    {I_FILD, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+18867, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FIMUL[] = {
    {I_FIMUL, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18871, IF_8086|IF_FPU},
    {I_FIMUL, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18875, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FINCSTP[] = {
    {I_FINCSTP, 0, {0,0,0,0,0}, nasm_bytecodes+18879, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FINIT[] = {
    {I_FINIT, 0, {0,0,0,0,0}, nasm_bytecodes+17212, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FIST[] = {
    {I_FIST, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18883, IF_8086|IF_FPU},
    {I_FIST, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18887, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FISTP[] = {
    {I_FISTP, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18891, IF_8086|IF_FPU},
    {I_FISTP, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18895, IF_8086|IF_FPU},
    {I_FISTP, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+18899, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FISTTP[] = {
    {I_FISTTP, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18903, IF_PRESCOTT|IF_FPU},
    {I_FISTTP, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18907, IF_PRESCOTT|IF_FPU},
    {I_FISTTP, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+18911, IF_PRESCOTT|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FISUB[] = {
    {I_FISUB, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18915, IF_8086|IF_FPU},
    {I_FISUB, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18919, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FISUBR[] = {
    {I_FISUBR, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18923, IF_8086|IF_FPU},
    {I_FISUBR, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18927, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FLD[] = {
    {I_FLD, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18931, IF_8086|IF_FPU},
    {I_FLD, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+18935, IF_8086|IF_FPU},
    {I_FLD, 1, {MEMORY|BITS80,0,0,0,0}, nasm_bytecodes+18939, IF_8086|IF_FPU},
    {I_FLD, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17217, IF_8086|IF_FPU},
    {I_FLD, 0, {0,0,0,0,0}, nasm_bytecodes+18943, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FLD1[] = {
    {I_FLD1, 0, {0,0,0,0,0}, nasm_bytecodes+18947, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FLDCW[] = {
    {I_FLDCW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18951, IF_8086|IF_FPU|IF_SW},
    ITEMPLATE_END
};

static const struct itemplate instrux_FLDENV[] = {
    {I_FLDENV, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18955, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FLDL2E[] = {
    {I_FLDL2E, 0, {0,0,0,0,0}, nasm_bytecodes+18959, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FLDL2T[] = {
    {I_FLDL2T, 0, {0,0,0,0,0}, nasm_bytecodes+18963, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FLDLG2[] = {
    {I_FLDLG2, 0, {0,0,0,0,0}, nasm_bytecodes+18967, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FLDLN2[] = {
    {I_FLDLN2, 0, {0,0,0,0,0}, nasm_bytecodes+18971, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FLDPI[] = {
    {I_FLDPI, 0, {0,0,0,0,0}, nasm_bytecodes+18975, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FLDZ[] = {
    {I_FLDZ, 0, {0,0,0,0,0}, nasm_bytecodes+18979, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FMADDPD[] = {
    {I_FMADDPD, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8686, IF_SSE5|IF_AMD},
    {I_FMADDPD, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+8693, IF_SSE5|IF_AMD},
    {I_FMADDPD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+8700, IF_SSE5|IF_AMD},
    {I_FMADDPD, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+8707, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_FMADDPS[] = {
    {I_FMADDPS, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8658, IF_SSE5|IF_AMD},
    {I_FMADDPS, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+8665, IF_SSE5|IF_AMD},
    {I_FMADDPS, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+8672, IF_SSE5|IF_AMD},
    {I_FMADDPS, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+8679, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_FMADDSD[] = {
    {I_FMADDSD, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8742, IF_SSE5|IF_AMD},
    {I_FMADDSD, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+8749, IF_SSE5|IF_AMD},
    {I_FMADDSD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+8756, IF_SSE5|IF_AMD},
    {I_FMADDSD, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+8763, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_FMADDSS[] = {
    {I_FMADDSS, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8714, IF_SSE5|IF_AMD},
    {I_FMADDSS, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+8721, IF_SSE5|IF_AMD},
    {I_FMADDSS, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+8728, IF_SSE5|IF_AMD},
    {I_FMADDSS, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+8735, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_FMSUBPD[] = {
    {I_FMSUBPD, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8798, IF_SSE5|IF_AMD},
    {I_FMSUBPD, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+8805, IF_SSE5|IF_AMD},
    {I_FMSUBPD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+8812, IF_SSE5|IF_AMD},
    {I_FMSUBPD, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+8819, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_FMSUBPS[] = {
    {I_FMSUBPS, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8770, IF_SSE5|IF_AMD},
    {I_FMSUBPS, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+8777, IF_SSE5|IF_AMD},
    {I_FMSUBPS, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+8784, IF_SSE5|IF_AMD},
    {I_FMSUBPS, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+8791, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_FMSUBSD[] = {
    {I_FMSUBSD, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8854, IF_SSE5|IF_AMD},
    {I_FMSUBSD, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+8861, IF_SSE5|IF_AMD},
    {I_FMSUBSD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+8868, IF_SSE5|IF_AMD},
    {I_FMSUBSD, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+8875, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_FMSUBSS[] = {
    {I_FMSUBSS, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8826, IF_SSE5|IF_AMD},
    {I_FMSUBSS, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+8833, IF_SSE5|IF_AMD},
    {I_FMSUBSS, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+8840, IF_SSE5|IF_AMD},
    {I_FMSUBSS, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+8847, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_FMUL[] = {
    {I_FMUL, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+18983, IF_8086|IF_FPU},
    {I_FMUL, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+18987, IF_8086|IF_FPU},
    {I_FMUL, 1, {FPUREG|TO,0,0,0,0}, nasm_bytecodes+17222, IF_8086|IF_FPU},
    {I_FMUL, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17222, IF_8086|IF_FPU},
    {I_FMUL, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17227, IF_8086|IF_FPU},
    {I_FMUL, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17232, IF_8086|IF_FPU},
    {I_FMUL, 0, {0,0,0,0,0}, nasm_bytecodes+18991, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FMULP[] = {
    {I_FMULP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17237, IF_8086|IF_FPU},
    {I_FMULP, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17237, IF_8086|IF_FPU},
    {I_FMULP, 0, {0,0,0,0,0}, nasm_bytecodes+18991, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FNCLEX[] = {
    {I_FNCLEX, 0, {0,0,0,0,0}, nasm_bytecodes+18995, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FNDISI[] = {
    {I_FNDISI, 0, {0,0,0,0,0}, nasm_bytecodes+18999, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FNENI[] = {
    {I_FNENI, 0, {0,0,0,0,0}, nasm_bytecodes+19003, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FNINIT[] = {
    {I_FNINIT, 0, {0,0,0,0,0}, nasm_bytecodes+19007, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FNMADDPD[] = {
    {I_FNMADDPD, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8910, IF_SSE5|IF_AMD},
    {I_FNMADDPD, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+8917, IF_SSE5|IF_AMD},
    {I_FNMADDPD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+8924, IF_SSE5|IF_AMD},
    {I_FNMADDPD, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+8931, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_FNMADDPS[] = {
    {I_FNMADDPS, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8882, IF_SSE5|IF_AMD},
    {I_FNMADDPS, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+8889, IF_SSE5|IF_AMD},
    {I_FNMADDPS, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+8896, IF_SSE5|IF_AMD},
    {I_FNMADDPS, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+8903, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_FNMADDSD[] = {
    {I_FNMADDSD, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8966, IF_SSE5|IF_AMD},
    {I_FNMADDSD, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+8973, IF_SSE5|IF_AMD},
    {I_FNMADDSD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+8980, IF_SSE5|IF_AMD},
    {I_FNMADDSD, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+8987, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_FNMADDSS[] = {
    {I_FNMADDSS, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8938, IF_SSE5|IF_AMD},
    {I_FNMADDSS, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+8945, IF_SSE5|IF_AMD},
    {I_FNMADDSS, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+8952, IF_SSE5|IF_AMD},
    {I_FNMADDSS, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+8959, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_FNMSUBPD[] = {
    {I_FNMSUBPD, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+9022, IF_SSE5|IF_AMD},
    {I_FNMSUBPD, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+9029, IF_SSE5|IF_AMD},
    {I_FNMSUBPD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9036, IF_SSE5|IF_AMD},
    {I_FNMSUBPD, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+9043, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_FNMSUBPS[] = {
    {I_FNMSUBPS, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+8994, IF_SSE5|IF_AMD},
    {I_FNMSUBPS, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+9001, IF_SSE5|IF_AMD},
    {I_FNMSUBPS, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9008, IF_SSE5|IF_AMD},
    {I_FNMSUBPS, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+9015, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_FNMSUBSD[] = {
    {I_FNMSUBSD, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+9078, IF_SSE5|IF_AMD},
    {I_FNMSUBSD, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+9085, IF_SSE5|IF_AMD},
    {I_FNMSUBSD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9092, IF_SSE5|IF_AMD},
    {I_FNMSUBSD, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+9099, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_FNMSUBSS[] = {
    {I_FNMSUBSS, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+9050, IF_SSE5|IF_AMD},
    {I_FNMSUBSS, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+9057, IF_SSE5|IF_AMD},
    {I_FNMSUBSS, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9064, IF_SSE5|IF_AMD},
    {I_FNMSUBSS, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+9071, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_FNOP[] = {
    {I_FNOP, 0, {0,0,0,0,0}, nasm_bytecodes+19011, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FNSAVE[] = {
    {I_FNSAVE, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+19015, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FNSTCW[] = {
    {I_FNSTCW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+19019, IF_8086|IF_FPU|IF_SW},
    ITEMPLATE_END
};

static const struct itemplate instrux_FNSTENV[] = {
    {I_FNSTENV, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+19023, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FNSTSW[] = {
    {I_FNSTSW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+19027, IF_8086|IF_FPU|IF_SW},
    {I_FNSTSW, 1, {REG_AX,0,0,0,0}, nasm_bytecodes+19031, IF_286|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FPATAN[] = {
    {I_FPATAN, 0, {0,0,0,0,0}, nasm_bytecodes+19035, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FPREM[] = {
    {I_FPREM, 0, {0,0,0,0,0}, nasm_bytecodes+19039, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FPREM1[] = {
    {I_FPREM1, 0, {0,0,0,0,0}, nasm_bytecodes+19043, IF_386|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FPTAN[] = {
    {I_FPTAN, 0, {0,0,0,0,0}, nasm_bytecodes+19047, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FRCZPD[] = {
    {I_FRCZPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9477, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_FRCZPS[] = {
    {I_FRCZPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9470, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_FRCZSD[] = {
    {I_FRCZSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9491, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_FRCZSS[] = {
    {I_FRCZSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9484, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_FRNDINT[] = {
    {I_FRNDINT, 0, {0,0,0,0,0}, nasm_bytecodes+19051, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FRSTOR[] = {
    {I_FRSTOR, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+19055, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FSAVE[] = {
    {I_FSAVE, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17242, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FSCALE[] = {
    {I_FSCALE, 0, {0,0,0,0,0}, nasm_bytecodes+19059, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FSETPM[] = {
    {I_FSETPM, 0, {0,0,0,0,0}, nasm_bytecodes+19063, IF_286|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FSIN[] = {
    {I_FSIN, 0, {0,0,0,0,0}, nasm_bytecodes+19067, IF_386|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FSINCOS[] = {
    {I_FSINCOS, 0, {0,0,0,0,0}, nasm_bytecodes+19071, IF_386|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FSQRT[] = {
    {I_FSQRT, 0, {0,0,0,0,0}, nasm_bytecodes+19075, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FST[] = {
    {I_FST, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+19079, IF_8086|IF_FPU},
    {I_FST, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+19083, IF_8086|IF_FPU},
    {I_FST, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17247, IF_8086|IF_FPU},
    {I_FST, 0, {0,0,0,0,0}, nasm_bytecodes+19087, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FSTCW[] = {
    {I_FSTCW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17252, IF_8086|IF_FPU|IF_SW},
    ITEMPLATE_END
};

static const struct itemplate instrux_FSTENV[] = {
    {I_FSTENV, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17257, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FSTP[] = {
    {I_FSTP, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+19091, IF_8086|IF_FPU},
    {I_FSTP, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+19095, IF_8086|IF_FPU},
    {I_FSTP, 1, {MEMORY|BITS80,0,0,0,0}, nasm_bytecodes+19099, IF_8086|IF_FPU},
    {I_FSTP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17262, IF_8086|IF_FPU},
    {I_FSTP, 0, {0,0,0,0,0}, nasm_bytecodes+19103, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FSTSW[] = {
    {I_FSTSW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17267, IF_8086|IF_FPU|IF_SW},
    {I_FSTSW, 1, {REG_AX,0,0,0,0}, nasm_bytecodes+17272, IF_286|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FSUB[] = {
    {I_FSUB, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+19107, IF_8086|IF_FPU},
    {I_FSUB, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+19111, IF_8086|IF_FPU},
    {I_FSUB, 1, {FPUREG|TO,0,0,0,0}, nasm_bytecodes+17277, IF_8086|IF_FPU},
    {I_FSUB, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17277, IF_8086|IF_FPU},
    {I_FSUB, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17282, IF_8086|IF_FPU},
    {I_FSUB, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17287, IF_8086|IF_FPU},
    {I_FSUB, 0, {0,0,0,0,0}, nasm_bytecodes+19115, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FSUBP[] = {
    {I_FSUBP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17292, IF_8086|IF_FPU},
    {I_FSUBP, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17292, IF_8086|IF_FPU},
    {I_FSUBP, 0, {0,0,0,0,0}, nasm_bytecodes+19115, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FSUBR[] = {
    {I_FSUBR, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+19119, IF_8086|IF_FPU},
    {I_FSUBR, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+19123, IF_8086|IF_FPU},
    {I_FSUBR, 1, {FPUREG|TO,0,0,0,0}, nasm_bytecodes+17297, IF_8086|IF_FPU},
    {I_FSUBR, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17297, IF_8086|IF_FPU},
    {I_FSUBR, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17302, IF_8086|IF_FPU},
    {I_FSUBR, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17307, IF_8086|IF_FPU},
    {I_FSUBR, 0, {0,0,0,0,0}, nasm_bytecodes+19127, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FSUBRP[] = {
    {I_FSUBRP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17312, IF_8086|IF_FPU},
    {I_FSUBRP, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17312, IF_8086|IF_FPU},
    {I_FSUBRP, 0, {0,0,0,0,0}, nasm_bytecodes+19127, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FTST[] = {
    {I_FTST, 0, {0,0,0,0,0}, nasm_bytecodes+19131, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FUCOM[] = {
    {I_FUCOM, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17317, IF_386|IF_FPU},
    {I_FUCOM, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17322, IF_386|IF_FPU},
    {I_FUCOM, 0, {0,0,0,0,0}, nasm_bytecodes+19135, IF_386|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FUCOMI[] = {
    {I_FUCOMI, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17327, IF_P6|IF_FPU},
    {I_FUCOMI, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17332, IF_P6|IF_FPU},
    {I_FUCOMI, 0, {0,0,0,0,0}, nasm_bytecodes+19139, IF_P6|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FUCOMIP[] = {
    {I_FUCOMIP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17337, IF_P6|IF_FPU},
    {I_FUCOMIP, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17342, IF_P6|IF_FPU},
    {I_FUCOMIP, 0, {0,0,0,0,0}, nasm_bytecodes+19143, IF_P6|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FUCOMP[] = {
    {I_FUCOMP, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17347, IF_386|IF_FPU},
    {I_FUCOMP, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17352, IF_386|IF_FPU},
    {I_FUCOMP, 0, {0,0,0,0,0}, nasm_bytecodes+19147, IF_386|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FUCOMPP[] = {
    {I_FUCOMPP, 0, {0,0,0,0,0}, nasm_bytecodes+19151, IF_386|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FWAIT[] = {
    {I_FWAIT, 0, {0,0,0,0,0}, nasm_bytecodes+19694, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_FXAM[] = {
    {I_FXAM, 0, {0,0,0,0,0}, nasm_bytecodes+19155, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FXCH[] = {
    {I_FXCH, 1, {FPUREG,0,0,0,0}, nasm_bytecodes+17357, IF_8086|IF_FPU},
    {I_FXCH, 2, {FPUREG,FPU0,0,0,0}, nasm_bytecodes+17357, IF_8086|IF_FPU},
    {I_FXCH, 2, {FPU0,FPUREG,0,0,0}, nasm_bytecodes+17362, IF_8086|IF_FPU},
    {I_FXCH, 0, {0,0,0,0,0}, nasm_bytecodes+19159, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FXRSTOR[] = {
    {I_FXRSTOR, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18482, IF_P6|IF_SSE|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FXSAVE[] = {
    {I_FXSAVE, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18487, IF_P6|IF_SSE|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FXTRACT[] = {
    {I_FXTRACT, 0, {0,0,0,0,0}, nasm_bytecodes+19163, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FYL2X[] = {
    {I_FYL2X, 0, {0,0,0,0,0}, nasm_bytecodes+19167, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_FYL2XP1[] = {
    {I_FYL2XP1, 0, {0,0,0,0,0}, nasm_bytecodes+19171, IF_8086|IF_FPU},
    ITEMPLATE_END
};

static const struct itemplate instrux_GETSEC[] = {
    {I_GETSEC, 0, {0,0,0,0,0}, nasm_bytecodes+19627, IF_KATMAI},
    ITEMPLATE_END
};

static const struct itemplate instrux_HADDPD[] = {
    {I_HADDPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15394, IF_PRESCOTT|IF_SSE3|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_HADDPS[] = {
    {I_HADDPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15400, IF_PRESCOTT|IF_SSE3|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP0[] = {
    {I_HINT_NOP0, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15538, IF_P6|IF_UNDOC},
    {I_HINT_NOP0, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15544, IF_P6|IF_UNDOC},
    {I_HINT_NOP0, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15550, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP1[] = {
    {I_HINT_NOP1, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15556, IF_P6|IF_UNDOC},
    {I_HINT_NOP1, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15562, IF_P6|IF_UNDOC},
    {I_HINT_NOP1, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15568, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP10[] = {
    {I_HINT_NOP10, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15718, IF_P6|IF_UNDOC},
    {I_HINT_NOP10, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15724, IF_P6|IF_UNDOC},
    {I_HINT_NOP10, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15730, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP11[] = {
    {I_HINT_NOP11, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15736, IF_P6|IF_UNDOC},
    {I_HINT_NOP11, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15742, IF_P6|IF_UNDOC},
    {I_HINT_NOP11, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15748, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP12[] = {
    {I_HINT_NOP12, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15754, IF_P6|IF_UNDOC},
    {I_HINT_NOP12, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15760, IF_P6|IF_UNDOC},
    {I_HINT_NOP12, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15766, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP13[] = {
    {I_HINT_NOP13, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15772, IF_P6|IF_UNDOC},
    {I_HINT_NOP13, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15778, IF_P6|IF_UNDOC},
    {I_HINT_NOP13, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15784, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP14[] = {
    {I_HINT_NOP14, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15790, IF_P6|IF_UNDOC},
    {I_HINT_NOP14, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15796, IF_P6|IF_UNDOC},
    {I_HINT_NOP14, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15802, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP15[] = {
    {I_HINT_NOP15, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15808, IF_P6|IF_UNDOC},
    {I_HINT_NOP15, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15814, IF_P6|IF_UNDOC},
    {I_HINT_NOP15, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15820, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP16[] = {
    {I_HINT_NOP16, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15826, IF_P6|IF_UNDOC},
    {I_HINT_NOP16, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15832, IF_P6|IF_UNDOC},
    {I_HINT_NOP16, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15838, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP17[] = {
    {I_HINT_NOP17, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15844, IF_P6|IF_UNDOC},
    {I_HINT_NOP17, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15850, IF_P6|IF_UNDOC},
    {I_HINT_NOP17, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15856, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP18[] = {
    {I_HINT_NOP18, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15862, IF_P6|IF_UNDOC},
    {I_HINT_NOP18, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15868, IF_P6|IF_UNDOC},
    {I_HINT_NOP18, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15874, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP19[] = {
    {I_HINT_NOP19, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15880, IF_P6|IF_UNDOC},
    {I_HINT_NOP19, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15886, IF_P6|IF_UNDOC},
    {I_HINT_NOP19, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15892, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP2[] = {
    {I_HINT_NOP2, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15574, IF_P6|IF_UNDOC},
    {I_HINT_NOP2, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15580, IF_P6|IF_UNDOC},
    {I_HINT_NOP2, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15586, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP20[] = {
    {I_HINT_NOP20, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15898, IF_P6|IF_UNDOC},
    {I_HINT_NOP20, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15904, IF_P6|IF_UNDOC},
    {I_HINT_NOP20, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15910, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP21[] = {
    {I_HINT_NOP21, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15916, IF_P6|IF_UNDOC},
    {I_HINT_NOP21, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15922, IF_P6|IF_UNDOC},
    {I_HINT_NOP21, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15928, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP22[] = {
    {I_HINT_NOP22, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15934, IF_P6|IF_UNDOC},
    {I_HINT_NOP22, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15940, IF_P6|IF_UNDOC},
    {I_HINT_NOP22, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15946, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP23[] = {
    {I_HINT_NOP23, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15952, IF_P6|IF_UNDOC},
    {I_HINT_NOP23, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15958, IF_P6|IF_UNDOC},
    {I_HINT_NOP23, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15964, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP24[] = {
    {I_HINT_NOP24, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15970, IF_P6|IF_UNDOC},
    {I_HINT_NOP24, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15976, IF_P6|IF_UNDOC},
    {I_HINT_NOP24, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15982, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP25[] = {
    {I_HINT_NOP25, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15988, IF_P6|IF_UNDOC},
    {I_HINT_NOP25, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15994, IF_P6|IF_UNDOC},
    {I_HINT_NOP25, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16000, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP26[] = {
    {I_HINT_NOP26, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16006, IF_P6|IF_UNDOC},
    {I_HINT_NOP26, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16012, IF_P6|IF_UNDOC},
    {I_HINT_NOP26, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16018, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP27[] = {
    {I_HINT_NOP27, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16024, IF_P6|IF_UNDOC},
    {I_HINT_NOP27, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16030, IF_P6|IF_UNDOC},
    {I_HINT_NOP27, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16036, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP28[] = {
    {I_HINT_NOP28, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16042, IF_P6|IF_UNDOC},
    {I_HINT_NOP28, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16048, IF_P6|IF_UNDOC},
    {I_HINT_NOP28, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16054, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP29[] = {
    {I_HINT_NOP29, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16060, IF_P6|IF_UNDOC},
    {I_HINT_NOP29, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16066, IF_P6|IF_UNDOC},
    {I_HINT_NOP29, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16072, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP3[] = {
    {I_HINT_NOP3, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15592, IF_P6|IF_UNDOC},
    {I_HINT_NOP3, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15598, IF_P6|IF_UNDOC},
    {I_HINT_NOP3, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15604, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP30[] = {
    {I_HINT_NOP30, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16078, IF_P6|IF_UNDOC},
    {I_HINT_NOP30, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16084, IF_P6|IF_UNDOC},
    {I_HINT_NOP30, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16090, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP31[] = {
    {I_HINT_NOP31, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16096, IF_P6|IF_UNDOC},
    {I_HINT_NOP31, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16102, IF_P6|IF_UNDOC},
    {I_HINT_NOP31, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16108, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP32[] = {
    {I_HINT_NOP32, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16114, IF_P6|IF_UNDOC},
    {I_HINT_NOP32, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16120, IF_P6|IF_UNDOC},
    {I_HINT_NOP32, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16126, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP33[] = {
    {I_HINT_NOP33, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16132, IF_P6|IF_UNDOC},
    {I_HINT_NOP33, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16138, IF_P6|IF_UNDOC},
    {I_HINT_NOP33, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16144, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP34[] = {
    {I_HINT_NOP34, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16150, IF_P6|IF_UNDOC},
    {I_HINT_NOP34, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16156, IF_P6|IF_UNDOC},
    {I_HINT_NOP34, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16162, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP35[] = {
    {I_HINT_NOP35, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16168, IF_P6|IF_UNDOC},
    {I_HINT_NOP35, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16174, IF_P6|IF_UNDOC},
    {I_HINT_NOP35, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16180, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP36[] = {
    {I_HINT_NOP36, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16186, IF_P6|IF_UNDOC},
    {I_HINT_NOP36, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16192, IF_P6|IF_UNDOC},
    {I_HINT_NOP36, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16198, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP37[] = {
    {I_HINT_NOP37, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16204, IF_P6|IF_UNDOC},
    {I_HINT_NOP37, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16210, IF_P6|IF_UNDOC},
    {I_HINT_NOP37, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16216, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP38[] = {
    {I_HINT_NOP38, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16222, IF_P6|IF_UNDOC},
    {I_HINT_NOP38, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16228, IF_P6|IF_UNDOC},
    {I_HINT_NOP38, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16234, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP39[] = {
    {I_HINT_NOP39, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16240, IF_P6|IF_UNDOC},
    {I_HINT_NOP39, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16246, IF_P6|IF_UNDOC},
    {I_HINT_NOP39, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16252, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP4[] = {
    {I_HINT_NOP4, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15610, IF_P6|IF_UNDOC},
    {I_HINT_NOP4, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15616, IF_P6|IF_UNDOC},
    {I_HINT_NOP4, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15622, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP40[] = {
    {I_HINT_NOP40, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16258, IF_P6|IF_UNDOC},
    {I_HINT_NOP40, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16264, IF_P6|IF_UNDOC},
    {I_HINT_NOP40, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16270, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP41[] = {
    {I_HINT_NOP41, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16276, IF_P6|IF_UNDOC},
    {I_HINT_NOP41, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16282, IF_P6|IF_UNDOC},
    {I_HINT_NOP41, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16288, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP42[] = {
    {I_HINT_NOP42, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16294, IF_P6|IF_UNDOC},
    {I_HINT_NOP42, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16300, IF_P6|IF_UNDOC},
    {I_HINT_NOP42, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16306, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP43[] = {
    {I_HINT_NOP43, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16312, IF_P6|IF_UNDOC},
    {I_HINT_NOP43, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16318, IF_P6|IF_UNDOC},
    {I_HINT_NOP43, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16324, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP44[] = {
    {I_HINT_NOP44, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16330, IF_P6|IF_UNDOC},
    {I_HINT_NOP44, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16336, IF_P6|IF_UNDOC},
    {I_HINT_NOP44, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16342, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP45[] = {
    {I_HINT_NOP45, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16348, IF_P6|IF_UNDOC},
    {I_HINT_NOP45, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16354, IF_P6|IF_UNDOC},
    {I_HINT_NOP45, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16360, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP46[] = {
    {I_HINT_NOP46, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16366, IF_P6|IF_UNDOC},
    {I_HINT_NOP46, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16372, IF_P6|IF_UNDOC},
    {I_HINT_NOP46, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16378, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP47[] = {
    {I_HINT_NOP47, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16384, IF_P6|IF_UNDOC},
    {I_HINT_NOP47, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16390, IF_P6|IF_UNDOC},
    {I_HINT_NOP47, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16396, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP48[] = {
    {I_HINT_NOP48, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16402, IF_P6|IF_UNDOC},
    {I_HINT_NOP48, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16408, IF_P6|IF_UNDOC},
    {I_HINT_NOP48, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16414, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP49[] = {
    {I_HINT_NOP49, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16420, IF_P6|IF_UNDOC},
    {I_HINT_NOP49, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16426, IF_P6|IF_UNDOC},
    {I_HINT_NOP49, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16432, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP5[] = {
    {I_HINT_NOP5, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15628, IF_P6|IF_UNDOC},
    {I_HINT_NOP5, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15634, IF_P6|IF_UNDOC},
    {I_HINT_NOP5, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15640, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP50[] = {
    {I_HINT_NOP50, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16438, IF_P6|IF_UNDOC},
    {I_HINT_NOP50, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16444, IF_P6|IF_UNDOC},
    {I_HINT_NOP50, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16450, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP51[] = {
    {I_HINT_NOP51, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16456, IF_P6|IF_UNDOC},
    {I_HINT_NOP51, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16462, IF_P6|IF_UNDOC},
    {I_HINT_NOP51, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16468, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP52[] = {
    {I_HINT_NOP52, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16474, IF_P6|IF_UNDOC},
    {I_HINT_NOP52, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16480, IF_P6|IF_UNDOC},
    {I_HINT_NOP52, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16486, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP53[] = {
    {I_HINT_NOP53, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16492, IF_P6|IF_UNDOC},
    {I_HINT_NOP53, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16498, IF_P6|IF_UNDOC},
    {I_HINT_NOP53, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16504, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP54[] = {
    {I_HINT_NOP54, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16510, IF_P6|IF_UNDOC},
    {I_HINT_NOP54, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16516, IF_P6|IF_UNDOC},
    {I_HINT_NOP54, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16522, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP55[] = {
    {I_HINT_NOP55, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16528, IF_P6|IF_UNDOC},
    {I_HINT_NOP55, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16534, IF_P6|IF_UNDOC},
    {I_HINT_NOP55, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16540, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP56[] = {
    {I_HINT_NOP56, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+13876, IF_P6|IF_UNDOC},
    {I_HINT_NOP56, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+13882, IF_P6|IF_UNDOC},
    {I_HINT_NOP56, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+13888, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP57[] = {
    {I_HINT_NOP57, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16546, IF_P6|IF_UNDOC},
    {I_HINT_NOP57, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16552, IF_P6|IF_UNDOC},
    {I_HINT_NOP57, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16558, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP58[] = {
    {I_HINT_NOP58, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16564, IF_P6|IF_UNDOC},
    {I_HINT_NOP58, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16570, IF_P6|IF_UNDOC},
    {I_HINT_NOP58, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16576, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP59[] = {
    {I_HINT_NOP59, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16582, IF_P6|IF_UNDOC},
    {I_HINT_NOP59, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16588, IF_P6|IF_UNDOC},
    {I_HINT_NOP59, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16594, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP6[] = {
    {I_HINT_NOP6, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15646, IF_P6|IF_UNDOC},
    {I_HINT_NOP6, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15652, IF_P6|IF_UNDOC},
    {I_HINT_NOP6, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15658, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP60[] = {
    {I_HINT_NOP60, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16600, IF_P6|IF_UNDOC},
    {I_HINT_NOP60, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16606, IF_P6|IF_UNDOC},
    {I_HINT_NOP60, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16612, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP61[] = {
    {I_HINT_NOP61, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16618, IF_P6|IF_UNDOC},
    {I_HINT_NOP61, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16624, IF_P6|IF_UNDOC},
    {I_HINT_NOP61, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16630, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP62[] = {
    {I_HINT_NOP62, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16636, IF_P6|IF_UNDOC},
    {I_HINT_NOP62, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16642, IF_P6|IF_UNDOC},
    {I_HINT_NOP62, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16648, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP63[] = {
    {I_HINT_NOP63, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+16654, IF_P6|IF_UNDOC},
    {I_HINT_NOP63, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+16660, IF_P6|IF_UNDOC},
    {I_HINT_NOP63, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+16666, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP7[] = {
    {I_HINT_NOP7, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15664, IF_P6|IF_UNDOC},
    {I_HINT_NOP7, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15670, IF_P6|IF_UNDOC},
    {I_HINT_NOP7, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15676, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP8[] = {
    {I_HINT_NOP8, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15682, IF_P6|IF_UNDOC},
    {I_HINT_NOP8, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15688, IF_P6|IF_UNDOC},
    {I_HINT_NOP8, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15694, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HINT_NOP9[] = {
    {I_HINT_NOP9, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+15700, IF_P6|IF_UNDOC},
    {I_HINT_NOP9, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+15706, IF_P6|IF_UNDOC},
    {I_HINT_NOP9, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+15712, IF_X64|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_HLT[] = {
    {I_HLT, 0, {0,0,0,0,0}, nasm_bytecodes+19652, IF_8086|IF_PRIV},
    ITEMPLATE_END
};

static const struct itemplate instrux_HSUBPD[] = {
    {I_HSUBPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15406, IF_PRESCOTT|IF_SSE3|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_HSUBPS[] = {
    {I_HSUBPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15412, IF_PRESCOTT|IF_SSE3|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_IBTS[] = {
    {I_IBTS, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+13456, IF_386|IF_SW|IF_UNDOC},
    {I_IBTS, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+13456, IF_386|IF_UNDOC},
    {I_IBTS, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+13462, IF_386|IF_SD|IF_UNDOC},
    {I_IBTS, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+13462, IF_386|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_ICEBP[] = {
    {I_ICEBP, 0, {0,0,0,0,0}, nasm_bytecodes+19655, IF_386},
    ITEMPLATE_END
};

static const struct itemplate instrux_IDIV[] = {
    {I_IDIV, 1, {RM_GPR|BITS8,0,0,0,0}, nasm_bytecodes+19175, IF_8086},
    {I_IDIV, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+17367, IF_8086},
    {I_IDIV, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+17372, IF_386},
    {I_IDIV, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+17377, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_IMUL[] = {
    {I_IMUL, 1, {RM_GPR|BITS8,0,0,0,0}, nasm_bytecodes+19179, IF_8086},
    {I_IMUL, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+17382, IF_8086},
    {I_IMUL, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+17387, IF_386},
    {I_IMUL, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+17392, IF_X64},
    {I_IMUL, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+13474, IF_386|IF_SM},
    {I_IMUL, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+13474, IF_386},
    {I_IMUL, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+13480, IF_386|IF_SM},
    {I_IMUL, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+13480, IF_386},
    {I_IMUL, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+13486, IF_X64|IF_SM},
    {I_IMUL, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+13486, IF_X64},
    {I_IMUL, 3, {REG16,MEMORY,IMMEDIATE|BITS8,0,0}, nasm_bytecodes+13492, IF_186|IF_SM},
    {I_IMUL, 3, {REG16,MEMORY,SBYTE16,0,0}, nasm_bytecodes+13492, IF_186|IF_SM},
    {I_IMUL, 3, {REG16,MEMORY,IMMEDIATE|BITS16,0,0}, nasm_bytecodes+13498, IF_186|IF_SM},
    {I_IMUL, 3, {REG16,MEMORY,IMMEDIATE,0,0}, nasm_bytecodes+13504, IF_186|IF_SM},
    {I_IMUL, 3, {REG16,REG16,IMMEDIATE|BITS8,0,0}, nasm_bytecodes+13492, IF_186},
    {I_IMUL, 3, {REG16,REG16,SBYTE32,0,0}, nasm_bytecodes+13492, IF_186|IF_SM},
    {I_IMUL, 3, {REG16,REG16,IMMEDIATE|BITS16,0,0}, nasm_bytecodes+13498, IF_186},
    {I_IMUL, 3, {REG16,REG16,IMMEDIATE,0,0}, nasm_bytecodes+13504, IF_186|IF_SM},
    {I_IMUL, 3, {REG32,MEMORY,IMMEDIATE|BITS8,0,0}, nasm_bytecodes+13510, IF_386|IF_SM},
    {I_IMUL, 3, {REG32,MEMORY,SBYTE64,0,0}, nasm_bytecodes+13510, IF_386|IF_SM},
    {I_IMUL, 3, {REG32,MEMORY,IMMEDIATE|BITS32,0,0}, nasm_bytecodes+13516, IF_386|IF_SM},
    {I_IMUL, 3, {REG32,MEMORY,IMMEDIATE,0,0}, nasm_bytecodes+13522, IF_386|IF_SM},
    {I_IMUL, 3, {REG32,REG32,IMMEDIATE|BITS8,0,0}, nasm_bytecodes+13510, IF_386},
    {I_IMUL, 3, {REG32,REG32,SBYTE16,0,0}, nasm_bytecodes+13510, IF_386|IF_SM},
    {I_IMUL, 3, {REG32,REG32,IMMEDIATE|BITS32,0,0}, nasm_bytecodes+13516, IF_386},
    {I_IMUL, 3, {REG32,REG32,IMMEDIATE,0,0}, nasm_bytecodes+13522, IF_386|IF_SM},
    {I_IMUL, 3, {REG64,MEMORY,IMMEDIATE|BITS8,0,0}, nasm_bytecodes+13528, IF_X64|IF_SM},
    {I_IMUL, 3, {REG64,MEMORY,SBYTE32,0,0}, nasm_bytecodes+13528, IF_X64|IF_SM},
    {I_IMUL, 3, {REG64,MEMORY,IMMEDIATE|BITS32,0,0}, nasm_bytecodes+13534, IF_X64|IF_SM},
    {I_IMUL, 3, {REG64,MEMORY,IMMEDIATE,0,0}, nasm_bytecodes+13540, IF_X64|IF_SM},
    {I_IMUL, 3, {REG64,REG64,IMMEDIATE|BITS8,0,0}, nasm_bytecodes+13528, IF_X64},
    {I_IMUL, 3, {REG64,REG64,SBYTE64,0,0}, nasm_bytecodes+13528, IF_X64|IF_SM},
    {I_IMUL, 3, {REG64,REG64,IMMEDIATE|BITS32,0,0}, nasm_bytecodes+13534, IF_X64},
    {I_IMUL, 3, {REG64,REG64,IMMEDIATE,0,0}, nasm_bytecodes+13540, IF_X64|IF_SM},
    {I_IMUL, 2, {REG16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13546, IF_186},
    {I_IMUL, 2, {REG16,SBYTE16,0,0,0}, nasm_bytecodes+13546, IF_186|IF_SM},
    {I_IMUL, 2, {REG16,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+13552, IF_186},
    {I_IMUL, 2, {REG16,IMMEDIATE,0,0,0}, nasm_bytecodes+13558, IF_186|IF_SM},
    {I_IMUL, 2, {REG32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13564, IF_386},
    {I_IMUL, 2, {REG32,SBYTE32,0,0,0}, nasm_bytecodes+13564, IF_386|IF_SM},
    {I_IMUL, 2, {REG32,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+13570, IF_386},
    {I_IMUL, 2, {REG32,IMMEDIATE,0,0,0}, nasm_bytecodes+13576, IF_386|IF_SM},
    {I_IMUL, 2, {REG64,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13582, IF_X64},
    {I_IMUL, 2, {REG64,SBYTE64,0,0,0}, nasm_bytecodes+13582, IF_X64|IF_SM},
    {I_IMUL, 2, {REG64,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+13588, IF_X64},
    {I_IMUL, 2, {REG64,IMMEDIATE,0,0,0}, nasm_bytecodes+13594, IF_X64|IF_SM},
    ITEMPLATE_END
};

static const struct itemplate instrux_IN[] = {
    {I_IN, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+19183, IF_8086|IF_SB},
    {I_IN, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+17397, IF_8086|IF_SB},
    {I_IN, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+17402, IF_386|IF_SB},
    {I_IN, 2, {REG_AL,REG_DX,0,0,0}, nasm_bytecodes+19658, IF_8086},
    {I_IN, 2, {REG_AX,REG_DX,0,0,0}, nasm_bytecodes+19187, IF_8086},
    {I_IN, 2, {REG_EAX,REG_DX,0,0,0}, nasm_bytecodes+19191, IF_386},
    ITEMPLATE_END
};

static const struct itemplate instrux_INC[] = {
    {I_INC, 1, {REG16,0,0,0,0}, nasm_bytecodes+19195, IF_8086|IF_NOLONG},
    {I_INC, 1, {REG32,0,0,0,0}, nasm_bytecodes+19199, IF_386|IF_NOLONG},
    {I_INC, 1, {RM_GPR|BITS8,0,0,0,0}, nasm_bytecodes+19203, IF_8086},
    {I_INC, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+17407, IF_8086},
    {I_INC, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+17412, IF_386},
    {I_INC, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+17417, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_INCBIN[] = {
    ITEMPLATE_END
};

static const struct itemplate instrux_INSB[] = {
    {I_INSB, 0, {0,0,0,0,0}, nasm_bytecodes+19661, IF_186},
    ITEMPLATE_END
};

static const struct itemplate instrux_INSD[] = {
    {I_INSD, 0, {0,0,0,0,0}, nasm_bytecodes+19207, IF_386},
    ITEMPLATE_END
};

static const struct itemplate instrux_INSERTPS[] = {
    {I_INSERTPS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6142, IF_SSE41|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_INSERTQ[] = {
    {I_INSERTQ, 4, {XMMREG,XMMREG,IMMEDIATE,IMMEDIATE,0}, nasm_bytecodes+6102, IF_SSE4A|IF_AMD},
    {I_INSERTQ, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+15460, IF_SSE4A|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_INSW[] = {
    {I_INSW, 0, {0,0,0,0,0}, nasm_bytecodes+19211, IF_186},
    ITEMPLATE_END
};

static const struct itemplate instrux_INT[] = {
    {I_INT, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+19215, IF_8086|IF_SB},
    ITEMPLATE_END
};

static const struct itemplate instrux_INT01[] = {
    {I_INT01, 0, {0,0,0,0,0}, nasm_bytecodes+19655, IF_386},
    ITEMPLATE_END
};

static const struct itemplate instrux_INT03[] = {
    {I_INT03, 0, {0,0,0,0,0}, nasm_bytecodes+19664, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_INT1[] = {
    {I_INT1, 0, {0,0,0,0,0}, nasm_bytecodes+19655, IF_386},
    ITEMPLATE_END
};

static const struct itemplate instrux_INT3[] = {
    {I_INT3, 0, {0,0,0,0,0}, nasm_bytecodes+19664, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_INTO[] = {
    {I_INTO, 0, {0,0,0,0,0}, nasm_bytecodes+19667, IF_8086|IF_NOLONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_INVD[] = {
    {I_INVD, 0, {0,0,0,0,0}, nasm_bytecodes+19219, IF_486|IF_PRIV},
    ITEMPLATE_END
};

static const struct itemplate instrux_INVEPT[] = {
    {I_INVEPT, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+6063, IF_VMX|IF_SO|IF_NOLONG},
    {I_INVEPT, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+6062, IF_VMX|IF_SO|IF_LONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_INVLPG[] = {
    {I_INVLPG, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17422, IF_486|IF_PRIV},
    ITEMPLATE_END
};

static const struct itemplate instrux_INVLPGA[] = {
    {I_INVLPGA, 2, {REG_AX,REG_ECX,0,0,0}, nasm_bytecodes+13600, IF_X86_64|IF_AMD|IF_NOLONG},
    {I_INVLPGA, 2, {REG_EAX,REG_ECX,0,0,0}, nasm_bytecodes+13606, IF_X86_64|IF_AMD},
    {I_INVLPGA, 2, {REG_RAX,REG_ECX,0,0,0}, nasm_bytecodes+7314, IF_X64|IF_AMD},
    {I_INVLPGA, 0, {0,0,0,0,0}, nasm_bytecodes+13607, IF_X86_64|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_INVVPID[] = {
    {I_INVVPID, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+6071, IF_VMX|IF_SO|IF_NOLONG},
    {I_INVVPID, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+6070, IF_VMX|IF_SO|IF_LONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_IRET[] = {
    {I_IRET, 0, {0,0,0,0,0}, nasm_bytecodes+19223, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_IRETD[] = {
    {I_IRETD, 0, {0,0,0,0,0}, nasm_bytecodes+19227, IF_386},
    ITEMPLATE_END
};

static const struct itemplate instrux_IRETQ[] = {
    {I_IRETQ, 0, {0,0,0,0,0}, nasm_bytecodes+19231, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_IRETW[] = {
    {I_IRETW, 0, {0,0,0,0,0}, nasm_bytecodes+19235, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_JCXZ[] = {
    {I_JCXZ, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+17427, IF_8086|IF_NOLONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_JECXZ[] = {
    {I_JECXZ, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+17432, IF_386},
    ITEMPLATE_END
};

static const struct itemplate instrux_JMP[] = {
    {I_JMP, 1, {IMMEDIATE|SHORT,0,0,0,0}, nasm_bytecodes+17438, IF_8086},
    {I_JMP, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+17437, IF_8086},
    {I_JMP, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+17442, IF_8086},
    {I_JMP, 1, {IMMEDIATE|NEAR,0,0,0,0}, nasm_bytecodes+17442, IF_8086},
    {I_JMP, 1, {IMMEDIATE|FAR,0,0,0,0}, nasm_bytecodes+13612, IF_8086|IF_NOLONG},
    {I_JMP, 1, {IMMEDIATE|BITS16,0,0,0,0}, nasm_bytecodes+17447, IF_8086},
    {I_JMP, 1, {IMMEDIATE|BITS16|NEAR,0,0,0,0}, nasm_bytecodes+17447, IF_8086},
    {I_JMP, 1, {IMMEDIATE|BITS16|FAR,0,0,0,0}, nasm_bytecodes+13618, IF_8086|IF_NOLONG},
    {I_JMP, 1, {IMMEDIATE|BITS32,0,0,0,0}, nasm_bytecodes+17452, IF_386},
    {I_JMP, 1, {IMMEDIATE|BITS32|NEAR,0,0,0,0}, nasm_bytecodes+17452, IF_386},
    {I_JMP, 1, {IMMEDIATE|BITS32|FAR,0,0,0,0}, nasm_bytecodes+13624, IF_386|IF_NOLONG},
    {I_JMP, 2, {IMMEDIATE|COLON,IMMEDIATE,0,0,0}, nasm_bytecodes+13630, IF_8086|IF_NOLONG},
    {I_JMP, 2, {IMMEDIATE|BITS16|COLON,IMMEDIATE,0,0,0}, nasm_bytecodes+13636, IF_8086|IF_NOLONG},
    {I_JMP, 2, {IMMEDIATE|COLON,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+13636, IF_8086|IF_NOLONG},
    {I_JMP, 2, {IMMEDIATE|BITS32|COLON,IMMEDIATE,0,0,0}, nasm_bytecodes+13642, IF_386|IF_NOLONG},
    {I_JMP, 2, {IMMEDIATE|COLON,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+13642, IF_386|IF_NOLONG},
    {I_JMP, 1, {MEMORY|FAR,0,0,0,0}, nasm_bytecodes+17457, IF_8086|IF_NOLONG},
    {I_JMP, 1, {MEMORY|FAR,0,0,0,0}, nasm_bytecodes+17462, IF_X64},
    {I_JMP, 1, {MEMORY|BITS16|FAR,0,0,0,0}, nasm_bytecodes+17467, IF_8086},
    {I_JMP, 1, {MEMORY|BITS32|FAR,0,0,0,0}, nasm_bytecodes+17472, IF_386},
    {I_JMP, 1, {MEMORY|BITS64|FAR,0,0,0,0}, nasm_bytecodes+17462, IF_X64},
    {I_JMP, 1, {MEMORY|NEAR,0,0,0,0}, nasm_bytecodes+17477, IF_8086},
    {I_JMP, 1, {MEMORY|BITS16|NEAR,0,0,0,0}, nasm_bytecodes+17482, IF_8086},
    {I_JMP, 1, {MEMORY|BITS32|NEAR,0,0,0,0}, nasm_bytecodes+17487, IF_386|IF_NOLONG},
    {I_JMP, 1, {MEMORY|BITS64|NEAR,0,0,0,0}, nasm_bytecodes+17492, IF_X64},
    {I_JMP, 1, {REG16,0,0,0,0}, nasm_bytecodes+17482, IF_8086},
    {I_JMP, 1, {REG32,0,0,0,0}, nasm_bytecodes+17487, IF_386|IF_NOLONG},
    {I_JMP, 1, {REG64,0,0,0,0}, nasm_bytecodes+17492, IF_X64},
    {I_JMP, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17477, IF_8086},
    {I_JMP, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+17482, IF_8086},
    {I_JMP, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+17487, IF_386|IF_NOLONG},
    {I_JMP, 1, {MEMORY|BITS64,0,0,0,0}, nasm_bytecodes+17492, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_JMPE[] = {
    {I_JMPE, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+13648, IF_IA64},
    {I_JMPE, 1, {IMMEDIATE|BITS16,0,0,0,0}, nasm_bytecodes+13654, IF_IA64},
    {I_JMPE, 1, {IMMEDIATE|BITS32,0,0,0,0}, nasm_bytecodes+13660, IF_IA64},
    {I_JMPE, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+13666, IF_IA64},
    {I_JMPE, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+13672, IF_IA64},
    ITEMPLATE_END
};

static const struct itemplate instrux_JRCXZ[] = {
    {I_JRCXZ, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+17433, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_LAHF[] = {
    {I_LAHF, 0, {0,0,0,0,0}, nasm_bytecodes+19670, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_LAR[] = {
    {I_LAR, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+13678, IF_286|IF_PROT|IF_SW},
    {I_LAR, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+13678, IF_286|IF_PROT},
    {I_LAR, 2, {REG16,REG32,0,0,0}, nasm_bytecodes+13678, IF_386|IF_PROT},
    {I_LAR, 2, {REG16,REG64,0,0,0}, nasm_bytecodes+7321, IF_X64|IF_PROT},
    {I_LAR, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+13684, IF_386|IF_PROT|IF_SW},
    {I_LAR, 2, {REG32,REG16,0,0,0}, nasm_bytecodes+13684, IF_386|IF_PROT},
    {I_LAR, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+13684, IF_386|IF_PROT},
    {I_LAR, 2, {REG32,REG64,0,0,0}, nasm_bytecodes+7328, IF_X64|IF_PROT},
    {I_LAR, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+13690, IF_X64|IF_PROT|IF_SW},
    {I_LAR, 2, {REG64,REG16,0,0,0}, nasm_bytecodes+13690, IF_X64|IF_PROT},
    {I_LAR, 2, {REG64,REG32,0,0,0}, nasm_bytecodes+13690, IF_X64|IF_PROT},
    {I_LAR, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+13690, IF_X64|IF_PROT},
    ITEMPLATE_END
};

static const struct itemplate instrux_LDDQU[] = {
    {I_LDDQU, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+15418, IF_PRESCOTT|IF_SSE3|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_LDMXCSR[] = {
    {I_LDMXCSR, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18472, IF_KATMAI|IF_SSE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_LDS[] = {
    {I_LDS, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+17497, IF_8086|IF_NOLONG},
    {I_LDS, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+17502, IF_386|IF_NOLONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_LEA[] = {
    {I_LEA, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+17507, IF_8086},
    {I_LEA, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+17512, IF_386},
    {I_LEA, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+17517, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_LEAVE[] = {
    {I_LEAVE, 0, {0,0,0,0,0}, nasm_bytecodes+17754, IF_186},
    ITEMPLATE_END
};

static const struct itemplate instrux_LES[] = {
    {I_LES, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+17522, IF_8086|IF_NOLONG},
    {I_LES, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+17527, IF_386|IF_NOLONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_LFENCE[] = {
    {I_LFENCE, 0, {0,0,0,0,0}, nasm_bytecodes+17532, IF_X64|IF_AMD},
    {I_LFENCE, 0, {0,0,0,0,0}, nasm_bytecodes+17532, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_LFS[] = {
    {I_LFS, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+13696, IF_386},
    {I_LFS, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+13702, IF_386},
    ITEMPLATE_END
};

static const struct itemplate instrux_LGDT[] = {
    {I_LGDT, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17537, IF_286|IF_PRIV},
    ITEMPLATE_END
};

static const struct itemplate instrux_LGS[] = {
    {I_LGS, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+13708, IF_386},
    {I_LGS, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+13714, IF_386},
    ITEMPLATE_END
};

static const struct itemplate instrux_LIDT[] = {
    {I_LIDT, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17542, IF_286|IF_PRIV},
    ITEMPLATE_END
};

static const struct itemplate instrux_LLDT[] = {
    {I_LLDT, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17547, IF_286|IF_PROT|IF_PRIV},
    {I_LLDT, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+17547, IF_286|IF_PROT|IF_PRIV},
    {I_LLDT, 1, {REG16,0,0,0,0}, nasm_bytecodes+17547, IF_286|IF_PROT|IF_PRIV},
    ITEMPLATE_END
};

static const struct itemplate instrux_LMSW[] = {
    {I_LMSW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17552, IF_286|IF_PRIV},
    {I_LMSW, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+17552, IF_286|IF_PRIV},
    {I_LMSW, 1, {REG16,0,0,0,0}, nasm_bytecodes+17552, IF_286|IF_PRIV},
    ITEMPLATE_END
};

static const struct itemplate instrux_LOADALL[] = {
    {I_LOADALL, 0, {0,0,0,0,0}, nasm_bytecodes+19239, IF_386|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_LOADALL286[] = {
    {I_LOADALL286, 0, {0,0,0,0,0}, nasm_bytecodes+19243, IF_286|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_LODSB[] = {
    {I_LODSB, 0, {0,0,0,0,0}, nasm_bytecodes+19673, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_LODSD[] = {
    {I_LODSD, 0, {0,0,0,0,0}, nasm_bytecodes+19247, IF_386},
    ITEMPLATE_END
};

static const struct itemplate instrux_LODSQ[] = {
    {I_LODSQ, 0, {0,0,0,0,0}, nasm_bytecodes+19251, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_LODSW[] = {
    {I_LODSW, 0, {0,0,0,0,0}, nasm_bytecodes+19255, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_LOOP[] = {
    {I_LOOP, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+17557, IF_8086},
    {I_LOOP, 2, {IMMEDIATE,REG_CX,0,0,0}, nasm_bytecodes+17562, IF_8086|IF_NOLONG},
    {I_LOOP, 2, {IMMEDIATE,REG_ECX,0,0,0}, nasm_bytecodes+17567, IF_386},
    {I_LOOP, 2, {IMMEDIATE,REG_RCX,0,0,0}, nasm_bytecodes+17572, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_LOOPE[] = {
    {I_LOOPE, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+17577, IF_8086},
    {I_LOOPE, 2, {IMMEDIATE,REG_CX,0,0,0}, nasm_bytecodes+17582, IF_8086|IF_NOLONG},
    {I_LOOPE, 2, {IMMEDIATE,REG_ECX,0,0,0}, nasm_bytecodes+17587, IF_386},
    {I_LOOPE, 2, {IMMEDIATE,REG_RCX,0,0,0}, nasm_bytecodes+17592, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_LOOPNE[] = {
    {I_LOOPNE, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+17597, IF_8086},
    {I_LOOPNE, 2, {IMMEDIATE,REG_CX,0,0,0}, nasm_bytecodes+17602, IF_8086|IF_NOLONG},
    {I_LOOPNE, 2, {IMMEDIATE,REG_ECX,0,0,0}, nasm_bytecodes+17607, IF_386},
    {I_LOOPNE, 2, {IMMEDIATE,REG_RCX,0,0,0}, nasm_bytecodes+17612, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_LOOPNZ[] = {
    {I_LOOPNZ, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+17597, IF_8086},
    {I_LOOPNZ, 2, {IMMEDIATE,REG_CX,0,0,0}, nasm_bytecodes+17602, IF_8086|IF_NOLONG},
    {I_LOOPNZ, 2, {IMMEDIATE,REG_ECX,0,0,0}, nasm_bytecodes+17607, IF_386},
    {I_LOOPNZ, 2, {IMMEDIATE,REG_RCX,0,0,0}, nasm_bytecodes+17612, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_LOOPZ[] = {
    {I_LOOPZ, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+17577, IF_8086},
    {I_LOOPZ, 2, {IMMEDIATE,REG_CX,0,0,0}, nasm_bytecodes+17582, IF_8086|IF_NOLONG},
    {I_LOOPZ, 2, {IMMEDIATE,REG_ECX,0,0,0}, nasm_bytecodes+17587, IF_386},
    {I_LOOPZ, 2, {IMMEDIATE,REG_RCX,0,0,0}, nasm_bytecodes+17592, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_LSL[] = {
    {I_LSL, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+13720, IF_286|IF_PROT|IF_SW},
    {I_LSL, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+13720, IF_286|IF_PROT},
    {I_LSL, 2, {REG16,REG32,0,0,0}, nasm_bytecodes+13720, IF_386|IF_PROT},
    {I_LSL, 2, {REG16,REG64,0,0,0}, nasm_bytecodes+7335, IF_X64|IF_PROT},
    {I_LSL, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+13726, IF_386|IF_PROT|IF_SW},
    {I_LSL, 2, {REG32,REG16,0,0,0}, nasm_bytecodes+13726, IF_386|IF_PROT},
    {I_LSL, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+13726, IF_386|IF_PROT},
    {I_LSL, 2, {REG32,REG64,0,0,0}, nasm_bytecodes+7342, IF_X64|IF_PROT},
    {I_LSL, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+13732, IF_X64|IF_PROT|IF_SW},
    {I_LSL, 2, {REG64,REG16,0,0,0}, nasm_bytecodes+13732, IF_X64|IF_PROT},
    {I_LSL, 2, {REG64,REG32,0,0,0}, nasm_bytecodes+13732, IF_X64|IF_PROT},
    {I_LSL, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+13732, IF_X64|IF_PROT},
    ITEMPLATE_END
};

static const struct itemplate instrux_LSS[] = {
    {I_LSS, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+13738, IF_386},
    {I_LSS, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+13744, IF_386},
    ITEMPLATE_END
};

static const struct itemplate instrux_LTR[] = {
    {I_LTR, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17617, IF_286|IF_PROT|IF_PRIV},
    {I_LTR, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+17617, IF_286|IF_PROT|IF_PRIV},
    {I_LTR, 1, {REG16,0,0,0,0}, nasm_bytecodes+17617, IF_286|IF_PROT|IF_PRIV},
    ITEMPLATE_END
};

static const struct itemplate instrux_LZCNT[] = {
    {I_LZCNT, 2, {REG16,RM_GPR|BITS16,0,0,0}, nasm_bytecodes+8399, IF_P6|IF_AMD},
    {I_LZCNT, 2, {REG32,RM_GPR|BITS32,0,0,0}, nasm_bytecodes+8406, IF_P6|IF_AMD},
    {I_LZCNT, 2, {REG64,RM_GPR|BITS64,0,0,0}, nasm_bytecodes+8413, IF_P6|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_MASKMOVDQU[] = {
    {I_MASKMOVDQU, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14650, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_MASKMOVQ[] = {
    {I_MASKMOVQ, 2, {MMXREG,MMXREG,0,0,0}, nasm_bytecodes+14632, IF_KATMAI|IF_MMX},
    ITEMPLATE_END
};

static const struct itemplate instrux_MAXPD[] = {
    {I_MAXPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15208, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_MAXPS[] = {
    {I_MAXPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14428, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_MAXSD[] = {
    {I_MAXSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15214, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_MAXSS[] = {
    {I_MAXSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14434, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_MFENCE[] = {
    {I_MFENCE, 0, {0,0,0,0,0}, nasm_bytecodes+17622, IF_X64|IF_AMD},
    {I_MFENCE, 0, {0,0,0,0,0}, nasm_bytecodes+17622, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_MINPD[] = {
    {I_MINPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15220, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_MINPS[] = {
    {I_MINPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14440, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_MINSD[] = {
    {I_MINSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15226, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_MINSS[] = {
    {I_MINSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14446, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_MONITOR[] = {
    {I_MONITOR, 0, {0,0,0,0,0}, nasm_bytecodes+17627, IF_PRESCOTT},
    {I_MONITOR, 3, {REG_EAX,REG_ECX,REG_EDX,0,0}, nasm_bytecodes+17627, IF_PRESCOTT},
    ITEMPLATE_END
};

static const struct itemplate instrux_MONTMUL[] = {
    {I_MONTMUL, 0, {0,0,0,0,0}, nasm_bytecodes+15520, IF_PENT|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOV[] = {
    {I_MOV, 2, {MEMORY,REG_SREG,0,0,0}, nasm_bytecodes+17638, IF_8086|IF_SM},
    {I_MOV, 2, {REG16,REG_SREG,0,0,0}, nasm_bytecodes+17632, IF_8086},
    {I_MOV, 2, {REG32,REG_SREG,0,0,0}, nasm_bytecodes+17637, IF_386},
    {I_MOV, 2, {REG_SREG,MEMORY,0,0,0}, nasm_bytecodes+19259, IF_8086|IF_SM},
    {I_MOV, 2, {REG_SREG,REG16,0,0,0}, nasm_bytecodes+19259, IF_8086},
    {I_MOV, 2, {REG_SREG,REG32,0,0,0}, nasm_bytecodes+19259, IF_386},
    {I_MOV, 2, {REG_AL,MEM_OFFS,0,0,0}, nasm_bytecodes+19263, IF_8086|IF_SM},
    {I_MOV, 2, {REG_AX,MEM_OFFS,0,0,0}, nasm_bytecodes+17642, IF_8086|IF_SM},
    {I_MOV, 2, {REG_EAX,MEM_OFFS,0,0,0}, nasm_bytecodes+17647, IF_386|IF_SM},
    {I_MOV, 2, {REG_RAX,MEM_OFFS,0,0,0}, nasm_bytecodes+17652, IF_X64|IF_SM},
    {I_MOV, 2, {MEM_OFFS,REG_AL,0,0,0}, nasm_bytecodes+19267, IF_8086|IF_SM},
    {I_MOV, 2, {MEM_OFFS,REG_AX,0,0,0}, nasm_bytecodes+17657, IF_8086|IF_SM},
    {I_MOV, 2, {MEM_OFFS,REG_EAX,0,0,0}, nasm_bytecodes+17662, IF_386|IF_SM},
    {I_MOV, 2, {MEM_OFFS,REG_RAX,0,0,0}, nasm_bytecodes+17667, IF_X64|IF_SM},
    {I_MOV, 2, {REG32,REG_CREG,0,0,0}, nasm_bytecodes+13750, IF_386|IF_PRIV|IF_NOLONG},
    {I_MOV, 2, {REG64,REG_CREG,0,0,0}, nasm_bytecodes+13756, IF_X64|IF_PRIV},
    {I_MOV, 2, {REG_CREG,REG32,0,0,0}, nasm_bytecodes+13762, IF_386|IF_PRIV|IF_NOLONG},
    {I_MOV, 2, {REG_CREG,REG64,0,0,0}, nasm_bytecodes+13768, IF_X64|IF_PRIV},
    {I_MOV, 2, {REG32,REG_DREG,0,0,0}, nasm_bytecodes+13775, IF_386|IF_PRIV|IF_NOLONG},
    {I_MOV, 2, {REG64,REG_DREG,0,0,0}, nasm_bytecodes+13774, IF_X64|IF_PRIV},
    {I_MOV, 2, {REG_DREG,REG32,0,0,0}, nasm_bytecodes+13781, IF_386|IF_PRIV|IF_NOLONG},
    {I_MOV, 2, {REG_DREG,REG64,0,0,0}, nasm_bytecodes+13780, IF_X64|IF_PRIV},
    {I_MOV, 2, {REG32,REG_TREG,0,0,0}, nasm_bytecodes+17672, IF_386|IF_NOLONG},
    {I_MOV, 2, {REG_TREG,REG32,0,0,0}, nasm_bytecodes+17677, IF_386|IF_NOLONG},
    {I_MOV, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+19271, IF_8086|IF_SM},
    {I_MOV, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+19271, IF_8086},
    {I_MOV, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+17682, IF_8086|IF_SM},
    {I_MOV, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+17682, IF_8086},
    {I_MOV, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+17687, IF_386|IF_SM},
    {I_MOV, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+17687, IF_386},
    {I_MOV, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+17692, IF_X64|IF_SM},
    {I_MOV, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+17692, IF_X64},
    {I_MOV, 2, {REG8,MEMORY,0,0,0}, nasm_bytecodes+19275, IF_8086|IF_SM},
    {I_MOV, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+19275, IF_8086},
    {I_MOV, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+17697, IF_8086|IF_SM},
    {I_MOV, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+17697, IF_8086},
    {I_MOV, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+17702, IF_386|IF_SM},
    {I_MOV, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+17702, IF_386},
    {I_MOV, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+17707, IF_X64|IF_SM},
    {I_MOV, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+17707, IF_X64},
    {I_MOV, 2, {REG8,IMMEDIATE,0,0,0}, nasm_bytecodes+19279, IF_8086|IF_SM},
    {I_MOV, 2, {REG16,IMMEDIATE,0,0,0}, nasm_bytecodes+17712, IF_8086|IF_SM},
    {I_MOV, 2, {REG32,IMMEDIATE,0,0,0}, nasm_bytecodes+17717, IF_386|IF_SM},
    {I_MOV, 2, {REG64,IMMEDIATE,0,0,0}, nasm_bytecodes+17722, IF_X64|IF_SM},
    {I_MOV, 2, {REG64,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+13786, IF_X64},
    {I_MOV, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+17727, IF_8086|IF_SM},
    {I_MOV, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+13792, IF_8086|IF_SM},
    {I_MOV, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+13798, IF_386|IF_SM},
    {I_MOV, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+13786, IF_X64|IF_SM},
    {I_MOV, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+17727, IF_8086|IF_SM},
    {I_MOV, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+13792, IF_8086|IF_SM},
    {I_MOV, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+13798, IF_386|IF_SM},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVAPD[] = {
    {I_MOVAPD, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+15232, IF_WILLAMETTE|IF_SSE2},
    {I_MOVAPD, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+15238, IF_WILLAMETTE|IF_SSE2},
    {I_MOVAPD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+15244, IF_WILLAMETTE|IF_SSE2|IF_SO},
    {I_MOVAPD, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+15232, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVAPS[] = {
    {I_MOVAPS, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+14452, IF_KATMAI|IF_SSE},
    {I_MOVAPS, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+14458, IF_KATMAI|IF_SSE},
    {I_MOVAPS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14452, IF_KATMAI|IF_SSE},
    {I_MOVAPS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14458, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVBE[] = {
    {I_MOVBE, 2, {REG16,MEMORY|BITS16,0,0,0}, nasm_bytecodes+9617, IF_NEHALEM|IF_SM},
    {I_MOVBE, 2, {REG32,MEMORY|BITS32,0,0,0}, nasm_bytecodes+9624, IF_NEHALEM|IF_SM},
    {I_MOVBE, 2, {REG64,MEMORY|BITS64,0,0,0}, nasm_bytecodes+9631, IF_NEHALEM|IF_SM},
    {I_MOVBE, 2, {MEMORY|BITS16,REG16,0,0,0}, nasm_bytecodes+9638, IF_NEHALEM|IF_SM},
    {I_MOVBE, 2, {MEMORY|BITS32,REG32,0,0,0}, nasm_bytecodes+9645, IF_NEHALEM|IF_SM},
    {I_MOVBE, 2, {MEMORY|BITS64,REG64,0,0,0}, nasm_bytecodes+9652, IF_NEHALEM|IF_SM},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVD[] = {
    {I_MOVD, 2, {MMXREG,MEMORY,0,0,0}, nasm_bytecodes+13804, IF_PENT|IF_MMX|IF_SD},
    {I_MOVD, 2, {MMXREG,REG32,0,0,0}, nasm_bytecodes+13804, IF_PENT|IF_MMX},
    {I_MOVD, 2, {MEMORY,MMXREG,0,0,0}, nasm_bytecodes+13810, IF_PENT|IF_MMX|IF_SD},
    {I_MOVD, 2, {REG32,MMXREG,0,0,0}, nasm_bytecodes+13810, IF_PENT|IF_MMX},
    {I_MOVD, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+7349, IF_X64|IF_SD},
    {I_MOVD, 2, {XMMREG,REG32,0,0,0}, nasm_bytecodes+7349, IF_X64},
    {I_MOVD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+7356, IF_X64|IF_SD},
    {I_MOVD, 2, {REG32,XMMREG,0,0,0}, nasm_bytecodes+7356, IF_X64|IF_SSE},
    {I_MOVD, 2, {XMMREG,REG32,0,0,0}, nasm_bytecodes+14668, IF_WILLAMETTE|IF_SSE2},
    {I_MOVD, 2, {REG32,XMMREG,0,0,0}, nasm_bytecodes+14674, IF_WILLAMETTE|IF_SSE2},
    {I_MOVD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+14674, IF_WILLAMETTE|IF_SSE2|IF_SD},
    {I_MOVD, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+14668, IF_WILLAMETTE|IF_SSE2|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVDDUP[] = {
    {I_MOVDDUP, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15424, IF_PRESCOTT|IF_SSE3},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVDQ2Q[] = {
    {I_MOVDQ2Q, 2, {MMXREG,XMMREG,0,0,0}, nasm_bytecodes+7986, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVDQA[] = {
    {I_MOVDQA, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14680, IF_WILLAMETTE|IF_SSE2},
    {I_MOVDQA, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+14686, IF_WILLAMETTE|IF_SSE2|IF_SO},
    {I_MOVDQA, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+14680, IF_WILLAMETTE|IF_SSE2|IF_SO},
    {I_MOVDQA, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14692, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVDQU[] = {
    {I_MOVDQU, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14698, IF_WILLAMETTE|IF_SSE2},
    {I_MOVDQU, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+14704, IF_WILLAMETTE|IF_SSE2|IF_SO},
    {I_MOVDQU, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+14698, IF_WILLAMETTE|IF_SSE2|IF_SO},
    {I_MOVDQU, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14710, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVHLPS[] = {
    {I_MOVHLPS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14284, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVHPD[] = {
    {I_MOVHPD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+15250, IF_WILLAMETTE|IF_SSE2},
    {I_MOVHPD, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+15256, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVHPS[] = {
    {I_MOVHPS, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+14464, IF_KATMAI|IF_SSE},
    {I_MOVHPS, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+14470, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVLHPS[] = {
    {I_MOVLHPS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14464, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVLPD[] = {
    {I_MOVLPD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+15262, IF_WILLAMETTE|IF_SSE2},
    {I_MOVLPD, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+15268, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVLPS[] = {
    {I_MOVLPS, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+14284, IF_KATMAI|IF_SSE},
    {I_MOVLPS, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+14476, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVMSKPD[] = {
    {I_MOVMSKPD, 2, {REG32,XMMREG,0,0,0}, nasm_bytecodes+15274, IF_WILLAMETTE|IF_SSE2},
    {I_MOVMSKPD, 2, {REG64,XMMREG,0,0,0}, nasm_bytecodes+8161, IF_X64|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVMSKPS[] = {
    {I_MOVMSKPS, 2, {REG32,XMMREG,0,0,0}, nasm_bytecodes+14482, IF_KATMAI|IF_SSE},
    {I_MOVMSKPS, 2, {REG64,XMMREG,0,0,0}, nasm_bytecodes+7895, IF_X64|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVNTDQ[] = {
    {I_MOVNTDQ, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+14656, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVNTDQA[] = {
    {I_MOVNTDQA, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+8434, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVNTI[] = {
    {I_MOVNTI, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+7980, IF_WILLAMETTE|IF_SD},
    {I_MOVNTI, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+7979, IF_X64|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVNTPD[] = {
    {I_MOVNTPD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+14662, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVNTPS[] = {
    {I_MOVNTPS, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+14488, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVNTQ[] = {
    {I_MOVNTQ, 2, {MEMORY,MMXREG,0,0,0}, nasm_bytecodes+14638, IF_KATMAI|IF_MMX|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVNTSD[] = {
    {I_MOVNTSD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+15466, IF_SSE4A|IF_AMD|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVNTSS[] = {
    {I_MOVNTSS, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+15472, IF_SSE4A|IF_AMD|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVQ[] = {
    {I_MOVQ, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7363, IF_PENT|IF_MMX|IF_SQ},
    {I_MOVQ, 2, {RM_MMX,MMXREG,0,0,0}, nasm_bytecodes+7370, IF_PENT|IF_MMX|IF_SQ},
    {I_MOVQ, 2, {MMXREG,RM_GPR|BITS64,0,0,0}, nasm_bytecodes+13804, IF_X64|IF_MMX},
    {I_MOVQ, 2, {RM_GPR|BITS64,MMXREG,0,0,0}, nasm_bytecodes+13810, IF_X64|IF_MMX},
    {I_MOVQ, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14716, IF_WILLAMETTE|IF_SSE2},
    {I_MOVQ, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14722, IF_WILLAMETTE|IF_SSE2},
    {I_MOVQ, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+14728, IF_WILLAMETTE|IF_SSE2|IF_SQ},
    {I_MOVQ, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+14716, IF_WILLAMETTE|IF_SSE2|IF_SQ},
    {I_MOVQ, 2, {XMMREG,RM_GPR|BITS64,0,0,0}, nasm_bytecodes+7993, IF_X64|IF_SSE2},
    {I_MOVQ, 2, {RM_GPR|BITS64,XMMREG,0,0,0}, nasm_bytecodes+8000, IF_X64|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVQ2DQ[] = {
    {I_MOVQ2DQ, 2, {XMMREG,MMXREG,0,0,0}, nasm_bytecodes+14734, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVSB[] = {
    {I_MOVSB, 0, {0,0,0,0,0}, nasm_bytecodes+5659, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVSD[] = {
    {I_MOVSD, 0, {0,0,0,0,0}, nasm_bytecodes+19283, IF_386},
    {I_MOVSD, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+15280, IF_WILLAMETTE|IF_SSE2},
    {I_MOVSD, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+15286, IF_WILLAMETTE|IF_SSE2},
    {I_MOVSD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+15292, IF_WILLAMETTE|IF_SSE2},
    {I_MOVSD, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+15280, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVSHDUP[] = {
    {I_MOVSHDUP, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15430, IF_PRESCOTT|IF_SSE3},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVSLDUP[] = {
    {I_MOVSLDUP, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15436, IF_PRESCOTT|IF_SSE3},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVSQ[] = {
    {I_MOVSQ, 0, {0,0,0,0,0}, nasm_bytecodes+19287, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVSS[] = {
    {I_MOVSS, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+14494, IF_KATMAI|IF_SSE},
    {I_MOVSS, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+14500, IF_KATMAI|IF_SSE},
    {I_MOVSS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14494, IF_KATMAI|IF_SSE},
    {I_MOVSS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14500, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVSW[] = {
    {I_MOVSW, 0, {0,0,0,0,0}, nasm_bytecodes+19291, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVSX[] = {
    {I_MOVSX, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+13816, IF_386|IF_SB},
    {I_MOVSX, 2, {REG16,REG8,0,0,0}, nasm_bytecodes+13816, IF_386},
    {I_MOVSX, 2, {REG32,RM_GPR|BITS8,0,0,0}, nasm_bytecodes+13822, IF_386},
    {I_MOVSX, 2, {REG32,RM_GPR|BITS16,0,0,0}, nasm_bytecodes+13828, IF_386},
    {I_MOVSX, 2, {REG64,RM_GPR|BITS8,0,0,0}, nasm_bytecodes+13834, IF_X64},
    {I_MOVSX, 2, {REG64,RM_GPR|BITS16,0,0,0}, nasm_bytecodes+13840, IF_X64},
    {I_MOVSX, 2, {REG64,RM_GPR|BITS32,0,0,0}, nasm_bytecodes+17732, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVSXD[] = {
    {I_MOVSXD, 2, {REG64,RM_GPR|BITS32,0,0,0}, nasm_bytecodes+17732, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVUPD[] = {
    {I_MOVUPD, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+15298, IF_WILLAMETTE|IF_SSE2},
    {I_MOVUPD, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+15304, IF_WILLAMETTE|IF_SSE2},
    {I_MOVUPD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+15310, IF_WILLAMETTE|IF_SSE2|IF_SO},
    {I_MOVUPD, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+15298, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVUPS[] = {
    {I_MOVUPS, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+14506, IF_KATMAI|IF_SSE},
    {I_MOVUPS, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+14512, IF_KATMAI|IF_SSE},
    {I_MOVUPS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14506, IF_KATMAI|IF_SSE},
    {I_MOVUPS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+14512, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_MOVZX[] = {
    {I_MOVZX, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+13846, IF_386|IF_SB},
    {I_MOVZX, 2, {REG16,REG8,0,0,0}, nasm_bytecodes+13846, IF_386},
    {I_MOVZX, 2, {REG32,RM_GPR|BITS8,0,0,0}, nasm_bytecodes+13852, IF_386},
    {I_MOVZX, 2, {REG32,RM_GPR|BITS16,0,0,0}, nasm_bytecodes+13858, IF_386},
    {I_MOVZX, 2, {REG64,RM_GPR|BITS8,0,0,0}, nasm_bytecodes+13864, IF_X64},
    {I_MOVZX, 2, {REG64,RM_GPR|BITS16,0,0,0}, nasm_bytecodes+13870, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_MPSADBW[] = {
    {I_MPSADBW, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6150, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_MUL[] = {
    {I_MUL, 1, {RM_GPR|BITS8,0,0,0,0}, nasm_bytecodes+19295, IF_8086},
    {I_MUL, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+17737, IF_8086},
    {I_MUL, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+17742, IF_386},
    {I_MUL, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+17747, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_MULPD[] = {
    {I_MULPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15316, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_MULPS[] = {
    {I_MULPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14518, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_MULSD[] = {
    {I_MULSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15322, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_MULSS[] = {
    {I_MULSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14524, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_MWAIT[] = {
    {I_MWAIT, 0, {0,0,0,0,0}, nasm_bytecodes+17752, IF_PRESCOTT},
    {I_MWAIT, 2, {REG_EAX,REG_ECX,0,0,0}, nasm_bytecodes+17752, IF_PRESCOTT},
    ITEMPLATE_END
};

static const struct itemplate instrux_NEG[] = {
    {I_NEG, 1, {RM_GPR|BITS8,0,0,0,0}, nasm_bytecodes+19299, IF_8086},
    {I_NEG, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+17757, IF_8086},
    {I_NEG, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+17762, IF_386},
    {I_NEG, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+17767, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_NOP[] = {
    {I_NOP, 0, {0,0,0,0,0}, nasm_bytecodes+19303, IF_8086},
    {I_NOP, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+13876, IF_P6},
    {I_NOP, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+13882, IF_P6},
    {I_NOP, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+13888, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_NOT[] = {
    {I_NOT, 1, {RM_GPR|BITS8,0,0,0,0}, nasm_bytecodes+19307, IF_8086},
    {I_NOT, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+17772, IF_8086},
    {I_NOT, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+17777, IF_386},
    {I_NOT, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+17782, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_OR[] = {
    {I_OR, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+19311, IF_8086|IF_SM},
    {I_OR, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+19311, IF_8086},
    {I_OR, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+17787, IF_8086|IF_SM},
    {I_OR, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+17787, IF_8086},
    {I_OR, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+17792, IF_386|IF_SM},
    {I_OR, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+17792, IF_386},
    {I_OR, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+17797, IF_X64|IF_SM},
    {I_OR, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+17797, IF_X64},
    {I_OR, 2, {REG8,MEMORY,0,0,0}, nasm_bytecodes+12357, IF_8086|IF_SM},
    {I_OR, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+12357, IF_8086},
    {I_OR, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+17802, IF_8086|IF_SM},
    {I_OR, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+17802, IF_8086},
    {I_OR, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+17807, IF_386|IF_SM},
    {I_OR, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+17807, IF_386},
    {I_OR, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+17812, IF_X64|IF_SM},
    {I_OR, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+17812, IF_X64},
    {I_OR, 2, {RM_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13894, IF_8086},
    {I_OR, 2, {RM_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13900, IF_386},
    {I_OR, 2, {RM_GPR|BITS64,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+13906, IF_X64},
    {I_OR, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+19315, IF_8086|IF_SM},
    {I_OR, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+17817, IF_8086|IF_SM},
    {I_OR, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+17822, IF_386|IF_SM},
    {I_OR, 2, {REG_RAX,IMMEDIATE,0,0,0}, nasm_bytecodes+17827, IF_X64|IF_SM},
    {I_OR, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+17832, IF_8086|IF_SM},
    {I_OR, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+13912, IF_8086|IF_SM},
    {I_OR, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+13918, IF_386|IF_SM},
    {I_OR, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+13924, IF_X64|IF_SM},
    {I_OR, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+17832, IF_8086|IF_SM},
    {I_OR, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+13912, IF_8086|IF_SM},
    {I_OR, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+13918, IF_386|IF_SM},
    ITEMPLATE_END
};

static const struct itemplate instrux_ORPD[] = {
    {I_ORPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15328, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_ORPS[] = {
    {I_ORPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14530, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_OUT[] = {
    {I_OUT, 2, {IMMEDIATE,REG_AL,0,0,0}, nasm_bytecodes+19319, IF_8086|IF_SB},
    {I_OUT, 2, {IMMEDIATE,REG_AX,0,0,0}, nasm_bytecodes+17837, IF_8086|IF_SB},
    {I_OUT, 2, {IMMEDIATE,REG_EAX,0,0,0}, nasm_bytecodes+17842, IF_386|IF_SB},
    {I_OUT, 2, {REG_DX,REG_AL,0,0,0}, nasm_bytecodes+19676, IF_8086},
    {I_OUT, 2, {REG_DX,REG_AX,0,0,0}, nasm_bytecodes+19323, IF_8086},
    {I_OUT, 2, {REG_DX,REG_EAX,0,0,0}, nasm_bytecodes+19327, IF_386},
    ITEMPLATE_END
};

static const struct itemplate instrux_OUTSB[] = {
    {I_OUTSB, 0, {0,0,0,0,0}, nasm_bytecodes+19679, IF_186},
    ITEMPLATE_END
};

static const struct itemplate instrux_OUTSD[] = {
    {I_OUTSD, 0, {0,0,0,0,0}, nasm_bytecodes+19331, IF_386},
    ITEMPLATE_END
};

static const struct itemplate instrux_OUTSW[] = {
    {I_OUTSW, 0, {0,0,0,0,0}, nasm_bytecodes+19335, IF_186},
    ITEMPLATE_END
};

static const struct itemplate instrux_PABSB[] = {
    {I_PABSB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8189, IF_SSSE3|IF_MMX|IF_SQ},
    {I_PABSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8196, IF_SSSE3},
    ITEMPLATE_END
};

static const struct itemplate instrux_PABSD[] = {
    {I_PABSD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8217, IF_SSSE3|IF_MMX|IF_SQ},
    {I_PABSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8224, IF_SSSE3},
    ITEMPLATE_END
};

static const struct itemplate instrux_PABSW[] = {
    {I_PABSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8203, IF_SSSE3|IF_MMX|IF_SQ},
    {I_PABSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8210, IF_SSSE3},
    ITEMPLATE_END
};

static const struct itemplate instrux_PACKSSDW[] = {
    {I_PACKSSDW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7377, IF_PENT|IF_MMX|IF_SQ},
    {I_PACKSSDW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14746, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PACKSSWB[] = {
    {I_PACKSSWB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7384, IF_PENT|IF_MMX|IF_SQ},
    {I_PACKSSWB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14740, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PACKUSDW[] = {
    {I_PACKUSDW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8441, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_PACKUSWB[] = {
    {I_PACKUSWB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7391, IF_PENT|IF_MMX|IF_SQ},
    {I_PACKUSWB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14752, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PADDB[] = {
    {I_PADDB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7398, IF_PENT|IF_MMX|IF_SQ},
    {I_PADDB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14758, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PADDD[] = {
    {I_PADDD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7405, IF_PENT|IF_MMX|IF_SQ},
    {I_PADDD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14770, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PADDQ[] = {
    {I_PADDQ, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8007, IF_WILLAMETTE|IF_SSE2|IF_SO},
    {I_PADDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14776, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PADDSB[] = {
    {I_PADDSB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7412, IF_PENT|IF_MMX|IF_SQ},
    {I_PADDSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14782, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PADDSIW[] = {
    {I_PADDSIW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+13930, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_PADDSW[] = {
    {I_PADDSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7419, IF_PENT|IF_MMX|IF_SQ},
    {I_PADDSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14788, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PADDUSB[] = {
    {I_PADDUSB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7426, IF_PENT|IF_MMX|IF_SQ},
    {I_PADDUSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14794, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PADDUSW[] = {
    {I_PADDUSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7433, IF_PENT|IF_MMX|IF_SQ},
    {I_PADDUSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14800, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PADDW[] = {
    {I_PADDW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7440, IF_PENT|IF_MMX|IF_SQ},
    {I_PADDW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14764, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PALIGNR[] = {
    {I_PALIGNR, 3, {MMXREG,RM_MMX,IMMEDIATE,0,0}, nasm_bytecodes+6078, IF_SSSE3|IF_MMX|IF_SQ},
    {I_PALIGNR, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6086, IF_SSSE3},
    ITEMPLATE_END
};

static const struct itemplate instrux_PAND[] = {
    {I_PAND, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7447, IF_PENT|IF_MMX|IF_SQ},
    {I_PAND, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14806, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PANDN[] = {
    {I_PANDN, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7454, IF_PENT|IF_MMX|IF_SQ},
    {I_PANDN, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14812, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PAUSE[] = {
    {I_PAUSE, 0, {0,0,0,0,0}, nasm_bytecodes+17847, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_PAVEB[] = {
    {I_PAVEB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+13936, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_PAVGB[] = {
    {I_PAVGB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7909, IF_KATMAI|IF_MMX|IF_SQ},
    {I_PAVGB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14818, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PAVGUSB[] = {
    {I_PAVGUSB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5598, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PAVGW[] = {
    {I_PAVGW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7916, IF_KATMAI|IF_MMX|IF_SQ},
    {I_PAVGW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14824, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PBLENDVB[] = {
    {I_PBLENDVB, 3, {XMMREG,RM_XMM,XMM0,0,0}, nasm_bytecodes+8448, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_PBLENDW[] = {
    {I_PBLENDW, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6158, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCLMULHQHQDQ[] = {
    {I_PCLMULHQHQDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5013, IF_SSE|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCLMULHQLQDQ[] = {
    {I_PCLMULHQLQDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4995, IF_SSE|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCLMULLQHQDQ[] = {
    {I_PCLMULLQHQDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+5004, IF_SSE|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCLMULLQLQDQ[] = {
    {I_PCLMULLQLQDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4986, IF_SSE|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCLMULQDQ[] = {
    {I_PCLMULQDQ, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+7222, IF_SSE|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCMOV[] = {
    {I_PCMOV, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+9162, IF_SSE5|IF_AMD},
    {I_PCMOV, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+9169, IF_SSE5|IF_AMD},
    {I_PCMOV, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9176, IF_SSE5|IF_AMD},
    {I_PCMOV, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+9183, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCMPEQB[] = {
    {I_PCMPEQB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7461, IF_PENT|IF_MMX|IF_SQ},
    {I_PCMPEQB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14830, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCMPEQD[] = {
    {I_PCMPEQD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7468, IF_PENT|IF_MMX|IF_SQ},
    {I_PCMPEQD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14842, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCMPEQQ[] = {
    {I_PCMPEQQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8455, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCMPEQW[] = {
    {I_PCMPEQW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7475, IF_PENT|IF_MMX|IF_SQ},
    {I_PCMPEQW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14836, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCMPESTRI[] = {
    {I_PCMPESTRI, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6246, IF_SSE42},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCMPESTRM[] = {
    {I_PCMPESTRM, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6254, IF_SSE42},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCMPGTB[] = {
    {I_PCMPGTB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7482, IF_PENT|IF_MMX|IF_SQ},
    {I_PCMPGTB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14848, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCMPGTD[] = {
    {I_PCMPGTD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7489, IF_PENT|IF_MMX|IF_SQ},
    {I_PCMPGTD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14860, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCMPGTQ[] = {
    {I_PCMPGTQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8630, IF_SSE42},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCMPGTW[] = {
    {I_PCMPGTW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7496, IF_PENT|IF_MMX|IF_SQ},
    {I_PCMPGTW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14854, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCMPISTRI[] = {
    {I_PCMPISTRI, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6262, IF_SSE42},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCMPISTRM[] = {
    {I_PCMPISTRM, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6270, IF_SSE42},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMB[] = {
    {I_PCOMB, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6310, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMD[] = {
    {I_PCOMD, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6326, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMEQB[] = {
    {I_PCOMEQB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+648, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMEQD[] = {
    {I_PCOMEQD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+792, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMEQQ[] = {
    {I_PCOMEQQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+864, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMEQUB[] = {
    {I_PCOMEQUB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+936, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMEQUD[] = {
    {I_PCOMEQUD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1080, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMEQUQ[] = {
    {I_PCOMEQUQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1152, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMEQUW[] = {
    {I_PCOMEQUW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1008, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMEQW[] = {
    {I_PCOMEQW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+720, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMFALSEB[] = {
    {I_PCOMFALSEB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+666, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMFALSED[] = {
    {I_PCOMFALSED, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+810, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMFALSEQ[] = {
    {I_PCOMFALSEQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+882, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMFALSEUB[] = {
    {I_PCOMFALSEUB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+954, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMFALSEUD[] = {
    {I_PCOMFALSEUD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1098, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMFALSEUQ[] = {
    {I_PCOMFALSEUQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1170, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMFALSEUW[] = {
    {I_PCOMFALSEUW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1026, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMFALSEW[] = {
    {I_PCOMFALSEW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+738, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMGEB[] = {
    {I_PCOMGEB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+639, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMGED[] = {
    {I_PCOMGED, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+783, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMGEQ[] = {
    {I_PCOMGEQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+855, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMGEUB[] = {
    {I_PCOMGEUB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+927, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMGEUD[] = {
    {I_PCOMGEUD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1071, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMGEUQ[] = {
    {I_PCOMGEUQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1143, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMGEUW[] = {
    {I_PCOMGEUW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+999, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMGEW[] = {
    {I_PCOMGEW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+711, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMGTB[] = {
    {I_PCOMGTB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+630, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMGTD[] = {
    {I_PCOMGTD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+774, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMGTQ[] = {
    {I_PCOMGTQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+846, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMGTUB[] = {
    {I_PCOMGTUB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+918, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMGTUD[] = {
    {I_PCOMGTUD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1062, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMGTUQ[] = {
    {I_PCOMGTUQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1134, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMGTUW[] = {
    {I_PCOMGTUW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+990, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMGTW[] = {
    {I_PCOMGTW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+702, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMLEB[] = {
    {I_PCOMLEB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+621, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMLED[] = {
    {I_PCOMLED, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+765, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMLEQ[] = {
    {I_PCOMLEQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+837, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMLEUB[] = {
    {I_PCOMLEUB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+909, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMLEUD[] = {
    {I_PCOMLEUD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1053, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMLEUQ[] = {
    {I_PCOMLEUQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1125, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMLEUW[] = {
    {I_PCOMLEUW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+981, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMLEW[] = {
    {I_PCOMLEW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+693, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMLTB[] = {
    {I_PCOMLTB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+612, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMLTD[] = {
    {I_PCOMLTD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+756, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMLTQ[] = {
    {I_PCOMLTQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+828, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMLTUB[] = {
    {I_PCOMLTUB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+900, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMLTUD[] = {
    {I_PCOMLTUD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1044, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMLTUQ[] = {
    {I_PCOMLTUQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1116, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMLTUW[] = {
    {I_PCOMLTUW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+972, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMLTW[] = {
    {I_PCOMLTW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+684, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMNEQB[] = {
    {I_PCOMNEQB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+657, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMNEQD[] = {
    {I_PCOMNEQD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+801, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMNEQQ[] = {
    {I_PCOMNEQQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+873, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMNEQUB[] = {
    {I_PCOMNEQUB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+945, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMNEQUD[] = {
    {I_PCOMNEQUD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1089, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMNEQUQ[] = {
    {I_PCOMNEQUQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1161, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMNEQUW[] = {
    {I_PCOMNEQUW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1017, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMNEQW[] = {
    {I_PCOMNEQW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+729, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMQ[] = {
    {I_PCOMQ, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6334, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMTRUEB[] = {
    {I_PCOMTRUEB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+675, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMTRUED[] = {
    {I_PCOMTRUED, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+819, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMTRUEQ[] = {
    {I_PCOMTRUEQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+891, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMTRUEUB[] = {
    {I_PCOMTRUEUB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+963, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMTRUEUD[] = {
    {I_PCOMTRUEUD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1107, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMTRUEUQ[] = {
    {I_PCOMTRUEUQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1179, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMTRUEUW[] = {
    {I_PCOMTRUEUW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1035, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMTRUEW[] = {
    {I_PCOMTRUEW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+747, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMUB[] = {
    {I_PCOMUB, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6342, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMUD[] = {
    {I_PCOMUD, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6358, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMUQ[] = {
    {I_PCOMUQ, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6366, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMUW[] = {
    {I_PCOMUW, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6350, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PCOMW[] = {
    {I_PCOMW, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6318, IF_SSE5|IF_AMD|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PDISTIB[] = {
    {I_PDISTIB, 2, {MMXREG,MEMORY,0,0,0}, nasm_bytecodes+15107, IF_PENT|IF_MMX|IF_SM|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_PERMPD[] = {
    {I_PERMPD, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+9134, IF_SSE5|IF_AMD},
    {I_PERMPD, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+9141, IF_SSE5|IF_AMD},
    {I_PERMPD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9148, IF_SSE5|IF_AMD},
    {I_PERMPD, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+9155, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PERMPS[] = {
    {I_PERMPS, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+9106, IF_SSE5|IF_AMD},
    {I_PERMPS, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+9113, IF_SSE5|IF_AMD},
    {I_PERMPS, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9120, IF_SSE5|IF_AMD},
    {I_PERMPS, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+9127, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PEXTRB[] = {
    {I_PEXTRB, 3, {REG32,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+10, IF_SSE41},
    {I_PEXTRB, 3, {MEMORY|BITS8,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+10, IF_SSE41},
    {I_PEXTRB, 3, {REG64,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+9, IF_SSE41|IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_PEXTRD[] = {
    {I_PEXTRD, 3, {RM_GPR|BITS32,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6166, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_PEXTRQ[] = {
    {I_PEXTRQ, 3, {RM_GPR|BITS64,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6166, IF_SSE41|IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_PEXTRW[] = {
    {I_PEXTRW, 3, {REG32,MMXREG,IMMEDIATE,0,0}, nasm_bytecodes+7923, IF_KATMAI|IF_MMX|IF_SB|IF_AR2},
    {I_PEXTRW, 3, {REG32,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+8014, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR2},
    {I_PEXTRW, 3, {REG32,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+19, IF_SSE41},
    {I_PEXTRW, 3, {MEMORY|BITS16,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+19, IF_SSE41},
    {I_PEXTRW, 3, {REG64,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+18, IF_SSE41|IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_PF2ID[] = {
    {I_PF2ID, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5606, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PF2IW[] = {
    {I_PF2IW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5886, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PFACC[] = {
    {I_PFACC, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5614, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PFADD[] = {
    {I_PFADD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5622, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PFCMPEQ[] = {
    {I_PFCMPEQ, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5630, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PFCMPGE[] = {
    {I_PFCMPGE, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5638, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PFCMPGT[] = {
    {I_PFCMPGT, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5646, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PFMAX[] = {
    {I_PFMAX, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5654, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PFMIN[] = {
    {I_PFMIN, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5662, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PFMUL[] = {
    {I_PFMUL, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5670, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PFNACC[] = {
    {I_PFNACC, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5894, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PFPNACC[] = {
    {I_PFPNACC, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5902, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PFRCP[] = {
    {I_PFRCP, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5678, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PFRCPIT1[] = {
    {I_PFRCPIT1, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5686, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PFRCPIT2[] = {
    {I_PFRCPIT2, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5694, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PFRCPV[] = {
    {I_PFRCPV, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+6406, IF_PENT|IF_3DNOW|IF_SQ|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_PFRSQIT1[] = {
    {I_PFRSQIT1, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5702, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PFRSQRT[] = {
    {I_PFRSQRT, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5710, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PFRSQRTV[] = {
    {I_PFRSQRTV, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+6414, IF_PENT|IF_3DNOW|IF_SQ|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_PFSUB[] = {
    {I_PFSUB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5718, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PFSUBR[] = {
    {I_PFSUBR, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5726, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PHADDBD[] = {
    {I_PHADDBD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9519, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PHADDBQ[] = {
    {I_PHADDBQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9526, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PHADDBW[] = {
    {I_PHADDBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9512, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PHADDD[] = {
    {I_PHADDD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8245, IF_SSSE3|IF_MMX|IF_SQ},
    {I_PHADDD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8252, IF_SSSE3},
    ITEMPLATE_END
};

static const struct itemplate instrux_PHADDDQ[] = {
    {I_PHADDDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9547, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PHADDSW[] = {
    {I_PHADDSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8259, IF_SSSE3|IF_MMX|IF_SQ},
    {I_PHADDSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8266, IF_SSSE3},
    ITEMPLATE_END
};

static const struct itemplate instrux_PHADDUBD[] = {
    {I_PHADDUBD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9561, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PHADDUBQ[] = {
    {I_PHADDUBQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9568, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PHADDUBW[] = {
    {I_PHADDUBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9554, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PHADDUDQ[] = {
    {I_PHADDUDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9589, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PHADDUWD[] = {
    {I_PHADDUWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9575, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PHADDUWQ[] = {
    {I_PHADDUWQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9582, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PHADDW[] = {
    {I_PHADDW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8231, IF_SSSE3|IF_MMX|IF_SQ},
    {I_PHADDW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8238, IF_SSSE3},
    ITEMPLATE_END
};

static const struct itemplate instrux_PHADDWD[] = {
    {I_PHADDWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9533, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PHADDWQ[] = {
    {I_PHADDWQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9540, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PHMINPOSUW[] = {
    {I_PHMINPOSUW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8462, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_PHSUBBW[] = {
    {I_PHSUBBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9596, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PHSUBD[] = {
    {I_PHSUBD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8287, IF_SSSE3|IF_MMX|IF_SQ},
    {I_PHSUBD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8294, IF_SSSE3},
    ITEMPLATE_END
};

static const struct itemplate instrux_PHSUBDQ[] = {
    {I_PHSUBDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9610, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PHSUBSW[] = {
    {I_PHSUBSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8301, IF_SSSE3|IF_MMX|IF_SQ},
    {I_PHSUBSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8308, IF_SSSE3},
    ITEMPLATE_END
};

static const struct itemplate instrux_PHSUBW[] = {
    {I_PHSUBW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8273, IF_SSSE3|IF_MMX|IF_SQ},
    {I_PHSUBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8280, IF_SSSE3},
    ITEMPLATE_END
};

static const struct itemplate instrux_PHSUBWD[] = {
    {I_PHSUBWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9603, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PI2FD[] = {
    {I_PI2FD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5734, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PI2FW[] = {
    {I_PI2FW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5910, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PINSRB[] = {
    {I_PINSRB, 3, {XMMREG,REG32,IMMEDIATE,0,0}, nasm_bytecodes+6174, IF_SSE41},
    {I_PINSRB, 3, {XMMREG,MEMORY|BITS8,IMMEDIATE,0,0}, nasm_bytecodes+6174, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_PINSRD[] = {
    {I_PINSRD, 3, {XMMREG,RM_GPR|BITS32,IMMEDIATE,0,0}, nasm_bytecodes+28, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_PINSRQ[] = {
    {I_PINSRQ, 3, {XMMREG,RM_GPR|BITS64,IMMEDIATE,0,0}, nasm_bytecodes+27, IF_SSE41|IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_PINSRW[] = {
    {I_PINSRW, 3, {MMXREG,REG16,IMMEDIATE,0,0}, nasm_bytecodes+7930, IF_KATMAI|IF_MMX|IF_SB|IF_AR2},
    {I_PINSRW, 3, {MMXREG,REG32,IMMEDIATE,0,0}, nasm_bytecodes+7930, IF_KATMAI|IF_MMX|IF_SB|IF_AR2},
    {I_PINSRW, 3, {MMXREG,MEMORY,IMMEDIATE,0,0}, nasm_bytecodes+7930, IF_KATMAI|IF_MMX|IF_SB|IF_AR2},
    {I_PINSRW, 3, {MMXREG,MEMORY|BITS16,IMMEDIATE,0,0}, nasm_bytecodes+7930, IF_KATMAI|IF_MMX|IF_SB|IF_AR2},
    {I_PINSRW, 3, {XMMREG,REG16,IMMEDIATE,0,0}, nasm_bytecodes+8021, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR2},
    {I_PINSRW, 3, {XMMREG,REG32,IMMEDIATE,0,0}, nasm_bytecodes+8021, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR2},
    {I_PINSRW, 3, {XMMREG,MEMORY,IMMEDIATE,0,0}, nasm_bytecodes+8021, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR2},
    {I_PINSRW, 3, {XMMREG,MEMORY|BITS16,IMMEDIATE,0,0}, nasm_bytecodes+8021, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR2},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMACHRIW[] = {
    {I_PMACHRIW, 2, {MMXREG,MEMORY,0,0,0}, nasm_bytecodes+15203, IF_PENT|IF_MMX|IF_SM|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMACSDD[] = {
    {I_PMACSDD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9253, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMACSDQH[] = {
    {I_PMACSDQH, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9281, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMACSDQL[] = {
    {I_PMACSDQL, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9267, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMACSSDD[] = {
    {I_PMACSSDD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9246, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMACSSDQH[] = {
    {I_PMACSSDQH, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9274, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMACSSDQL[] = {
    {I_PMACSSDQL, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9260, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMACSSWD[] = {
    {I_PMACSSWD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9232, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMACSSWW[] = {
    {I_PMACSSWW, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9218, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMACSWD[] = {
    {I_PMACSWD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9239, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMACSWW[] = {
    {I_PMACSWW, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9225, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMADCSSWD[] = {
    {I_PMADCSSWD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9288, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMADCSWD[] = {
    {I_PMADCSWD, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9295, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMADDUBSW[] = {
    {I_PMADDUBSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8315, IF_SSSE3|IF_MMX|IF_SQ},
    {I_PMADDUBSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8322, IF_SSSE3},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMADDWD[] = {
    {I_PMADDWD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7503, IF_PENT|IF_MMX|IF_SQ},
    {I_PMADDWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14866, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMAGW[] = {
    {I_PMAGW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+13942, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMAXSB[] = {
    {I_PMAXSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8469, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMAXSD[] = {
    {I_PMAXSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8476, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMAXSW[] = {
    {I_PMAXSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7937, IF_KATMAI|IF_MMX|IF_SQ},
    {I_PMAXSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14872, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMAXUB[] = {
    {I_PMAXUB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7944, IF_KATMAI|IF_MMX|IF_SQ},
    {I_PMAXUB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14878, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMAXUD[] = {
    {I_PMAXUD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8483, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMAXUW[] = {
    {I_PMAXUW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8490, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMINSB[] = {
    {I_PMINSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8497, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMINSD[] = {
    {I_PMINSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8504, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMINSW[] = {
    {I_PMINSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7951, IF_KATMAI|IF_MMX|IF_SQ},
    {I_PMINSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14884, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMINUB[] = {
    {I_PMINUB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7958, IF_KATMAI|IF_MMX|IF_SQ},
    {I_PMINUB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14890, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMINUD[] = {
    {I_PMINUD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8511, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMINUW[] = {
    {I_PMINUW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8518, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMOVMSKB[] = {
    {I_PMOVMSKB, 2, {REG32,MMXREG,0,0,0}, nasm_bytecodes+14644, IF_KATMAI|IF_MMX},
    {I_PMOVMSKB, 2, {REG32,XMMREG,0,0,0}, nasm_bytecodes+14896, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMOVSXBD[] = {
    {I_PMOVSXBD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8532, IF_SSE41|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMOVSXBQ[] = {
    {I_PMOVSXBQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8539, IF_SSE41|IF_SW},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMOVSXBW[] = {
    {I_PMOVSXBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8525, IF_SSE41|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMOVSXDQ[] = {
    {I_PMOVSXDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8560, IF_SSE41|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMOVSXWD[] = {
    {I_PMOVSXWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8546, IF_SSE41|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMOVSXWQ[] = {
    {I_PMOVSXWQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8553, IF_SSE41|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMOVZXBD[] = {
    {I_PMOVZXBD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8574, IF_SSE41|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMOVZXBQ[] = {
    {I_PMOVZXBQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8581, IF_SSE41|IF_SW},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMOVZXBW[] = {
    {I_PMOVZXBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8567, IF_SSE41|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMOVZXDQ[] = {
    {I_PMOVZXDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8602, IF_SSE41|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMOVZXWD[] = {
    {I_PMOVZXWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8588, IF_SSE41|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMOVZXWQ[] = {
    {I_PMOVZXWQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8595, IF_SSE41|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMULDQ[] = {
    {I_PMULDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8609, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMULHRIW[] = {
    {I_PMULHRIW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+13948, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMULHRSW[] = {
    {I_PMULHRSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8329, IF_SSSE3|IF_MMX|IF_SQ},
    {I_PMULHRSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8336, IF_SSSE3},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMULHRWA[] = {
    {I_PMULHRWA, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5742, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMULHRWC[] = {
    {I_PMULHRWC, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+13954, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMULHUW[] = {
    {I_PMULHUW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7965, IF_KATMAI|IF_MMX|IF_SQ},
    {I_PMULHUW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14902, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMULHW[] = {
    {I_PMULHW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7510, IF_PENT|IF_MMX|IF_SQ},
    {I_PMULHW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14908, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMULLD[] = {
    {I_PMULLD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8616, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMULLW[] = {
    {I_PMULLW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7517, IF_PENT|IF_MMX|IF_SQ},
    {I_PMULLW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14914, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMULUDQ[] = {
    {I_PMULUDQ, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8028, IF_WILLAMETTE|IF_SSE2|IF_SO},
    {I_PMULUDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14920, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMVGEZB[] = {
    {I_PMVGEZB, 2, {MMXREG,MEMORY,0,0,0}, nasm_bytecodes+15353, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMVLZB[] = {
    {I_PMVLZB, 2, {MMXREG,MEMORY,0,0,0}, nasm_bytecodes+15191, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMVNZB[] = {
    {I_PMVNZB, 2, {MMXREG,MEMORY,0,0,0}, nasm_bytecodes+15173, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_PMVZB[] = {
    {I_PMVZB, 2, {MMXREG,MEMORY,0,0,0}, nasm_bytecodes+15095, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_POP[] = {
    {I_POP, 1, {REG16,0,0,0,0}, nasm_bytecodes+19339, IF_8086},
    {I_POP, 1, {REG32,0,0,0,0}, nasm_bytecodes+19343, IF_386|IF_NOLONG},
    {I_POP, 1, {REG64,0,0,0,0}, nasm_bytecodes+19347, IF_X64},
    {I_POP, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+17852, IF_8086},
    {I_POP, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+17857, IF_386|IF_NOLONG},
    {I_POP, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+17862, IF_X64},
    {I_POP, 1, {REG_CS,0,0,0,0}, nasm_bytecodes+4389, IF_8086|IF_UNDOC},
    {I_POP, 1, {REG_DESS,0,0,0,0}, nasm_bytecodes+19157, IF_8086|IF_NOLONG},
    {I_POP, 1, {REG_FSGS,0,0,0,0}, nasm_bytecodes+19351, IF_386},
    ITEMPLATE_END
};

static const struct itemplate instrux_POPA[] = {
    {I_POPA, 0, {0,0,0,0,0}, nasm_bytecodes+19355, IF_186|IF_NOLONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_POPAD[] = {
    {I_POPAD, 0, {0,0,0,0,0}, nasm_bytecodes+19359, IF_386|IF_NOLONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_POPAW[] = {
    {I_POPAW, 0, {0,0,0,0,0}, nasm_bytecodes+19363, IF_186|IF_NOLONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_POPCNT[] = {
    {I_POPCNT, 2, {REG16,RM_GPR|BITS16,0,0,0}, nasm_bytecodes+8637, IF_NEHALEM},
    {I_POPCNT, 2, {REG32,RM_GPR|BITS32,0,0,0}, nasm_bytecodes+8644, IF_NEHALEM},
    {I_POPCNT, 2, {REG64,RM_GPR|BITS32,0,0,0}, nasm_bytecodes+8651, IF_NEHALEM|IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_POPF[] = {
    {I_POPF, 0, {0,0,0,0,0}, nasm_bytecodes+19367, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_POPFD[] = {
    {I_POPFD, 0, {0,0,0,0,0}, nasm_bytecodes+19371, IF_386|IF_NOLONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_POPFQ[] = {
    {I_POPFQ, 0, {0,0,0,0,0}, nasm_bytecodes+19371, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_POPFW[] = {
    {I_POPFW, 0, {0,0,0,0,0}, nasm_bytecodes+19375, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_POR[] = {
    {I_POR, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7524, IF_PENT|IF_MMX|IF_SQ},
    {I_POR, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14926, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PPERM[] = {
    {I_PPERM, 4, {XMMREG,SAME_AS|0,XMMREG,RM_XMM,0}, nasm_bytecodes+9190, IF_SSE5|IF_AMD},
    {I_PPERM, 4, {XMMREG,SAME_AS|0,RM_XMM,XMMREG,0}, nasm_bytecodes+9197, IF_SSE5|IF_AMD},
    {I_PPERM, 4, {XMMREG,XMMREG,RM_XMM,SAME_AS|0,0}, nasm_bytecodes+9204, IF_SSE5|IF_AMD},
    {I_PPERM, 4, {XMMREG,RM_XMM,XMMREG,SAME_AS|0,0}, nasm_bytecodes+9211, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PREFETCH[] = {
    {I_PREFETCH, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17867, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PREFETCHNTA[] = {
    {I_PREFETCHNTA, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+15551, IF_KATMAI},
    ITEMPLATE_END
};

static const struct itemplate instrux_PREFETCHT0[] = {
    {I_PREFETCHT0, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+15569, IF_KATMAI},
    ITEMPLATE_END
};

static const struct itemplate instrux_PREFETCHT1[] = {
    {I_PREFETCHT1, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+15587, IF_KATMAI},
    ITEMPLATE_END
};

static const struct itemplate instrux_PREFETCHT2[] = {
    {I_PREFETCHT2, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+15605, IF_KATMAI},
    ITEMPLATE_END
};

static const struct itemplate instrux_PREFETCHW[] = {
    {I_PREFETCHW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+17872, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PROTB[] = {
    {I_PROTB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9302, IF_SSE5|IF_AMD},
    {I_PROTB, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+9309, IF_SSE5|IF_AMD},
    {I_PROTB, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6374, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PROTD[] = {
    {I_PROTD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9330, IF_SSE5|IF_AMD},
    {I_PROTD, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+9337, IF_SSE5|IF_AMD},
    {I_PROTD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6390, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PROTQ[] = {
    {I_PROTQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9344, IF_SSE5|IF_AMD},
    {I_PROTQ, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+9351, IF_SSE5|IF_AMD},
    {I_PROTQ, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6398, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PROTW[] = {
    {I_PROTW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9316, IF_SSE5|IF_AMD},
    {I_PROTW, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+9323, IF_SSE5|IF_AMD},
    {I_PROTW, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6382, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSADBW[] = {
    {I_PSADBW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7972, IF_KATMAI|IF_MMX|IF_SQ},
    {I_PSADBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14932, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSHAB[] = {
    {I_PSHAB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9414, IF_SSE5|IF_AMD},
    {I_PSHAB, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+9421, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSHAD[] = {
    {I_PSHAD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9442, IF_SSE5|IF_AMD},
    {I_PSHAD, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+9449, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSHAQ[] = {
    {I_PSHAQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9456, IF_SSE5|IF_AMD},
    {I_PSHAQ, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+9463, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSHAW[] = {
    {I_PSHAW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9428, IF_SSE5|IF_AMD},
    {I_PSHAW, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+9435, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSHLB[] = {
    {I_PSHLB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9358, IF_SSE5|IF_AMD},
    {I_PSHLB, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+9365, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSHLD[] = {
    {I_PSHLD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9386, IF_SSE5|IF_AMD},
    {I_PSHLD, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+9393, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSHLQ[] = {
    {I_PSHLQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9400, IF_SSE5|IF_AMD},
    {I_PSHLQ, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+9407, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSHLW[] = {
    {I_PSHLW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9372, IF_SSE5|IF_AMD},
    {I_PSHLW, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+9379, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSHUFB[] = {
    {I_PSHUFB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8343, IF_SSSE3|IF_MMX|IF_SQ},
    {I_PSHUFB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8350, IF_SSSE3},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSHUFD[] = {
    {I_PSHUFD, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+8035, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR2},
    {I_PSHUFD, 3, {XMMREG,MEMORY,IMMEDIATE,0,0}, nasm_bytecodes+8035, IF_WILLAMETTE|IF_SSE2|IF_SM2|IF_SB|IF_AR2},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSHUFHW[] = {
    {I_PSHUFHW, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+8042, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR2},
    {I_PSHUFHW, 3, {XMMREG,MEMORY,IMMEDIATE,0,0}, nasm_bytecodes+8042, IF_WILLAMETTE|IF_SSE2|IF_SM2|IF_SB|IF_AR2},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSHUFLW[] = {
    {I_PSHUFLW, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+5926, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR2},
    {I_PSHUFLW, 3, {XMMREG,MEMORY,IMMEDIATE,0,0}, nasm_bytecodes+5926, IF_WILLAMETTE|IF_SSE2|IF_SM2|IF_SB|IF_AR2},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSHUFW[] = {
    {I_PSHUFW, 3, {MMXREG,RM_MMX,IMMEDIATE,0,0}, nasm_bytecodes+5878, IF_KATMAI|IF_MMX|IF_SM2|IF_SB|IF_AR2},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSIGNB[] = {
    {I_PSIGNB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8357, IF_SSSE3|IF_MMX|IF_SQ},
    {I_PSIGNB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8364, IF_SSSE3},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSIGND[] = {
    {I_PSIGND, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8385, IF_SSSE3|IF_MMX|IF_SQ},
    {I_PSIGND, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8392, IF_SSSE3},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSIGNW[] = {
    {I_PSIGNW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8371, IF_SSSE3|IF_MMX|IF_SQ},
    {I_PSIGNW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8378, IF_SSSE3},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSLLD[] = {
    {I_PSLLD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7531, IF_PENT|IF_MMX|IF_SQ},
    {I_PSLLD, 2, {MMXREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7538, IF_PENT|IF_MMX},
    {I_PSLLD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14944, IF_WILLAMETTE|IF_SSE2|IF_SO},
    {I_PSLLD, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+8063, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR1},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSLLDQ[] = {
    {I_PSLLDQ, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+8049, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR1},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSLLQ[] = {
    {I_PSLLQ, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7545, IF_PENT|IF_MMX|IF_SQ},
    {I_PSLLQ, 2, {MMXREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7552, IF_PENT|IF_MMX},
    {I_PSLLQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14950, IF_WILLAMETTE|IF_SSE2|IF_SO},
    {I_PSLLQ, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+8070, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR1},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSLLW[] = {
    {I_PSLLW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7559, IF_PENT|IF_MMX|IF_SQ},
    {I_PSLLW, 2, {MMXREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7566, IF_PENT|IF_MMX},
    {I_PSLLW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14938, IF_WILLAMETTE|IF_SSE2|IF_SO},
    {I_PSLLW, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+8056, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR1},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSRAD[] = {
    {I_PSRAD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7573, IF_PENT|IF_MMX|IF_SQ},
    {I_PSRAD, 2, {MMXREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7580, IF_PENT|IF_MMX},
    {I_PSRAD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14962, IF_WILLAMETTE|IF_SSE2|IF_SO},
    {I_PSRAD, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+8084, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR1},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSRAW[] = {
    {I_PSRAW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7587, IF_PENT|IF_MMX|IF_SQ},
    {I_PSRAW, 2, {MMXREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7594, IF_PENT|IF_MMX},
    {I_PSRAW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14956, IF_WILLAMETTE|IF_SSE2|IF_SO},
    {I_PSRAW, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+8077, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR1},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSRLD[] = {
    {I_PSRLD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7601, IF_PENT|IF_MMX|IF_SQ},
    {I_PSRLD, 2, {MMXREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7608, IF_PENT|IF_MMX},
    {I_PSRLD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14974, IF_WILLAMETTE|IF_SSE2|IF_SO},
    {I_PSRLD, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+8105, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR1},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSRLDQ[] = {
    {I_PSRLDQ, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+8091, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR1},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSRLQ[] = {
    {I_PSRLQ, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7615, IF_PENT|IF_MMX|IF_SQ},
    {I_PSRLQ, 2, {MMXREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7622, IF_PENT|IF_MMX},
    {I_PSRLQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14980, IF_WILLAMETTE|IF_SSE2|IF_SO},
    {I_PSRLQ, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+8112, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR1},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSRLW[] = {
    {I_PSRLW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7629, IF_PENT|IF_MMX|IF_SQ},
    {I_PSRLW, 2, {MMXREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7636, IF_PENT|IF_MMX},
    {I_PSRLW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14968, IF_WILLAMETTE|IF_SSE2|IF_SO},
    {I_PSRLW, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+8098, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR1},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSUBB[] = {
    {I_PSUBB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7643, IF_PENT|IF_MMX|IF_SQ},
    {I_PSUBB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14986, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSUBD[] = {
    {I_PSUBD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7650, IF_PENT|IF_MMX|IF_SQ},
    {I_PSUBD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14998, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSUBQ[] = {
    {I_PSUBQ, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+8119, IF_WILLAMETTE|IF_SSE2|IF_SO},
    {I_PSUBQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15004, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSUBSB[] = {
    {I_PSUBSB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7657, IF_PENT|IF_MMX|IF_SQ},
    {I_PSUBSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15010, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSUBSIW[] = {
    {I_PSUBSIW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+13960, IF_PENT|IF_MMX|IF_SQ|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSUBSW[] = {
    {I_PSUBSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7664, IF_PENT|IF_MMX|IF_SQ},
    {I_PSUBSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15016, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSUBUSB[] = {
    {I_PSUBUSB, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7671, IF_PENT|IF_MMX|IF_SQ},
    {I_PSUBUSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15022, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSUBUSW[] = {
    {I_PSUBUSW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7678, IF_PENT|IF_MMX|IF_SQ},
    {I_PSUBUSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15028, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSUBW[] = {
    {I_PSUBW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7685, IF_PENT|IF_MMX|IF_SQ},
    {I_PSUBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14992, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PSWAPD[] = {
    {I_PSWAPD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+5918, IF_PENT|IF_3DNOW|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PTEST[] = {
    {I_PTEST, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+8623, IF_SSE41},
    ITEMPLATE_END
};

static const struct itemplate instrux_PUNPCKHBW[] = {
    {I_PUNPCKHBW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7692, IF_PENT|IF_MMX|IF_SQ},
    {I_PUNPCKHBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15034, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PUNPCKHDQ[] = {
    {I_PUNPCKHDQ, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7699, IF_PENT|IF_MMX|IF_SQ},
    {I_PUNPCKHDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15046, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PUNPCKHQDQ[] = {
    {I_PUNPCKHQDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15052, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PUNPCKHWD[] = {
    {I_PUNPCKHWD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7706, IF_PENT|IF_MMX|IF_SQ},
    {I_PUNPCKHWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15040, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PUNPCKLBW[] = {
    {I_PUNPCKLBW, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7713, IF_PENT|IF_MMX|IF_SQ},
    {I_PUNPCKLBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15058, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PUNPCKLDQ[] = {
    {I_PUNPCKLDQ, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7720, IF_PENT|IF_MMX|IF_SQ},
    {I_PUNPCKLDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15070, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PUNPCKLQDQ[] = {
    {I_PUNPCKLQDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15076, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PUNPCKLWD[] = {
    {I_PUNPCKLWD, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7727, IF_PENT|IF_MMX|IF_SQ},
    {I_PUNPCKLWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15064, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_PUSH[] = {
    {I_PUSH, 1, {REG16,0,0,0,0}, nasm_bytecodes+19379, IF_8086},
    {I_PUSH, 1, {REG32,0,0,0,0}, nasm_bytecodes+19383, IF_386|IF_NOLONG},
    {I_PUSH, 1, {REG64,0,0,0,0}, nasm_bytecodes+19387, IF_X64},
    {I_PUSH, 1, {RM_GPR|BITS16,0,0,0,0}, nasm_bytecodes+17877, IF_8086},
    {I_PUSH, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+17882, IF_386|IF_NOLONG},
    {I_PUSH, 1, {RM_GPR|BITS64,0,0,0,0}, nasm_bytecodes+17887, IF_X64},
    {I_PUSH, 1, {REG_CS,0,0,0,0}, nasm_bytecodes+19133, IF_8086|IF_NOLONG},
    {I_PUSH, 1, {REG_DESS,0,0,0,0}, nasm_bytecodes+19133, IF_8086|IF_NOLONG},
    {I_PUSH, 1, {REG_FSGS,0,0,0,0}, nasm_bytecodes+19391, IF_386},
    {I_PUSH, 1, {IMMEDIATE|BITS8,0,0,0,0}, nasm_bytecodes+19395, IF_186},
    {I_PUSH, 1, {IMMEDIATE|BITS16,0,0,0,0}, nasm_bytecodes+17892, IF_186|IF_AR0|IF_SZ},
    {I_PUSH, 1, {IMMEDIATE|BITS32,0,0,0,0}, nasm_bytecodes+17897, IF_386|IF_NOLONG|IF_AR0|IF_SZ},
    {I_PUSH, 1, {IMMEDIATE|BITS32,0,0,0,0}, nasm_bytecodes+17897, IF_386|IF_NOLONG|IF_SD},
    {I_PUSH, 1, {IMMEDIATE|BITS64,0,0,0,0}, nasm_bytecodes+17902, IF_X64|IF_AR0|IF_SZ},
    ITEMPLATE_END
};

static const struct itemplate instrux_PUSHA[] = {
    {I_PUSHA, 0, {0,0,0,0,0}, nasm_bytecodes+19399, IF_186|IF_NOLONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_PUSHAD[] = {
    {I_PUSHAD, 0, {0,0,0,0,0}, nasm_bytecodes+19403, IF_386|IF_NOLONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_PUSHAW[] = {
    {I_PUSHAW, 0, {0,0,0,0,0}, nasm_bytecodes+19407, IF_186|IF_NOLONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_PUSHF[] = {
    {I_PUSHF, 0, {0,0,0,0,0}, nasm_bytecodes+19411, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_PUSHFD[] = {
    {I_PUSHFD, 0, {0,0,0,0,0}, nasm_bytecodes+19415, IF_386|IF_NOLONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_PUSHFQ[] = {
    {I_PUSHFQ, 0, {0,0,0,0,0}, nasm_bytecodes+19415, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_PUSHFW[] = {
    {I_PUSHFW, 0, {0,0,0,0,0}, nasm_bytecodes+19419, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_PXOR[] = {
    {I_PXOR, 2, {MMXREG,RM_MMX,0,0,0}, nasm_bytecodes+7734, IF_PENT|IF_MMX|IF_SQ},
    {I_PXOR, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15082, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_RCL[] = {
    {I_RCL, 2, {RM_GPR|BITS8,UNITY,0,0,0}, nasm_bytecodes+19423, IF_8086},
    {I_RCL, 2, {RM_GPR|BITS8,REG_CL,0,0,0}, nasm_bytecodes+19427, IF_8086},
    {I_RCL, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+17907, IF_186|IF_SB},
    {I_RCL, 2, {RM_GPR|BITS16,UNITY,0,0,0}, nasm_bytecodes+17912, IF_8086},
    {I_RCL, 2, {RM_GPR|BITS16,REG_CL,0,0,0}, nasm_bytecodes+17917, IF_8086},
    {I_RCL, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+13966, IF_186|IF_SB},
    {I_RCL, 2, {RM_GPR|BITS32,UNITY,0,0,0}, nasm_bytecodes+17922, IF_386},
    {I_RCL, 2, {RM_GPR|BITS32,REG_CL,0,0,0}, nasm_bytecodes+17927, IF_386},
    {I_RCL, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+13972, IF_386|IF_SB},
    {I_RCL, 2, {RM_GPR|BITS64,UNITY,0,0,0}, nasm_bytecodes+17932, IF_X64},
    {I_RCL, 2, {RM_GPR|BITS64,REG_CL,0,0,0}, nasm_bytecodes+17937, IF_X64},
    {I_RCL, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+13978, IF_X64|IF_SB},
    ITEMPLATE_END
};

static const struct itemplate instrux_RCPPS[] = {
    {I_RCPPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14536, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_RCPSS[] = {
    {I_RCPSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14542, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_RCR[] = {
    {I_RCR, 2, {RM_GPR|BITS8,UNITY,0,0,0}, nasm_bytecodes+19431, IF_8086},
    {I_RCR, 2, {RM_GPR|BITS8,REG_CL,0,0,0}, nasm_bytecodes+19435, IF_8086},
    {I_RCR, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+17942, IF_186|IF_SB},
    {I_RCR, 2, {RM_GPR|BITS16,UNITY,0,0,0}, nasm_bytecodes+17947, IF_8086},
    {I_RCR, 2, {RM_GPR|BITS16,REG_CL,0,0,0}, nasm_bytecodes+17952, IF_8086},
    {I_RCR, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+13984, IF_186|IF_SB},
    {I_RCR, 2, {RM_GPR|BITS32,UNITY,0,0,0}, nasm_bytecodes+17957, IF_386},
    {I_RCR, 2, {RM_GPR|BITS32,REG_CL,0,0,0}, nasm_bytecodes+17962, IF_386},
    {I_RCR, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+13990, IF_386|IF_SB},
    {I_RCR, 2, {RM_GPR|BITS64,UNITY,0,0,0}, nasm_bytecodes+17967, IF_X64},
    {I_RCR, 2, {RM_GPR|BITS64,REG_CL,0,0,0}, nasm_bytecodes+17972, IF_X64},
    {I_RCR, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+13996, IF_X64|IF_SB},
    ITEMPLATE_END
};

static const struct itemplate instrux_RDM[] = {
    {I_RDM, 0, {0,0,0,0,0}, nasm_bytecodes+18591, IF_P6|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_RDMSR[] = {
    {I_RDMSR, 0, {0,0,0,0,0}, nasm_bytecodes+19439, IF_PENT|IF_PRIV},
    ITEMPLATE_END
};

static const struct itemplate instrux_RDPMC[] = {
    {I_RDPMC, 0, {0,0,0,0,0}, nasm_bytecodes+19443, IF_P6},
    ITEMPLATE_END
};

static const struct itemplate instrux_RDSHR[] = {
    {I_RDSHR, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+14002, IF_P6|IF_CYRIX|IF_SMM},
    ITEMPLATE_END
};

static const struct itemplate instrux_RDTSC[] = {
    {I_RDTSC, 0, {0,0,0,0,0}, nasm_bytecodes+19447, IF_PENT},
    ITEMPLATE_END
};

static const struct itemplate instrux_RDTSCP[] = {
    {I_RDTSCP, 0, {0,0,0,0,0}, nasm_bytecodes+17977, IF_X86_64},
    ITEMPLATE_END
};

static const struct itemplate instrux_RESB[] = {
    {I_RESB, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+19033, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_RESD[] = {
    ITEMPLATE_END
};

static const struct itemplate instrux_RESO[] = {
    ITEMPLATE_END
};

static const struct itemplate instrux_RESQ[] = {
    ITEMPLATE_END
};

static const struct itemplate instrux_REST[] = {
    ITEMPLATE_END
};

static const struct itemplate instrux_RESW[] = {
    ITEMPLATE_END
};

static const struct itemplate instrux_RESY[] = {
    ITEMPLATE_END
};

static const struct itemplate instrux_RET[] = {
    {I_RET, 0, {0,0,0,0,0}, nasm_bytecodes+18524, IF_8086},
    {I_RET, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+19451, IF_8086|IF_SW},
    ITEMPLATE_END
};

static const struct itemplate instrux_RETF[] = {
    {I_RETF, 0, {0,0,0,0,0}, nasm_bytecodes+19682, IF_8086},
    {I_RETF, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+19455, IF_8086|IF_SW},
    ITEMPLATE_END
};

static const struct itemplate instrux_RETN[] = {
    {I_RETN, 0, {0,0,0,0,0}, nasm_bytecodes+18524, IF_8086},
    {I_RETN, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+19451, IF_8086|IF_SW},
    ITEMPLATE_END
};

static const struct itemplate instrux_ROL[] = {
    {I_ROL, 2, {RM_GPR|BITS8,UNITY,0,0,0}, nasm_bytecodes+19459, IF_8086},
    {I_ROL, 2, {RM_GPR|BITS8,REG_CL,0,0,0}, nasm_bytecodes+19463, IF_8086},
    {I_ROL, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+17982, IF_186|IF_SB},
    {I_ROL, 2, {RM_GPR|BITS16,UNITY,0,0,0}, nasm_bytecodes+17987, IF_8086},
    {I_ROL, 2, {RM_GPR|BITS16,REG_CL,0,0,0}, nasm_bytecodes+17992, IF_8086},
    {I_ROL, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+14008, IF_186|IF_SB},
    {I_ROL, 2, {RM_GPR|BITS32,UNITY,0,0,0}, nasm_bytecodes+17997, IF_386},
    {I_ROL, 2, {RM_GPR|BITS32,REG_CL,0,0,0}, nasm_bytecodes+18002, IF_386},
    {I_ROL, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+14014, IF_386|IF_SB},
    {I_ROL, 2, {RM_GPR|BITS64,UNITY,0,0,0}, nasm_bytecodes+18007, IF_X64},
    {I_ROL, 2, {RM_GPR|BITS64,REG_CL,0,0,0}, nasm_bytecodes+18012, IF_X64},
    {I_ROL, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+14020, IF_X64|IF_SB},
    ITEMPLATE_END
};

static const struct itemplate instrux_ROR[] = {
    {I_ROR, 2, {RM_GPR|BITS8,UNITY,0,0,0}, nasm_bytecodes+19467, IF_8086},
    {I_ROR, 2, {RM_GPR|BITS8,REG_CL,0,0,0}, nasm_bytecodes+19471, IF_8086},
    {I_ROR, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+18017, IF_186|IF_SB},
    {I_ROR, 2, {RM_GPR|BITS16,UNITY,0,0,0}, nasm_bytecodes+18022, IF_8086},
    {I_ROR, 2, {RM_GPR|BITS16,REG_CL,0,0,0}, nasm_bytecodes+18027, IF_8086},
    {I_ROR, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+14026, IF_186|IF_SB},
    {I_ROR, 2, {RM_GPR|BITS32,UNITY,0,0,0}, nasm_bytecodes+18032, IF_386},
    {I_ROR, 2, {RM_GPR|BITS32,REG_CL,0,0,0}, nasm_bytecodes+18037, IF_386},
    {I_ROR, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+14032, IF_386|IF_SB},
    {I_ROR, 2, {RM_GPR|BITS64,UNITY,0,0,0}, nasm_bytecodes+18042, IF_X64},
    {I_ROR, 2, {RM_GPR|BITS64,REG_CL,0,0,0}, nasm_bytecodes+18047, IF_X64},
    {I_ROR, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+14038, IF_X64|IF_SB},
    ITEMPLATE_END
};

static const struct itemplate instrux_ROUNDPD[] = {
    {I_ROUNDPD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6182, IF_SSE41},
    {I_ROUNDPD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6190, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_ROUNDPS[] = {
    {I_ROUNDPS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6190, IF_SSE41},
    {I_ROUNDPS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6190, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_ROUNDSD[] = {
    {I_ROUNDSD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6198, IF_SSE41},
    {I_ROUNDSD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6190, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_ROUNDSS[] = {
    {I_ROUNDSS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6206, IF_SSE41},
    {I_ROUNDSS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6190, IF_SSE5|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_RSDC[] = {
    {I_RSDC, 2, {REG_SREG,MEMORY|BITS80,0,0,0}, nasm_bytecodes+15461, IF_486|IF_CYRIX|IF_SMM},
    ITEMPLATE_END
};

static const struct itemplate instrux_RSLDT[] = {
    {I_RSLDT, 1, {MEMORY|BITS80,0,0,0,0}, nasm_bytecodes+18052, IF_486|IF_CYRIX|IF_SMM},
    ITEMPLATE_END
};

static const struct itemplate instrux_RSM[] = {
    {I_RSM, 0, {0,0,0,0,0}, nasm_bytecodes+19475, IF_PENT|IF_SMM},
    ITEMPLATE_END
};

static const struct itemplate instrux_RSQRTPS[] = {
    {I_RSQRTPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14548, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_RSQRTSS[] = {
    {I_RSQRTSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14554, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_RSTS[] = {
    {I_RSTS, 1, {MEMORY|BITS80,0,0,0,0}, nasm_bytecodes+18057, IF_486|IF_CYRIX|IF_SMM},
    ITEMPLATE_END
};

static const struct itemplate instrux_SAHF[] = {
    {I_SAHF, 0, {0,0,0,0,0}, nasm_bytecodes+5627, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_SAL[] = {
    {I_SAL, 2, {RM_GPR|BITS8,UNITY,0,0,0}, nasm_bytecodes+19479, IF_8086},
    {I_SAL, 2, {RM_GPR|BITS8,REG_CL,0,0,0}, nasm_bytecodes+19483, IF_8086},
    {I_SAL, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+18062, IF_186|IF_SB},
    {I_SAL, 2, {RM_GPR|BITS16,UNITY,0,0,0}, nasm_bytecodes+18067, IF_8086},
    {I_SAL, 2, {RM_GPR|BITS16,REG_CL,0,0,0}, nasm_bytecodes+18072, IF_8086},
    {I_SAL, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+14044, IF_186|IF_SB},
    {I_SAL, 2, {RM_GPR|BITS32,UNITY,0,0,0}, nasm_bytecodes+18077, IF_386},
    {I_SAL, 2, {RM_GPR|BITS32,REG_CL,0,0,0}, nasm_bytecodes+18082, IF_386},
    {I_SAL, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+14050, IF_386|IF_SB},
    {I_SAL, 2, {RM_GPR|BITS64,UNITY,0,0,0}, nasm_bytecodes+18087, IF_X64},
    {I_SAL, 2, {RM_GPR|BITS64,REG_CL,0,0,0}, nasm_bytecodes+18092, IF_X64},
    {I_SAL, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+14056, IF_X64|IF_SB},
    ITEMPLATE_END
};

static const struct itemplate instrux_SALC[] = {
    {I_SALC, 0, {0,0,0,0,0}, nasm_bytecodes+19685, IF_8086|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_SAR[] = {
    {I_SAR, 2, {RM_GPR|BITS8,UNITY,0,0,0}, nasm_bytecodes+19487, IF_8086},
    {I_SAR, 2, {RM_GPR|BITS8,REG_CL,0,0,0}, nasm_bytecodes+19491, IF_8086},
    {I_SAR, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+18097, IF_186|IF_SB},
    {I_SAR, 2, {RM_GPR|BITS16,UNITY,0,0,0}, nasm_bytecodes+18102, IF_8086},
    {I_SAR, 2, {RM_GPR|BITS16,REG_CL,0,0,0}, nasm_bytecodes+18107, IF_8086},
    {I_SAR, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+14062, IF_186|IF_SB},
    {I_SAR, 2, {RM_GPR|BITS32,UNITY,0,0,0}, nasm_bytecodes+18112, IF_386},
    {I_SAR, 2, {RM_GPR|BITS32,REG_CL,0,0,0}, nasm_bytecodes+18117, IF_386},
    {I_SAR, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+14068, IF_386|IF_SB},
    {I_SAR, 2, {RM_GPR|BITS64,UNITY,0,0,0}, nasm_bytecodes+18122, IF_X64},
    {I_SAR, 2, {RM_GPR|BITS64,REG_CL,0,0,0}, nasm_bytecodes+18127, IF_X64},
    {I_SAR, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+14074, IF_X64|IF_SB},
    ITEMPLATE_END
};

static const struct itemplate instrux_SBB[] = {
    {I_SBB, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+19495, IF_8086|IF_SM},
    {I_SBB, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+19495, IF_8086},
    {I_SBB, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+18132, IF_8086|IF_SM},
    {I_SBB, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+18132, IF_8086},
    {I_SBB, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+18137, IF_386|IF_SM},
    {I_SBB, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+18137, IF_386},
    {I_SBB, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+18142, IF_X64|IF_SM},
    {I_SBB, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+18142, IF_X64},
    {I_SBB, 2, {REG8,MEMORY,0,0,0}, nasm_bytecodes+10061, IF_8086|IF_SM},
    {I_SBB, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+10061, IF_8086},
    {I_SBB, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+18147, IF_8086|IF_SM},
    {I_SBB, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+18147, IF_8086},
    {I_SBB, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+18152, IF_386|IF_SM},
    {I_SBB, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+18152, IF_386},
    {I_SBB, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+18157, IF_X64|IF_SM},
    {I_SBB, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+18157, IF_X64},
    {I_SBB, 2, {RM_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+14080, IF_8086},
    {I_SBB, 2, {RM_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+14086, IF_386},
    {I_SBB, 2, {RM_GPR|BITS64,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+14092, IF_X64},
    {I_SBB, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+19499, IF_8086|IF_SM},
    {I_SBB, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+18162, IF_8086|IF_SM},
    {I_SBB, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+18167, IF_386|IF_SM},
    {I_SBB, 2, {REG_RAX,IMMEDIATE,0,0,0}, nasm_bytecodes+18172, IF_X64|IF_SM},
    {I_SBB, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+18177, IF_8086|IF_SM},
    {I_SBB, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+14098, IF_8086|IF_SM},
    {I_SBB, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+14104, IF_386|IF_SM},
    {I_SBB, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+14110, IF_X64|IF_SM},
    {I_SBB, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+18177, IF_8086|IF_SM},
    {I_SBB, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+14098, IF_8086|IF_SM},
    {I_SBB, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+14104, IF_386|IF_SM},
    ITEMPLATE_END
};

static const struct itemplate instrux_SCASB[] = {
    {I_SCASB, 0, {0,0,0,0,0}, nasm_bytecodes+19503, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_SCASD[] = {
    {I_SCASD, 0, {0,0,0,0,0}, nasm_bytecodes+18182, IF_386},
    ITEMPLATE_END
};

static const struct itemplate instrux_SCASQ[] = {
    {I_SCASQ, 0, {0,0,0,0,0}, nasm_bytecodes+18187, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_SCASW[] = {
    {I_SCASW, 0, {0,0,0,0,0}, nasm_bytecodes+18192, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_SFENCE[] = {
    {I_SFENCE, 0, {0,0,0,0,0}, nasm_bytecodes+18197, IF_X64|IF_AMD},
    {I_SFENCE, 0, {0,0,0,0,0}, nasm_bytecodes+18197, IF_KATMAI},
    ITEMPLATE_END
};

static const struct itemplate instrux_SGDT[] = {
    {I_SGDT, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18202, IF_286},
    ITEMPLATE_END
};

static const struct itemplate instrux_SHL[] = {
    {I_SHL, 2, {RM_GPR|BITS8,UNITY,0,0,0}, nasm_bytecodes+19479, IF_8086},
    {I_SHL, 2, {RM_GPR|BITS8,REG_CL,0,0,0}, nasm_bytecodes+19483, IF_8086},
    {I_SHL, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+18062, IF_186|IF_SB},
    {I_SHL, 2, {RM_GPR|BITS16,UNITY,0,0,0}, nasm_bytecodes+18067, IF_8086},
    {I_SHL, 2, {RM_GPR|BITS16,REG_CL,0,0,0}, nasm_bytecodes+18072, IF_8086},
    {I_SHL, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+14044, IF_186|IF_SB},
    {I_SHL, 2, {RM_GPR|BITS32,UNITY,0,0,0}, nasm_bytecodes+18077, IF_386},
    {I_SHL, 2, {RM_GPR|BITS32,REG_CL,0,0,0}, nasm_bytecodes+18082, IF_386},
    {I_SHL, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+14050, IF_386|IF_SB},
    {I_SHL, 2, {RM_GPR|BITS64,UNITY,0,0,0}, nasm_bytecodes+18087, IF_X64},
    {I_SHL, 2, {RM_GPR|BITS64,REG_CL,0,0,0}, nasm_bytecodes+18092, IF_X64},
    {I_SHL, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+14056, IF_X64|IF_SB},
    ITEMPLATE_END
};

static const struct itemplate instrux_SHLD[] = {
    {I_SHLD, 3, {MEMORY,REG16,IMMEDIATE,0,0}, nasm_bytecodes+7741, IF_386|IF_SM2|IF_SB|IF_AR2},
    {I_SHLD, 3, {REG16,REG16,IMMEDIATE,0,0}, nasm_bytecodes+7741, IF_386|IF_SM2|IF_SB|IF_AR2},
    {I_SHLD, 3, {MEMORY,REG32,IMMEDIATE,0,0}, nasm_bytecodes+7748, IF_386|IF_SM2|IF_SB|IF_AR2},
    {I_SHLD, 3, {REG32,REG32,IMMEDIATE,0,0}, nasm_bytecodes+7748, IF_386|IF_SM2|IF_SB|IF_AR2},
    {I_SHLD, 3, {MEMORY,REG64,IMMEDIATE,0,0}, nasm_bytecodes+7755, IF_X64|IF_SM2|IF_SB|IF_AR2},
    {I_SHLD, 3, {REG64,REG64,IMMEDIATE,0,0}, nasm_bytecodes+7755, IF_X64|IF_SM2|IF_SB|IF_AR2},
    {I_SHLD, 3, {MEMORY,REG16,REG_CL,0,0}, nasm_bytecodes+14116, IF_386|IF_SM},
    {I_SHLD, 3, {REG16,REG16,REG_CL,0,0}, nasm_bytecodes+14116, IF_386},
    {I_SHLD, 3, {MEMORY,REG32,REG_CL,0,0}, nasm_bytecodes+14122, IF_386|IF_SM},
    {I_SHLD, 3, {REG32,REG32,REG_CL,0,0}, nasm_bytecodes+14122, IF_386},
    {I_SHLD, 3, {MEMORY,REG64,REG_CL,0,0}, nasm_bytecodes+14128, IF_X64|IF_SM},
    {I_SHLD, 3, {REG64,REG64,REG_CL,0,0}, nasm_bytecodes+14128, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_SHR[] = {
    {I_SHR, 2, {RM_GPR|BITS8,UNITY,0,0,0}, nasm_bytecodes+19507, IF_8086},
    {I_SHR, 2, {RM_GPR|BITS8,REG_CL,0,0,0}, nasm_bytecodes+19511, IF_8086},
    {I_SHR, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+18207, IF_186|IF_SB},
    {I_SHR, 2, {RM_GPR|BITS16,UNITY,0,0,0}, nasm_bytecodes+18212, IF_8086},
    {I_SHR, 2, {RM_GPR|BITS16,REG_CL,0,0,0}, nasm_bytecodes+18217, IF_8086},
    {I_SHR, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+14134, IF_186|IF_SB},
    {I_SHR, 2, {RM_GPR|BITS32,UNITY,0,0,0}, nasm_bytecodes+18222, IF_386},
    {I_SHR, 2, {RM_GPR|BITS32,REG_CL,0,0,0}, nasm_bytecodes+18227, IF_386},
    {I_SHR, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+14140, IF_386|IF_SB},
    {I_SHR, 2, {RM_GPR|BITS64,UNITY,0,0,0}, nasm_bytecodes+18232, IF_X64},
    {I_SHR, 2, {RM_GPR|BITS64,REG_CL,0,0,0}, nasm_bytecodes+18237, IF_X64},
    {I_SHR, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+14146, IF_X64|IF_SB},
    ITEMPLATE_END
};

static const struct itemplate instrux_SHRD[] = {
    {I_SHRD, 3, {MEMORY,REG16,IMMEDIATE,0,0}, nasm_bytecodes+7762, IF_386|IF_SM2|IF_SB|IF_AR2},
    {I_SHRD, 3, {REG16,REG16,IMMEDIATE,0,0}, nasm_bytecodes+7762, IF_386|IF_SM2|IF_SB|IF_AR2},
    {I_SHRD, 3, {MEMORY,REG32,IMMEDIATE,0,0}, nasm_bytecodes+7769, IF_386|IF_SM2|IF_SB|IF_AR2},
    {I_SHRD, 3, {REG32,REG32,IMMEDIATE,0,0}, nasm_bytecodes+7769, IF_386|IF_SM2|IF_SB|IF_AR2},
    {I_SHRD, 3, {MEMORY,REG64,IMMEDIATE,0,0}, nasm_bytecodes+7776, IF_X64|IF_SM2|IF_SB|IF_AR2},
    {I_SHRD, 3, {REG64,REG64,IMMEDIATE,0,0}, nasm_bytecodes+7776, IF_X64|IF_SM2|IF_SB|IF_AR2},
    {I_SHRD, 3, {MEMORY,REG16,REG_CL,0,0}, nasm_bytecodes+14152, IF_386|IF_SM},
    {I_SHRD, 3, {REG16,REG16,REG_CL,0,0}, nasm_bytecodes+14152, IF_386},
    {I_SHRD, 3, {MEMORY,REG32,REG_CL,0,0}, nasm_bytecodes+14158, IF_386|IF_SM},
    {I_SHRD, 3, {REG32,REG32,REG_CL,0,0}, nasm_bytecodes+14158, IF_386},
    {I_SHRD, 3, {MEMORY,REG64,REG_CL,0,0}, nasm_bytecodes+14164, IF_X64|IF_SM},
    {I_SHRD, 3, {REG64,REG64,REG_CL,0,0}, nasm_bytecodes+14164, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_SHUFPD[] = {
    {I_SHUFPD, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+8168, IF_WILLAMETTE|IF_SSE2|IF_SB|IF_AR2},
    {I_SHUFPD, 3, {XMMREG,MEMORY,IMMEDIATE,0,0}, nasm_bytecodes+8168, IF_WILLAMETTE|IF_SSE2|IF_SM|IF_SB|IF_AR2},
    ITEMPLATE_END
};

static const struct itemplate instrux_SHUFPS[] = {
    {I_SHUFPS, 3, {XMMREG,MEMORY,IMMEDIATE,0,0}, nasm_bytecodes+7902, IF_KATMAI|IF_SSE|IF_SB|IF_AR2},
    {I_SHUFPS, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+7902, IF_KATMAI|IF_SSE|IF_SB|IF_AR2},
    ITEMPLATE_END
};

static const struct itemplate instrux_SIDT[] = {
    {I_SIDT, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18242, IF_286},
    ITEMPLATE_END
};

static const struct itemplate instrux_SKINIT[] = {
    {I_SKINIT, 0, {0,0,0,0,0}, nasm_bytecodes+18247, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_SLDT[] = {
    {I_SLDT, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+14189, IF_286},
    {I_SLDT, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+14189, IF_286},
    {I_SLDT, 1, {REG16,0,0,0,0}, nasm_bytecodes+14170, IF_286},
    {I_SLDT, 1, {REG32,0,0,0,0}, nasm_bytecodes+14176, IF_386},
    {I_SLDT, 1, {REG64,0,0,0,0}, nasm_bytecodes+14182, IF_X64},
    {I_SLDT, 1, {REG64,0,0,0,0}, nasm_bytecodes+14188, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_SMI[] = {
    {I_SMI, 0, {0,0,0,0,0}, nasm_bytecodes+19655, IF_386|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_SMINT[] = {
    {I_SMINT, 0, {0,0,0,0,0}, nasm_bytecodes+19515, IF_P6|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_SMINTOLD[] = {
    {I_SMINTOLD, 0, {0,0,0,0,0}, nasm_bytecodes+19519, IF_486|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_SMSW[] = {
    {I_SMSW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+14201, IF_286},
    {I_SMSW, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+14201, IF_286},
    {I_SMSW, 1, {REG16,0,0,0,0}, nasm_bytecodes+14194, IF_286},
    {I_SMSW, 1, {REG32,0,0,0,0}, nasm_bytecodes+14200, IF_386},
    ITEMPLATE_END
};

static const struct itemplate instrux_SQRTPD[] = {
    {I_SQRTPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15334, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_SQRTPS[] = {
    {I_SQRTPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14560, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_SQRTSD[] = {
    {I_SQRTSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15340, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_SQRTSS[] = {
    {I_SQRTSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14566, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_STC[] = {
    {I_STC, 0, {0,0,0,0,0}, nasm_bytecodes+17979, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_STD[] = {
    {I_STD, 0, {0,0,0,0,0}, nasm_bytecodes+19688, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_STGI[] = {
    {I_STGI, 0, {0,0,0,0,0}, nasm_bytecodes+18252, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_STI[] = {
    {I_STI, 0, {0,0,0,0,0}, nasm_bytecodes+19691, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_STMXCSR[] = {
    {I_STMXCSR, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18477, IF_KATMAI|IF_SSE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_STOSB[] = {
    {I_STOSB, 0, {0,0,0,0,0}, nasm_bytecodes+5731, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_STOSD[] = {
    {I_STOSD, 0, {0,0,0,0,0}, nasm_bytecodes+19523, IF_386},
    ITEMPLATE_END
};

static const struct itemplate instrux_STOSQ[] = {
    {I_STOSQ, 0, {0,0,0,0,0}, nasm_bytecodes+19527, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_STOSW[] = {
    {I_STOSW, 0, {0,0,0,0,0}, nasm_bytecodes+19531, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_STR[] = {
    {I_STR, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+14219, IF_286|IF_PROT},
    {I_STR, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+14219, IF_286|IF_PROT},
    {I_STR, 1, {REG16,0,0,0,0}, nasm_bytecodes+14206, IF_286|IF_PROT},
    {I_STR, 1, {REG32,0,0,0,0}, nasm_bytecodes+14212, IF_386|IF_PROT},
    {I_STR, 1, {REG64,0,0,0,0}, nasm_bytecodes+14218, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_SUB[] = {
    {I_SUB, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+19535, IF_8086|IF_SM},
    {I_SUB, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+19535, IF_8086},
    {I_SUB, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+18257, IF_8086|IF_SM},
    {I_SUB, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+18257, IF_8086},
    {I_SUB, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+18262, IF_386|IF_SM},
    {I_SUB, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+18262, IF_386},
    {I_SUB, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+18267, IF_X64|IF_SM},
    {I_SUB, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+18267, IF_X64},
    {I_SUB, 2, {REG8,MEMORY,0,0,0}, nasm_bytecodes+11076, IF_8086|IF_SM},
    {I_SUB, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+11076, IF_8086},
    {I_SUB, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+18272, IF_8086|IF_SM},
    {I_SUB, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+18272, IF_8086},
    {I_SUB, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+18277, IF_386|IF_SM},
    {I_SUB, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+18277, IF_386},
    {I_SUB, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+18282, IF_X64|IF_SM},
    {I_SUB, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+18282, IF_X64},
    {I_SUB, 2, {RM_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+14224, IF_8086},
    {I_SUB, 2, {RM_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+14230, IF_386},
    {I_SUB, 2, {RM_GPR|BITS64,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+14236, IF_X64},
    {I_SUB, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+19539, IF_8086|IF_SM},
    {I_SUB, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+18287, IF_8086|IF_SM},
    {I_SUB, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+18292, IF_386|IF_SM},
    {I_SUB, 2, {REG_RAX,IMMEDIATE,0,0,0}, nasm_bytecodes+18297, IF_X64|IF_SM},
    {I_SUB, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+18302, IF_8086|IF_SM},
    {I_SUB, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+14242, IF_8086|IF_SM},
    {I_SUB, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+14248, IF_386|IF_SM},
    {I_SUB, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+14254, IF_X64|IF_SM},
    {I_SUB, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+18302, IF_8086|IF_SM},
    {I_SUB, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+14242, IF_8086|IF_SM},
    {I_SUB, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+14248, IF_386|IF_SM},
    ITEMPLATE_END
};

static const struct itemplate instrux_SUBPD[] = {
    {I_SUBPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15346, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_SUBPS[] = {
    {I_SUBPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14572, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_SUBSD[] = {
    {I_SUBSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15352, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_SUBSS[] = {
    {I_SUBSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14578, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_SVDC[] = {
    {I_SVDC, 2, {MEMORY|BITS80,REG_SREG,0,0,0}, nasm_bytecodes+8177, IF_486|IF_CYRIX|IF_SMM},
    ITEMPLATE_END
};

static const struct itemplate instrux_SVLDT[] = {
    {I_SVLDT, 1, {MEMORY|BITS80,0,0,0,0}, nasm_bytecodes+18307, IF_486|IF_CYRIX|IF_SMM},
    ITEMPLATE_END
};

static const struct itemplate instrux_SVTS[] = {
    {I_SVTS, 1, {MEMORY|BITS80,0,0,0,0}, nasm_bytecodes+18312, IF_486|IF_CYRIX|IF_SMM},
    ITEMPLATE_END
};

static const struct itemplate instrux_SWAPGS[] = {
    {I_SWAPGS, 0, {0,0,0,0,0}, nasm_bytecodes+18317, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_SYSCALL[] = {
    {I_SYSCALL, 0, {0,0,0,0,0}, nasm_bytecodes+19243, IF_P6|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_SYSENTER[] = {
    {I_SYSENTER, 0, {0,0,0,0,0}, nasm_bytecodes+19543, IF_P6},
    ITEMPLATE_END
};

static const struct itemplate instrux_SYSEXIT[] = {
    {I_SYSEXIT, 0, {0,0,0,0,0}, nasm_bytecodes+19547, IF_P6|IF_PRIV},
    ITEMPLATE_END
};

static const struct itemplate instrux_SYSRET[] = {
    {I_SYSRET, 0, {0,0,0,0,0}, nasm_bytecodes+19239, IF_P6|IF_PRIV|IF_AMD},
    ITEMPLATE_END
};

static const struct itemplate instrux_TEST[] = {
    {I_TEST, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+19551, IF_8086|IF_SM},
    {I_TEST, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+19551, IF_8086},
    {I_TEST, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+18322, IF_8086|IF_SM},
    {I_TEST, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+18322, IF_8086},
    {I_TEST, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+18327, IF_386|IF_SM},
    {I_TEST, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+18327, IF_386},
    {I_TEST, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+18332, IF_X64|IF_SM},
    {I_TEST, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+18332, IF_X64},
    {I_TEST, 2, {REG8,MEMORY,0,0,0}, nasm_bytecodes+19555, IF_8086|IF_SM},
    {I_TEST, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+18337, IF_8086|IF_SM},
    {I_TEST, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+18342, IF_386|IF_SM},
    {I_TEST, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+18347, IF_X64|IF_SM},
    {I_TEST, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+19559, IF_8086|IF_SM},
    {I_TEST, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+18352, IF_8086|IF_SM},
    {I_TEST, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+18357, IF_386|IF_SM},
    {I_TEST, 2, {REG_RAX,IMMEDIATE,0,0,0}, nasm_bytecodes+18362, IF_X64|IF_SM},
    {I_TEST, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+18367, IF_8086|IF_SM},
    {I_TEST, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+14260, IF_8086|IF_SM},
    {I_TEST, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+14266, IF_386|IF_SM},
    {I_TEST, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+14272, IF_X64|IF_SM},
    {I_TEST, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+18367, IF_8086|IF_SM},
    {I_TEST, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+14260, IF_8086|IF_SM},
    {I_TEST, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+14266, IF_386|IF_SM},
    ITEMPLATE_END
};

static const struct itemplate instrux_UCOMISD[] = {
    {I_UCOMISD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15358, IF_WILLAMETTE|IF_SSE2},
    ITEMPLATE_END
};

static const struct itemplate instrux_UCOMISS[] = {
    {I_UCOMISS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14584, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_UD0[] = {
    {I_UD0, 0, {0,0,0,0,0}, nasm_bytecodes+19563, IF_186|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_UD1[] = {
    {I_UD1, 0, {0,0,0,0,0}, nasm_bytecodes+19567, IF_186|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_UD2[] = {
    {I_UD2, 0, {0,0,0,0,0}, nasm_bytecodes+19571, IF_186},
    ITEMPLATE_END
};

static const struct itemplate instrux_UD2A[] = {
    {I_UD2A, 0, {0,0,0,0,0}, nasm_bytecodes+19571, IF_186},
    ITEMPLATE_END
};

static const struct itemplate instrux_UD2B[] = {
    {I_UD2B, 0, {0,0,0,0,0}, nasm_bytecodes+19567, IF_186|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_UMOV[] = {
    {I_UMOV, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+14278, IF_386|IF_UNDOC|IF_SM},
    {I_UMOV, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+14278, IF_386|IF_UNDOC},
    {I_UMOV, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+7783, IF_386|IF_UNDOC|IF_SM},
    {I_UMOV, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+7783, IF_386|IF_UNDOC},
    {I_UMOV, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+7790, IF_386|IF_UNDOC|IF_SM},
    {I_UMOV, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+7790, IF_386|IF_UNDOC},
    {I_UMOV, 2, {REG8,MEMORY,0,0,0}, nasm_bytecodes+14284, IF_386|IF_UNDOC|IF_SM},
    {I_UMOV, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+14284, IF_386|IF_UNDOC},
    {I_UMOV, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+7797, IF_386|IF_UNDOC|IF_SM},
    {I_UMOV, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+7797, IF_386|IF_UNDOC},
    {I_UMOV, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+7804, IF_386|IF_UNDOC|IF_SM},
    {I_UMOV, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+7804, IF_386|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_UNPCKHPD[] = {
    {I_UNPCKHPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15364, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_UNPCKHPS[] = {
    {I_UNPCKHPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14590, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_UNPCKLPD[] = {
    {I_UNPCKLPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15370, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_UNPCKLPS[] = {
    {I_UNPCKLPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14596, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_VADDPD[] = {
    {I_VADDPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9757, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VADDPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9764, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VADDPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+9771, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VADDPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+9778, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VADDPS[] = {
    {I_VADDPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9785, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VADDPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9792, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VADDPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+9799, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VADDPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+9806, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VADDSD[] = {
    {I_VADDSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9813, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VADDSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9820, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VADDSS[] = {
    {I_VADDSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9827, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VADDSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9834, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VADDSUBPD[] = {
    {I_VADDSUBPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9841, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VADDSUBPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9848, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VADDSUBPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+9855, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VADDSUBPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+9862, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VADDSUBPS[] = {
    {I_VADDSUBPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9869, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VADDSUBPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9876, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VADDSUBPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+9883, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VADDSUBPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+9890, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VAESDEC[] = {
    {I_VAESDEC, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9722, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VAESDEC, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9729, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VAESDECLAST[] = {
    {I_VAESDECLAST, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9736, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VAESDECLAST, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9743, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VAESENC[] = {
    {I_VAESENC, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9694, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VAESENC, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9701, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VAESENCLAST[] = {
    {I_VAESENCLAST, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9708, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VAESENCLAST, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9715, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VAESIMC[] = {
    {I_VAESIMC, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9750, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VAESKEYGENASSIST[] = {
    {I_VAESKEYGENASSIST, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6430, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VANDNPD[] = {
    {I_VANDNPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9953, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VANDNPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9960, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VANDNPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+9967, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VANDNPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+9974, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VANDNPS[] = {
    {I_VANDNPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9981, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VANDNPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9988, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VANDNPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+9995, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VANDNPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10002, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VANDPD[] = {
    {I_VANDPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9897, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VANDPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9904, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VANDPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+9911, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VANDPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+9918, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VANDPS[] = {
    {I_VANDPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+9925, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VANDPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+9932, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VANDPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+9939, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VANDPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+9946, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VBLENDPD[] = {
    {I_VBLENDPD, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6438, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VBLENDPD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6446, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VBLENDPD, 4, {YMMREG,YMMREG,RM_YMM,IMMEDIATE,0}, nasm_bytecodes+6454, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VBLENDPD, 3, {YMMREG,RM_YMM,IMMEDIATE,0,0}, nasm_bytecodes+6462, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VBLENDPS[] = {
    {I_VBLENDPS, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6470, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VBLENDPS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6478, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VBLENDPS, 4, {YMMREG,YMMREG,RM_YMM,IMMEDIATE,0}, nasm_bytecodes+6486, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VBLENDPS, 3, {YMMREG,RM_YMM,IMMEDIATE,0,0}, nasm_bytecodes+6494, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VBLENDVPD[] = {
    {I_VBLENDVPD, 4, {XMMREG,XMMREG,RM_XMM,RM_XMM,0}, nasm_bytecodes+1188, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VBLENDVPD, 3, {XMMREG,RM_XMM,XMM0,0,0}, nasm_bytecodes+10009, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VBLENDVPD, 4, {YMMREG,YMMREG,RM_YMM,RM_YMM,0}, nasm_bytecodes+1197, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VBLENDVPD, 3, {YMMREG,RM_YMM,YMM0,0,0}, nasm_bytecodes+10016, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VBLENDVPD, 3, {YMMREG,RM_YMM,YMM0,0,0}, nasm_bytecodes+10030, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VBLENDVPS[] = {
    {I_VBLENDVPS, 4, {XMMREG,XMMREG,RM_XMM,RM_XMM,0}, nasm_bytecodes+1206, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VBLENDVPS, 3, {XMMREG,RM_XMM,XMM0,0,0}, nasm_bytecodes+10023, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VBLENDVPS, 4, {YMMREG,YMMREG,RM_YMM,RM_YMM,0}, nasm_bytecodes+1215, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VBROADCASTF128[] = {
    {I_VBROADCASTF128, 2, {YMMREG,MEMORY,0,0,0}, nasm_bytecodes+10058, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VBROADCASTSD[] = {
    {I_VBROADCASTSD, 2, {YMMREG,MEMORY,0,0,0}, nasm_bytecodes+10051, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VBROADCASTSS[] = {
    {I_VBROADCASTSS, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+10037, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VBROADCASTSS, 2, {YMMREG,MEMORY,0,0,0}, nasm_bytecodes+10044, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPEQPD[] = {
    {I_VCMPEQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1224, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPEQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1233, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPEQPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1242, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPEQPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1251, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPEQPS[] = {
    {I_VCMPEQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2376, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPEQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2385, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPEQPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2394, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPEQPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2403, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPEQSD[] = {
    {I_VCMPEQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3528, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPEQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3537, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPEQSS[] = {
    {I_VCMPEQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4104, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPEQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4113, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPEQ_OSPD[] = {
    {I_VCMPEQ_OSPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1800, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPEQ_OSPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1809, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPEQ_OSPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1818, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPEQ_OSPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1827, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPEQ_OSPS[] = {
    {I_VCMPEQ_OSPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2952, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPEQ_OSPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2961, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPEQ_OSPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2970, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPEQ_OSPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2979, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPEQ_OSSD[] = {
    {I_VCMPEQ_OSSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3816, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPEQ_OSSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3825, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPEQ_OSSS[] = {
    {I_VCMPEQ_OSSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4392, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPEQ_OSSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4401, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPEQ_UQPD[] = {
    {I_VCMPEQ_UQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1512, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPEQ_UQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1521, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPEQ_UQPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1530, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPEQ_UQPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1539, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPEQ_UQPS[] = {
    {I_VCMPEQ_UQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2664, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPEQ_UQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2673, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPEQ_UQPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2682, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPEQ_UQPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2691, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPEQ_UQSD[] = {
    {I_VCMPEQ_UQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3672, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPEQ_UQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3681, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPEQ_UQSS[] = {
    {I_VCMPEQ_UQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4248, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPEQ_UQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4257, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPEQ_USPD[] = {
    {I_VCMPEQ_USPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2088, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPEQ_USPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2097, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPEQ_USPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2106, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPEQ_USPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2115, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPEQ_USPS[] = {
    {I_VCMPEQ_USPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3240, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPEQ_USPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3249, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPEQ_USPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3258, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPEQ_USPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3267, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPEQ_USSD[] = {
    {I_VCMPEQ_USSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3960, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPEQ_USSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3969, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPEQ_USSS[] = {
    {I_VCMPEQ_USSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4536, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPEQ_USSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4545, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPFALSEPD[] = {
    {I_VCMPFALSEPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1620, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPFALSEPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1629, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPFALSEPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1638, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPFALSEPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1647, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPFALSEPS[] = {
    {I_VCMPFALSEPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2772, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPFALSEPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2781, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPFALSEPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2790, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPFALSEPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2799, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPFALSESD[] = {
    {I_VCMPFALSESD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3726, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPFALSESD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3735, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPFALSESS[] = {
    {I_VCMPFALSESS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4302, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPFALSESS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4311, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPFALSE_OSPD[] = {
    {I_VCMPFALSE_OSPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2196, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPFALSE_OSPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2205, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPFALSE_OSPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2214, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPFALSE_OSPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2223, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPFALSE_OSPS[] = {
    {I_VCMPFALSE_OSPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3348, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPFALSE_OSPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3357, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPFALSE_OSPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3366, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPFALSE_OSPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3375, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPFALSE_OSSD[] = {
    {I_VCMPFALSE_OSSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4014, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPFALSE_OSSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4023, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPFALSE_OSSS[] = {
    {I_VCMPFALSE_OSSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4590, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPFALSE_OSSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4599, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPGEPD[] = {
    {I_VCMPGEPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1692, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPGEPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1701, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPGEPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1710, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPGEPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1719, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPGEPS[] = {
    {I_VCMPGEPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2844, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPGEPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2853, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPGEPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2862, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPGEPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2871, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPGESD[] = {
    {I_VCMPGESD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3762, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPGESD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3771, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPGESS[] = {
    {I_VCMPGESS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4338, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPGESS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4347, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPGE_OQPD[] = {
    {I_VCMPGE_OQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2268, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPGE_OQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2277, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPGE_OQPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2286, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPGE_OQPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2295, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPGE_OQPS[] = {
    {I_VCMPGE_OQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3420, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPGE_OQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3429, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPGE_OQPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3438, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPGE_OQPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3447, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPGE_OQSD[] = {
    {I_VCMPGE_OQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4050, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPGE_OQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4059, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPGE_OQSS[] = {
    {I_VCMPGE_OQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4626, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPGE_OQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4635, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPGTPD[] = {
    {I_VCMPGTPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1728, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPGTPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1737, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPGTPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1746, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPGTPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1755, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPGTPS[] = {
    {I_VCMPGTPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2880, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPGTPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2889, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPGTPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2898, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPGTPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2907, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPGTSD[] = {
    {I_VCMPGTSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3780, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPGTSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3789, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPGTSS[] = {
    {I_VCMPGTSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4356, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPGTSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4365, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPGT_OQPD[] = {
    {I_VCMPGT_OQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2304, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPGT_OQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2313, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPGT_OQPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2322, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPGT_OQPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2331, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPGT_OQPS[] = {
    {I_VCMPGT_OQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3456, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPGT_OQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3465, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPGT_OQPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3474, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPGT_OQPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3483, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPGT_OQSD[] = {
    {I_VCMPGT_OQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4068, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPGT_OQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4077, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPGT_OQSS[] = {
    {I_VCMPGT_OQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4644, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPGT_OQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4653, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPLEPD[] = {
    {I_VCMPLEPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1296, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPLEPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1305, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPLEPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1314, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPLEPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1323, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPLEPS[] = {
    {I_VCMPLEPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2448, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPLEPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2457, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPLEPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2466, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPLEPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2475, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPLESD[] = {
    {I_VCMPLESD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3564, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPLESD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3573, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPLESS[] = {
    {I_VCMPLESS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4140, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPLESS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4149, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPLE_OQPD[] = {
    {I_VCMPLE_OQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1872, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPLE_OQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1881, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPLE_OQPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1890, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPLE_OQPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1899, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPLE_OQPS[] = {
    {I_VCMPLE_OQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3024, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPLE_OQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3033, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPLE_OQPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3042, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPLE_OQPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3051, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPLE_OQSD[] = {
    {I_VCMPLE_OQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3852, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPLE_OQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3861, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPLE_OQSS[] = {
    {I_VCMPLE_OQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4428, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPLE_OQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4437, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPLTPD[] = {
    {I_VCMPLTPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1260, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPLTPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1269, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPLTPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1278, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPLTPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1287, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPLTPS[] = {
    {I_VCMPLTPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2412, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPLTPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2421, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPLTPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2430, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPLTPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2439, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPLTSD[] = {
    {I_VCMPLTSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3546, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPLTSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3555, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPLTSS[] = {
    {I_VCMPLTSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4122, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPLTSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4131, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPLT_OQPD[] = {
    {I_VCMPLT_OQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1836, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPLT_OQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1845, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPLT_OQPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1854, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPLT_OQPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1863, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPLT_OQPS[] = {
    {I_VCMPLT_OQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2988, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPLT_OQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2997, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPLT_OQPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3006, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPLT_OQPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3015, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPLT_OQSD[] = {
    {I_VCMPLT_OQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3834, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPLT_OQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3843, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPLT_OQSS[] = {
    {I_VCMPLT_OQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4410, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPLT_OQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4419, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNEQPD[] = {
    {I_VCMPNEQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1368, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNEQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1377, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNEQPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1386, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPNEQPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1395, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNEQPS[] = {
    {I_VCMPNEQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2520, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNEQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2529, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNEQPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2538, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPNEQPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2547, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNEQSD[] = {
    {I_VCMPNEQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3600, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPNEQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3609, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNEQSS[] = {
    {I_VCMPNEQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4176, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPNEQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4185, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNEQ_OQPD[] = {
    {I_VCMPNEQ_OQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1656, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNEQ_OQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1665, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNEQ_OQPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1674, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPNEQ_OQPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1683, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNEQ_OQPS[] = {
    {I_VCMPNEQ_OQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2808, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNEQ_OQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2817, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNEQ_OQPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2826, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPNEQ_OQPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2835, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNEQ_OQSD[] = {
    {I_VCMPNEQ_OQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3744, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPNEQ_OQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3753, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNEQ_OQSS[] = {
    {I_VCMPNEQ_OQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4320, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPNEQ_OQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4329, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNEQ_OSPD[] = {
    {I_VCMPNEQ_OSPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2232, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNEQ_OSPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2241, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNEQ_OSPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2250, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPNEQ_OSPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2259, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNEQ_OSPS[] = {
    {I_VCMPNEQ_OSPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3384, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNEQ_OSPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3393, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNEQ_OSPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3402, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPNEQ_OSPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3411, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNEQ_OSSD[] = {
    {I_VCMPNEQ_OSSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4032, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPNEQ_OSSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4041, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNEQ_OSSS[] = {
    {I_VCMPNEQ_OSSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4608, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPNEQ_OSSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4617, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNEQ_USPD[] = {
    {I_VCMPNEQ_USPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1944, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNEQ_USPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1953, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNEQ_USPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1962, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPNEQ_USPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1971, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNEQ_USPS[] = {
    {I_VCMPNEQ_USPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3096, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNEQ_USPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3105, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNEQ_USPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3114, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPNEQ_USPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3123, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNEQ_USSD[] = {
    {I_VCMPNEQ_USSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3888, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPNEQ_USSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3897, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNEQ_USSS[] = {
    {I_VCMPNEQ_USSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4464, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPNEQ_USSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4473, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNGEPD[] = {
    {I_VCMPNGEPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1548, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNGEPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1557, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNGEPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1566, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPNGEPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1575, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNGEPS[] = {
    {I_VCMPNGEPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2700, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNGEPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2709, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNGEPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2718, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPNGEPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2727, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNGESD[] = {
    {I_VCMPNGESD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3690, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPNGESD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3699, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNGESS[] = {
    {I_VCMPNGESS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4266, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPNGESS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4275, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNGE_UQPD[] = {
    {I_VCMPNGE_UQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2124, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNGE_UQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2133, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNGE_UQPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2142, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPNGE_UQPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2151, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNGE_UQPS[] = {
    {I_VCMPNGE_UQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3276, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNGE_UQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3285, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNGE_UQPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3294, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPNGE_UQPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3303, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNGE_UQSD[] = {
    {I_VCMPNGE_UQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3978, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPNGE_UQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3987, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNGE_UQSS[] = {
    {I_VCMPNGE_UQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4554, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPNGE_UQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4563, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNGTPD[] = {
    {I_VCMPNGTPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1584, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNGTPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1593, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNGTPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1602, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPNGTPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1611, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNGTPS[] = {
    {I_VCMPNGTPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2736, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNGTPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2745, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNGTPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2754, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPNGTPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2763, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNGTSD[] = {
    {I_VCMPNGTSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3708, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPNGTSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3717, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNGTSS[] = {
    {I_VCMPNGTSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4284, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPNGTSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4293, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNGT_UQPD[] = {
    {I_VCMPNGT_UQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2160, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNGT_UQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2169, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNGT_UQPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2178, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPNGT_UQPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2187, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNGT_UQPS[] = {
    {I_VCMPNGT_UQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3312, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNGT_UQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3321, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNGT_UQPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3330, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPNGT_UQPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3339, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNGT_UQSD[] = {
    {I_VCMPNGT_UQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3996, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPNGT_UQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4005, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNGT_UQSS[] = {
    {I_VCMPNGT_UQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4572, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPNGT_UQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4581, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNLEPD[] = {
    {I_VCMPNLEPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1440, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNLEPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1449, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNLEPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1458, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPNLEPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1467, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNLEPS[] = {
    {I_VCMPNLEPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2592, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNLEPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2601, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNLEPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2610, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPNLEPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2619, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNLESD[] = {
    {I_VCMPNLESD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3636, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPNLESD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3645, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNLESS[] = {
    {I_VCMPNLESS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4212, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPNLESS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4221, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNLE_UQPD[] = {
    {I_VCMPNLE_UQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2016, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNLE_UQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2025, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNLE_UQPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2034, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPNLE_UQPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2043, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNLE_UQPS[] = {
    {I_VCMPNLE_UQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3168, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNLE_UQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3177, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNLE_UQPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3186, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPNLE_UQPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3195, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNLE_UQSD[] = {
    {I_VCMPNLE_UQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3924, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPNLE_UQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3933, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNLE_UQSS[] = {
    {I_VCMPNLE_UQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4500, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPNLE_UQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4509, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNLTPD[] = {
    {I_VCMPNLTPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1404, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNLTPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1413, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNLTPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1422, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPNLTPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1431, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNLTPS[] = {
    {I_VCMPNLTPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2556, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNLTPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2565, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNLTPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2574, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPNLTPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2583, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNLTSD[] = {
    {I_VCMPNLTSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3618, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPNLTSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3627, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNLTSS[] = {
    {I_VCMPNLTSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4194, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPNLTSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4203, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNLT_UQPD[] = {
    {I_VCMPNLT_UQPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1980, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNLT_UQPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1989, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNLT_UQPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1998, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPNLT_UQPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2007, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNLT_UQPS[] = {
    {I_VCMPNLT_UQPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3132, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNLT_UQPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3141, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPNLT_UQPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3150, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPNLT_UQPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3159, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNLT_UQSD[] = {
    {I_VCMPNLT_UQSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3906, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPNLT_UQSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3915, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPNLT_UQSS[] = {
    {I_VCMPNLT_UQSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4482, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPNLT_UQSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4491, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPORDPD[] = {
    {I_VCMPORDPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1476, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPORDPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1485, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPORDPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1494, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPORDPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1503, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPORDPS[] = {
    {I_VCMPORDPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2628, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPORDPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2637, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPORDPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2646, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPORDPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2655, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPORDSD[] = {
    {I_VCMPORDSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3654, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPORDSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3663, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPORDSS[] = {
    {I_VCMPORDSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4230, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPORDSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4239, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPORD_SPD[] = {
    {I_VCMPORD_SPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2052, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPORD_SPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2061, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPORD_SPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2070, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPORD_SPS[] = {
    {I_VCMPORD_SPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3204, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPORD_SPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3213, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPORD_SPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3222, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPORD_SSD[] = {
    {I_VCMPORD_SSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3942, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPORD_SSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3951, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPORD_SSS[] = {
    {I_VCMPORD_SSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4518, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPORD_SSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4527, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPORS_SPD[] = {
    {I_VCMPORS_SPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2079, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPORS_SPS[] = {
    {I_VCMPORS_SPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3231, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPPD[] = {
    {I_VCMPPD, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6502, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPPD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6510, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPPD, 4, {YMMREG,YMMREG,RM_YMM,IMMEDIATE,0}, nasm_bytecodes+6518, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPPD, 3, {YMMREG,RM_YMM,IMMEDIATE,0,0}, nasm_bytecodes+6526, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPPS[] = {
    {I_VCMPPS, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6534, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPPS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6542, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPPS, 4, {YMMREG,YMMREG,RM_YMM,IMMEDIATE,0}, nasm_bytecodes+6550, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPPS, 3, {YMMREG,RM_YMM,IMMEDIATE,0,0}, nasm_bytecodes+6558, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPSD[] = {
    {I_VCMPSD, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6566, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPSD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6574, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPSS[] = {
    {I_VCMPSS, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6582, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPSS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6590, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPTRUEPD[] = {
    {I_VCMPTRUEPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1764, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPTRUEPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1773, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPTRUEPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1782, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPTRUEPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1791, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPTRUEPS[] = {
    {I_VCMPTRUEPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2916, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPTRUEPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2925, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPTRUEPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2934, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPTRUEPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2943, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPTRUESD[] = {
    {I_VCMPTRUESD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3798, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPTRUESD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3807, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPTRUESS[] = {
    {I_VCMPTRUESS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4374, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPTRUESS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4383, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPTRUE_USPD[] = {
    {I_VCMPTRUE_USPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2340, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPTRUE_USPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2349, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPTRUE_USPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2358, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPTRUE_USPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2367, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPTRUE_USPS[] = {
    {I_VCMPTRUE_USPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3492, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPTRUE_USPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3501, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPTRUE_USPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3510, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPTRUE_USPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3519, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPTRUE_USSD[] = {
    {I_VCMPTRUE_USSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4086, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPTRUE_USSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4095, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPTRUE_USSS[] = {
    {I_VCMPTRUE_USSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4662, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPTRUE_USSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4671, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPUNORDPD[] = {
    {I_VCMPUNORDPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1332, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPUNORDPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1341, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPUNORDPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1350, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPUNORDPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1359, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPUNORDPS[] = {
    {I_VCMPUNORDPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+2484, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPUNORDPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+2493, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPUNORDPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+2502, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPUNORDPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+2511, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPUNORDSD[] = {
    {I_VCMPUNORDSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3582, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPUNORDSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3591, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPUNORDSS[] = {
    {I_VCMPUNORDSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4158, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPUNORDSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4167, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPUNORD_SPD[] = {
    {I_VCMPUNORD_SPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+1908, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPUNORD_SPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+1917, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPUNORD_SPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+1926, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPUNORD_SPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+1935, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPUNORD_SPS[] = {
    {I_VCMPUNORD_SPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3060, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPUNORD_SPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3069, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCMPUNORD_SPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+3078, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VCMPUNORD_SPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+3087, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPUNORD_SSD[] = {
    {I_VCMPUNORD_SSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+3870, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCMPUNORD_SSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+3879, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCMPUNORD_SSS[] = {
    {I_VCMPUNORD_SSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+4446, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCMPUNORD_SSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+4455, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCOMISD[] = {
    {I_VCOMISD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10065, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCOMISS[] = {
    {I_VCOMISS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10072, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCVTDQ2PD[] = {
    {I_VCVTDQ2PD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10079, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCVTDQ2PD, 2, {YMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10086, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCVTDQ2PS[] = {
    {I_VCVTDQ2PS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10093, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCVTDQ2PS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10100, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCVTPD2DQ[] = {
    {I_VCVTPD2DQ, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+10107, IF_AVX|IF_SANDYBRIDGE},
    {I_VCVTPD2DQ, 2, {XMMREG,MEMORY|BITS128,0,0,0}, nasm_bytecodes+10107, IF_AVX|IF_SANDYBRIDGE},
    {I_VCVTPD2DQ, 2, {XMMREG,YMMREG,0,0,0}, nasm_bytecodes+10114, IF_AVX|IF_SANDYBRIDGE},
    {I_VCVTPD2DQ, 2, {XMMREG,MEMORY|BITS256,0,0,0}, nasm_bytecodes+10114, IF_AVX|IF_SANDYBRIDGE},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCVTPD2PS[] = {
    {I_VCVTPD2PS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+10121, IF_AVX|IF_SANDYBRIDGE},
    {I_VCVTPD2PS, 2, {XMMREG,MEMORY|BITS128,0,0,0}, nasm_bytecodes+10121, IF_AVX|IF_SANDYBRIDGE},
    {I_VCVTPD2PS, 2, {XMMREG,YMMREG,0,0,0}, nasm_bytecodes+10128, IF_AVX|IF_SANDYBRIDGE},
    {I_VCVTPD2PS, 2, {XMMREG,MEMORY|BITS256,0,0,0}, nasm_bytecodes+10128, IF_AVX|IF_SANDYBRIDGE},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCVTPS2DQ[] = {
    {I_VCVTPS2DQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10135, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCVTPS2DQ, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10142, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCVTPS2PD[] = {
    {I_VCVTPS2PD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10149, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCVTPS2PD, 2, {YMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10156, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCVTSD2SI[] = {
    {I_VCVTSD2SI, 2, {REG32,RM_XMM,0,0,0}, nasm_bytecodes+10163, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCVTSD2SI, 2, {REG64,RM_XMM,0,0,0}, nasm_bytecodes+10170, IF_AVX|IF_SANDYBRIDGE|IF_SQ|IF_LONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCVTSD2SS[] = {
    {I_VCVTSD2SS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10177, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCVTSD2SS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10184, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCVTSI2SD[] = {
    {I_VCVTSI2SD, 3, {XMMREG,XMMREG,RM_GPR|BITS32,0,0}, nasm_bytecodes+10191, IF_AVX|IF_SANDYBRIDGE},
    {I_VCVTSI2SD, 2, {XMMREG,RM_GPR|BITS32,0,0,0}, nasm_bytecodes+10198, IF_AVX|IF_SANDYBRIDGE},
    {I_VCVTSI2SD, 3, {XMMREG,XMMREG,MEMORY,0,0}, nasm_bytecodes+10191, IF_AVX|IF_SANDYBRIDGE|IF_SD|IF_AR2},
    {I_VCVTSI2SD, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+10198, IF_AVX|IF_SANDYBRIDGE|IF_SD|IF_AR2},
    {I_VCVTSI2SD, 3, {XMMREG,XMMREG,RM_GPR|BITS64,0,0}, nasm_bytecodes+10205, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    {I_VCVTSI2SD, 2, {XMMREG,RM_GPR|BITS64,0,0,0}, nasm_bytecodes+10212, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCVTSI2SS[] = {
    {I_VCVTSI2SS, 3, {XMMREG,XMMREG,RM_GPR|BITS32,0,0}, nasm_bytecodes+10219, IF_AVX|IF_SANDYBRIDGE},
    {I_VCVTSI2SS, 2, {XMMREG,RM_GPR|BITS32,0,0,0}, nasm_bytecodes+10226, IF_AVX|IF_SANDYBRIDGE},
    {I_VCVTSI2SS, 3, {XMMREG,XMMREG,MEMORY,0,0}, nasm_bytecodes+10219, IF_AVX|IF_SANDYBRIDGE|IF_SD|IF_AR2},
    {I_VCVTSI2SS, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+10226, IF_AVX|IF_SANDYBRIDGE|IF_SD|IF_AR2},
    {I_VCVTSI2SS, 3, {XMMREG,XMMREG,RM_GPR|BITS64,0,0}, nasm_bytecodes+10233, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    {I_VCVTSI2SS, 2, {XMMREG,RM_GPR|BITS64,0,0,0}, nasm_bytecodes+10240, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCVTSS2SD[] = {
    {I_VCVTSS2SD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10247, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCVTSS2SD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10254, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCVTSS2SI[] = {
    {I_VCVTSS2SI, 2, {REG32,RM_XMM,0,0,0}, nasm_bytecodes+10261, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCVTSS2SI, 2, {REG64,RM_XMM,0,0,0}, nasm_bytecodes+10268, IF_AVX|IF_SANDYBRIDGE|IF_SD|IF_LONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCVTTPD2DQ[] = {
    {I_VCVTTPD2DQ, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+10275, IF_AVX|IF_SANDYBRIDGE},
    {I_VCVTTPD2DQ, 2, {XMMREG,MEMORY|BITS128,0,0,0}, nasm_bytecodes+10275, IF_AVX|IF_SANDYBRIDGE},
    {I_VCVTTPD2DQ, 2, {XMMREG,YMMREG,0,0,0}, nasm_bytecodes+10282, IF_AVX|IF_SANDYBRIDGE},
    {I_VCVTTPD2DQ, 2, {XMMREG,MEMORY|BITS256,0,0,0}, nasm_bytecodes+10282, IF_AVX|IF_SANDYBRIDGE},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCVTTPS2DQ[] = {
    {I_VCVTTPS2DQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10289, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VCVTTPS2DQ, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10296, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCVTTSD2SI[] = {
    {I_VCVTTSD2SI, 2, {REG32,RM_XMM,0,0,0}, nasm_bytecodes+10303, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VCVTTSD2SI, 2, {REG64,RM_XMM,0,0,0}, nasm_bytecodes+10310, IF_AVX|IF_SANDYBRIDGE|IF_SQ|IF_LONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_VCVTTSS2SI[] = {
    {I_VCVTTSS2SI, 2, {REG32,RM_XMM,0,0,0}, nasm_bytecodes+10317, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VCVTTSS2SI, 2, {REG64,RM_XMM,0,0,0}, nasm_bytecodes+10324, IF_AVX|IF_SANDYBRIDGE|IF_SD|IF_LONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_VDIVPD[] = {
    {I_VDIVPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10331, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VDIVPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10338, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VDIVPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+10345, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VDIVPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10352, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VDIVPS[] = {
    {I_VDIVPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10359, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VDIVPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10366, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VDIVPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+10373, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VDIVPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10380, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VDIVSD[] = {
    {I_VDIVSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10387, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VDIVSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10394, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VDIVSS[] = {
    {I_VDIVSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10401, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VDIVSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10408, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VDPPD[] = {
    {I_VDPPD, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6598, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VDPPD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6606, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VDPPS[] = {
    {I_VDPPS, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6614, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VDPPS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6622, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VDPPS, 4, {YMMREG,YMMREG,RM_YMM,IMMEDIATE,0}, nasm_bytecodes+6630, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VDPPS, 3, {YMMREG,RM_YMM,IMMEDIATE,0,0}, nasm_bytecodes+6638, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VERR[] = {
    {I_VERR, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18372, IF_286|IF_PROT},
    {I_VERR, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18372, IF_286|IF_PROT},
    {I_VERR, 1, {REG16,0,0,0,0}, nasm_bytecodes+18372, IF_286|IF_PROT},
    ITEMPLATE_END
};

static const struct itemplate instrux_VERW[] = {
    {I_VERW, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18377, IF_286|IF_PROT},
    {I_VERW, 1, {MEMORY|BITS16,0,0,0,0}, nasm_bytecodes+18377, IF_286|IF_PROT},
    {I_VERW, 1, {REG16,0,0,0,0}, nasm_bytecodes+18377, IF_286|IF_PROT},
    ITEMPLATE_END
};

static const struct itemplate instrux_VEXTRACTF128[] = {
    {I_VEXTRACTF128, 3, {RM_XMM,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6646, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VEXTRACTPS[] = {
    {I_VEXTRACTPS, 3, {RM_GPR|BITS32,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6654, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VFMADDPD[] = {
    {I_VFMADDPD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5022, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    {I_VFMADDPD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5031, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    {I_VFMADDPD, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+5040, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    {I_VFMADDPD, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+5049, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VFMADDPS[] = {
    {I_VFMADDPS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5058, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    {I_VFMADDPS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5067, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    {I_VFMADDPS, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+5076, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    {I_VFMADDPS, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+5085, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VFMADDSD[] = {
    {I_VFMADDSD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5094, IF_FMA|IF_SANDYBRIDGE|IF_SQ},
    {I_VFMADDSD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5103, IF_FMA|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VFMADDSS[] = {
    {I_VFMADDSS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5112, IF_FMA|IF_SANDYBRIDGE|IF_SD},
    {I_VFMADDSS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5121, IF_FMA|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VFMADDSUBPD[] = {
    {I_VFMADDSUBPD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5130, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    {I_VFMADDSUBPD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5139, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    {I_VFMADDSUBPD, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+5148, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    {I_VFMADDSUBPD, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+5157, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VFMADDSUBPS[] = {
    {I_VFMADDSUBPS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5166, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    {I_VFMADDSUBPS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5175, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    {I_VFMADDSUBPS, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+5184, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    {I_VFMADDSUBPS, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+5193, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VFMSUBADDPD[] = {
    {I_VFMSUBADDPD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5202, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    {I_VFMSUBADDPD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5211, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    {I_VFMSUBADDPD, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+5220, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    {I_VFMSUBADDPD, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+5229, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VFMSUBADDPS[] = {
    {I_VFMSUBADDPS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5238, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    {I_VFMSUBADDPS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5247, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    {I_VFMSUBADDPS, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+5256, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    {I_VFMSUBADDPS, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+5265, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VFMSUBPD[] = {
    {I_VFMSUBPD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5274, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    {I_VFMSUBPD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5283, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    {I_VFMSUBPD, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+5292, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    {I_VFMSUBPD, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+5301, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VFMSUBPS[] = {
    {I_VFMSUBPS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5310, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    {I_VFMSUBPS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5319, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    {I_VFMSUBPS, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+5328, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    {I_VFMSUBPS, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+5337, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VFMSUBSD[] = {
    {I_VFMSUBSD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5346, IF_FMA|IF_SANDYBRIDGE|IF_SQ},
    {I_VFMSUBSD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5355, IF_FMA|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VFMSUBSS[] = {
    {I_VFMSUBSS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5364, IF_FMA|IF_SANDYBRIDGE|IF_SD},
    {I_VFMSUBSS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5373, IF_FMA|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VFNMADDPD[] = {
    {I_VFNMADDPD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5382, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    {I_VFNMADDPD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5391, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    {I_VFNMADDPD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5400, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    {I_VFNMADDPD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5409, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VFNMADDPS[] = {
    {I_VFNMADDPS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5418, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    {I_VFNMADDPS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5427, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    {I_VFNMADDPS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5436, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    {I_VFNMADDPS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5445, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VFNMADDSD[] = {
    {I_VFNMADDSD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5454, IF_FMA|IF_SANDYBRIDGE|IF_SQ},
    {I_VFNMADDSD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5463, IF_FMA|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VFNMADDSS[] = {
    {I_VFNMADDSS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5472, IF_FMA|IF_SANDYBRIDGE|IF_SD},
    {I_VFNMADDSS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5481, IF_FMA|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VFNMSUBPD[] = {
    {I_VFNMSUBPD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5490, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    {I_VFNMSUBPD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5499, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    {I_VFNMSUBPD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5508, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    {I_VFNMSUBPD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5517, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VFNMSUBPS[] = {
    {I_VFNMSUBPS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5526, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    {I_VFNMSUBPS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5535, IF_FMA|IF_SANDYBRIDGE|IF_SO},
    {I_VFNMSUBPS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5544, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    {I_VFNMSUBPS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5553, IF_FMA|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VFNMSUBSD[] = {
    {I_VFNMSUBSD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5562, IF_FMA|IF_SANDYBRIDGE|IF_SQ},
    {I_VFNMSUBSD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5571, IF_FMA|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VFNMSUBSS[] = {
    {I_VFNMSUBSS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+5580, IF_FMA|IF_SANDYBRIDGE|IF_SD},
    {I_VFNMSUBSS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+5589, IF_FMA|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VHADDPD[] = {
    {I_VHADDPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10415, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VHADDPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10422, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VHADDPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+10429, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VHADDPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10436, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VHADDPS[] = {
    {I_VHADDPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10443, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VHADDPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10450, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VHADDPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+10457, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VHADDPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10464, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VHSUBPD[] = {
    {I_VHSUBPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10471, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VHSUBPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10478, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VHSUBPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+10485, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VHSUBPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10492, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VHSUBPS[] = {
    {I_VHSUBPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10499, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VHSUBPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10506, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VHSUBPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+10513, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VHSUBPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10520, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VINSERTF128[] = {
    {I_VINSERTF128, 4, {YMMREG,YMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6662, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VINSERTPS[] = {
    {I_VINSERTPS, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6670, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VINSERTPS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6678, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VLDDQU[] = {
    {I_VLDDQU, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+10527, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VLDDQU, 2, {YMMREG,MEMORY,0,0,0}, nasm_bytecodes+10534, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VLDMXCSR[] = {
    {I_VLDMXCSR, 1, {MEMORY|BITS32,0,0,0,0}, nasm_bytecodes+10541, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VLDQQU[] = {
    {I_VLDQQU, 2, {YMMREG,MEMORY,0,0,0}, nasm_bytecodes+10534, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMASKMOVDQU[] = {
    {I_VMASKMOVDQU, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+10548, IF_AVX|IF_SANDYBRIDGE},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMASKMOVPD[] = {
    {I_VMASKMOVPD, 3, {XMMREG,XMMREG,MEMORY,0,0}, nasm_bytecodes+10583, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMASKMOVPD, 3, {YMMREG,YMMREG,MEMORY,0,0}, nasm_bytecodes+10590, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VMASKMOVPD, 3, {MEMORY,XMMREG,XMMREG,0,0}, nasm_bytecodes+10597, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMASKMOVPD, 3, {MEMORY,YMMREG,YMMREG,0,0}, nasm_bytecodes+10604, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMASKMOVPS[] = {
    {I_VMASKMOVPS, 3, {XMMREG,XMMREG,MEMORY,0,0}, nasm_bytecodes+10555, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMASKMOVPS, 3, {YMMREG,YMMREG,MEMORY,0,0}, nasm_bytecodes+10562, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VMASKMOVPS, 3, {MEMORY,XMMREG,XMMREG,0,0}, nasm_bytecodes+10569, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMASKMOVPS, 3, {MEMORY,XMMREG,XMMREG,0,0}, nasm_bytecodes+10576, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMAXPD[] = {
    {I_VMAXPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10611, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMAXPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10618, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMAXPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+10625, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VMAXPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10632, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMAXPS[] = {
    {I_VMAXPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10639, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMAXPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10646, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMAXPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+10653, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VMAXPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10660, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMAXSD[] = {
    {I_VMAXSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10667, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VMAXSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10674, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMAXSS[] = {
    {I_VMAXSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10681, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VMAXSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10688, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMCALL[] = {
    {I_VMCALL, 0, {0,0,0,0,0}, nasm_bytecodes+18497, IF_VMX},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMCLEAR[] = {
    {I_VMCLEAR, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+15442, IF_VMX},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMINPD[] = {
    {I_VMINPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10695, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMINPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10702, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMINPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+10709, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VMINPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10716, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMINPS[] = {
    {I_VMINPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10723, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMINPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10730, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMINPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+10737, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VMINPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10744, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMINSD[] = {
    {I_VMINSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10751, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VMINSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10758, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMINSS[] = {
    {I_VMINSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+10765, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VMINSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10772, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMLAUNCH[] = {
    {I_VMLAUNCH, 0, {0,0,0,0,0}, nasm_bytecodes+18502, IF_VMX},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMLOAD[] = {
    {I_VMLOAD, 0, {0,0,0,0,0}, nasm_bytecodes+18507, IF_X64|IF_VMX},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMMCALL[] = {
    {I_VMMCALL, 0, {0,0,0,0,0}, nasm_bytecodes+18512, IF_X64|IF_VMX},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVAPD[] = {
    {I_VMOVAPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10779, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMOVAPD, 2, {RM_XMM,XMMREG,0,0,0}, nasm_bytecodes+10786, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMOVAPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10793, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VMOVAPD, 2, {RM_YMM,YMMREG,0,0,0}, nasm_bytecodes+10800, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVAPS[] = {
    {I_VMOVAPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10807, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMOVAPS, 2, {RM_XMM,XMMREG,0,0,0}, nasm_bytecodes+10814, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMOVAPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10821, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VMOVAPS, 2, {RM_YMM,YMMREG,0,0,0}, nasm_bytecodes+10828, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVD[] = {
    {I_VMOVD, 2, {XMMREG,RM_GPR|BITS32,0,0,0}, nasm_bytecodes+10849, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VMOVD, 2, {RM_GPR|BITS32,XMMREG,0,0,0}, nasm_bytecodes+10863, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVDDUP[] = {
    {I_VMOVDDUP, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10877, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VMOVDDUP, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10884, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVDQA[] = {
    {I_VMOVDQA, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10891, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMOVDQA, 2, {RM_XMM,XMMREG,0,0,0}, nasm_bytecodes+10898, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMOVDQA, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10905, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VMOVDQA, 2, {RM_YMM,YMMREG,0,0,0}, nasm_bytecodes+10912, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVDQU[] = {
    {I_VMOVDQU, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10919, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMOVDQU, 2, {RM_XMM,XMMREG,0,0,0}, nasm_bytecodes+10926, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMOVDQU, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10933, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VMOVDQU, 2, {RM_YMM,YMMREG,0,0,0}, nasm_bytecodes+10940, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVHLPS[] = {
    {I_VMOVHLPS, 3, {XMMREG,XMMREG,XMMREG,0,0}, nasm_bytecodes+10947, IF_AVX|IF_SANDYBRIDGE},
    {I_VMOVHLPS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+10954, IF_AVX|IF_SANDYBRIDGE},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVHPD[] = {
    {I_VMOVHPD, 3, {XMMREG,XMMREG,MEMORY,0,0}, nasm_bytecodes+10961, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VMOVHPD, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+10968, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VMOVHPD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+10975, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVHPS[] = {
    {I_VMOVHPS, 3, {XMMREG,XMMREG,MEMORY,0,0}, nasm_bytecodes+10982, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VMOVHPS, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+10989, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VMOVHPS, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+10996, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVLHPS[] = {
    {I_VMOVLHPS, 3, {XMMREG,XMMREG,XMMREG,0,0}, nasm_bytecodes+10982, IF_AVX|IF_SANDYBRIDGE},
    {I_VMOVLHPS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+10989, IF_AVX|IF_SANDYBRIDGE},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVLPD[] = {
    {I_VMOVLPD, 3, {XMMREG,XMMREG,MEMORY,0,0}, nasm_bytecodes+11003, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VMOVLPD, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+11010, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VMOVLPD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+11017, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVLPS[] = {
    {I_VMOVLPS, 3, {XMMREG,XMMREG,MEMORY,0,0}, nasm_bytecodes+10947, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VMOVLPS, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+10954, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VMOVLPS, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+11024, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVMSKPD[] = {
    {I_VMOVMSKPD, 2, {REG64,XMMREG,0,0,0}, nasm_bytecodes+11031, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    {I_VMOVMSKPD, 2, {REG32,XMMREG,0,0,0}, nasm_bytecodes+11031, IF_AVX|IF_SANDYBRIDGE},
    {I_VMOVMSKPD, 2, {REG64,YMMREG,0,0,0}, nasm_bytecodes+11038, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    {I_VMOVMSKPD, 2, {REG32,YMMREG,0,0,0}, nasm_bytecodes+11038, IF_AVX|IF_SANDYBRIDGE},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVMSKPS[] = {
    {I_VMOVMSKPS, 2, {REG64,XMMREG,0,0,0}, nasm_bytecodes+11045, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    {I_VMOVMSKPS, 2, {REG32,XMMREG,0,0,0}, nasm_bytecodes+11045, IF_AVX|IF_SANDYBRIDGE},
    {I_VMOVMSKPS, 2, {REG64,YMMREG,0,0,0}, nasm_bytecodes+11052, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    {I_VMOVMSKPS, 2, {REG32,YMMREG,0,0,0}, nasm_bytecodes+11052, IF_AVX|IF_SANDYBRIDGE},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVNTDQ[] = {
    {I_VMOVNTDQ, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+11059, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMOVNTDQ, 2, {MEMORY,YMMREG,0,0,0}, nasm_bytecodes+11066, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVNTDQA[] = {
    {I_VMOVNTDQA, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+11073, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVNTPD[] = {
    {I_VMOVNTPD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+11080, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMOVNTPD, 2, {MEMORY,YMMREG,0,0,0}, nasm_bytecodes+11087, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVNTPS[] = {
    {I_VMOVNTPS, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+11094, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMOVNTPS, 2, {MEMORY,YMMREG,0,0,0}, nasm_bytecodes+11101, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVNTQQ[] = {
    {I_VMOVNTQQ, 2, {MEMORY,YMMREG,0,0,0}, nasm_bytecodes+11066, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVQ[] = {
    {I_VMOVQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+10835, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VMOVQ, 2, {RM_XMM,XMMREG,0,0,0}, nasm_bytecodes+10842, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VMOVQ, 2, {XMMREG,RM_GPR|BITS64,0,0,0}, nasm_bytecodes+10856, IF_AVX|IF_SANDYBRIDGE|IF_SQ|IF_LONG},
    {I_VMOVQ, 2, {RM_GPR|BITS64,XMMREG,0,0,0}, nasm_bytecodes+10870, IF_AVX|IF_SANDYBRIDGE|IF_SQ|IF_LONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVQQA[] = {
    {I_VMOVQQA, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10905, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VMOVQQA, 2, {RM_YMM,YMMREG,0,0,0}, nasm_bytecodes+10912, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVQQU[] = {
    {I_VMOVQQU, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+10933, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VMOVQQU, 2, {RM_YMM,YMMREG,0,0,0}, nasm_bytecodes+10940, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVSD[] = {
    {I_VMOVSD, 3, {XMMREG,XMMREG,XMMREG,0,0}, nasm_bytecodes+11108, IF_AVX|IF_SANDYBRIDGE},
    {I_VMOVSD, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+11115, IF_AVX|IF_SANDYBRIDGE},
    {I_VMOVSD, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+11122, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VMOVSD, 3, {XMMREG,XMMREG,XMMREG,0,0}, nasm_bytecodes+11129, IF_AVX|IF_SANDYBRIDGE},
    {I_VMOVSD, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+11136, IF_AVX|IF_SANDYBRIDGE},
    {I_VMOVSD, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+11143, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVSHDUP[] = {
    {I_VMOVSHDUP, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11150, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMOVSHDUP, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+11157, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVSLDUP[] = {
    {I_VMOVSLDUP, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11164, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMOVSLDUP, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+11171, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVSS[] = {
    {I_VMOVSS, 3, {XMMREG,XMMREG,XMMREG,0,0}, nasm_bytecodes+11178, IF_AVX|IF_SANDYBRIDGE},
    {I_VMOVSS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+11185, IF_AVX|IF_SANDYBRIDGE},
    {I_VMOVSS, 2, {XMMREG,MEMORY,0,0,0}, nasm_bytecodes+11192, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VMOVSS, 3, {XMMREG,XMMREG,XMMREG,0,0}, nasm_bytecodes+11199, IF_AVX|IF_SANDYBRIDGE},
    {I_VMOVSS, 2, {XMMREG,XMMREG,0,0,0}, nasm_bytecodes+11206, IF_AVX|IF_SANDYBRIDGE},
    {I_VMOVSS, 2, {MEMORY,XMMREG,0,0,0}, nasm_bytecodes+11213, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVUPD[] = {
    {I_VMOVUPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11220, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMOVUPD, 2, {RM_XMM,XMMREG,0,0,0}, nasm_bytecodes+11227, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMOVUPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+11234, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VMOVUPD, 2, {RM_YMM,YMMREG,0,0,0}, nasm_bytecodes+11241, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMOVUPS[] = {
    {I_VMOVUPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11248, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMOVUPS, 2, {RM_XMM,XMMREG,0,0,0}, nasm_bytecodes+11255, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMOVUPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+11262, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VMOVUPS, 2, {RM_YMM,YMMREG,0,0,0}, nasm_bytecodes+11269, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMPSADBW[] = {
    {I_VMPSADBW, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6686, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMPSADBW, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6694, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMPTRLD[] = {
    {I_VMPTRLD, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+15449, IF_VMX},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMPTRST[] = {
    {I_VMPTRST, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+18517, IF_VMX},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMREAD[] = {
    {I_VMREAD, 2, {RM_GPR|BITS32,REG32,0,0,0}, nasm_bytecodes+8176, IF_VMX|IF_NOLONG|IF_SD},
    {I_VMREAD, 2, {RM_GPR|BITS64,REG64,0,0,0}, nasm_bytecodes+8175, IF_X64|IF_VMX|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMRESUME[] = {
    {I_VMRESUME, 0, {0,0,0,0,0}, nasm_bytecodes+18522, IF_VMX},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMRUN[] = {
    {I_VMRUN, 0, {0,0,0,0,0}, nasm_bytecodes+18527, IF_X64|IF_VMX},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMSAVE[] = {
    {I_VMSAVE, 0, {0,0,0,0,0}, nasm_bytecodes+18532, IF_X64|IF_VMX},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMULPD[] = {
    {I_VMULPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11276, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMULPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11283, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMULPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+11290, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VMULPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+11297, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMULPS[] = {
    {I_VMULPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11304, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMULPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11311, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VMULPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+11318, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VMULPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+11325, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMULSD[] = {
    {I_VMULSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11332, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VMULSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11339, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMULSS[] = {
    {I_VMULSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11346, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VMULSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11353, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMWRITE[] = {
    {I_VMWRITE, 2, {REG32,RM_GPR|BITS32,0,0,0}, nasm_bytecodes+8183, IF_VMX|IF_NOLONG|IF_SD},
    {I_VMWRITE, 2, {REG64,RM_GPR|BITS64,0,0,0}, nasm_bytecodes+8182, IF_X64|IF_VMX|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMXOFF[] = {
    {I_VMXOFF, 0, {0,0,0,0,0}, nasm_bytecodes+18537, IF_VMX},
    ITEMPLATE_END
};

static const struct itemplate instrux_VMXON[] = {
    {I_VMXON, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+15448, IF_VMX},
    ITEMPLATE_END
};

static const struct itemplate instrux_VORPD[] = {
    {I_VORPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11360, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VORPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11367, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VORPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+11374, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VORPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+11381, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VORPS[] = {
    {I_VORPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11388, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VORPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11395, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VORPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+11402, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VORPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+11409, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPABSB[] = {
    {I_VPABSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11416, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPABSD[] = {
    {I_VPABSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11430, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPABSW[] = {
    {I_VPABSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11423, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPACKSSDW[] = {
    {I_VPACKSSDW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11451, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPACKSSDW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11458, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPACKSSWB[] = {
    {I_VPACKSSWB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11437, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPACKSSWB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11444, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPACKUSDW[] = {
    {I_VPACKUSDW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11479, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPACKUSDW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11486, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPACKUSWB[] = {
    {I_VPACKUSWB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11465, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPACKUSWB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11472, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPADDB[] = {
    {I_VPADDB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11493, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPADDB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11500, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPADDD[] = {
    {I_VPADDD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11521, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPADDD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11528, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPADDQ[] = {
    {I_VPADDQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11535, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPADDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11542, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPADDSB[] = {
    {I_VPADDSB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11549, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPADDSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11556, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPADDSW[] = {
    {I_VPADDSW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11563, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPADDSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11570, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPADDUSB[] = {
    {I_VPADDUSB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11577, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPADDUSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11584, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPADDUSW[] = {
    {I_VPADDUSW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11591, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPADDUSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11598, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPADDW[] = {
    {I_VPADDW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11507, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPADDW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11514, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPALIGNR[] = {
    {I_VPALIGNR, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6702, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPALIGNR, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6710, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPAND[] = {
    {I_VPAND, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11605, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPAND, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11612, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPANDN[] = {
    {I_VPANDN, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11619, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPANDN, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11626, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPAVGB[] = {
    {I_VPAVGB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11633, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPAVGB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11640, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPAVGW[] = {
    {I_VPAVGW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11647, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPAVGW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11654, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPBLENDVB[] = {
    {I_VPBLENDVB, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+4680, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPBLENDVB, 3, {XMMREG,RM_XMM,XMMREG,0,0}, nasm_bytecodes+4689, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPBLENDW[] = {
    {I_VPBLENDW, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+6718, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPBLENDW, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6726, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPCMPEQB[] = {
    {I_VPCMPEQB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11661, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPCMPEQB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11668, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPCMPEQD[] = {
    {I_VPCMPEQD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11689, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPCMPEQD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11696, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPCMPEQQ[] = {
    {I_VPCMPEQQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11703, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPCMPEQQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11710, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPCMPEQW[] = {
    {I_VPCMPEQW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11675, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPCMPEQW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11682, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPCMPESTRI[] = {
    {I_VPCMPESTRI, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6734, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPCMPESTRM[] = {
    {I_VPCMPESTRM, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6742, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPCMPGTB[] = {
    {I_VPCMPGTB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11717, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPCMPGTB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11724, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPCMPGTD[] = {
    {I_VPCMPGTD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11745, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPCMPGTD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11752, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPCMPGTQ[] = {
    {I_VPCMPGTQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11759, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPCMPGTQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11766, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPCMPGTW[] = {
    {I_VPCMPGTW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11731, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPCMPGTW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11738, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPCMPISTRI[] = {
    {I_VPCMPISTRI, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6750, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPCMPISTRM[] = {
    {I_VPCMPISTRM, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6758, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPERM2F128[] = {
    {I_VPERM2F128, 4, {YMMREG,YMMREG,RM_YMM,IMMEDIATE,0}, nasm_bytecodes+6798, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPERMIL2PD[] = {
    {I_VPERMIL2PD, 5, {XMMREG,XMMREG,RM_XMM,XMMREG,IMMEDIATE}, nasm_bytecodes+4806, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPERMIL2PD, 5, {XMMREG,XMMREG,XMMREG,RM_XMM,IMMEDIATE}, nasm_bytecodes+4815, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPERMIL2PD, 5, {YMMREG,YMMREG,RM_YMM,YMMREG,IMMEDIATE}, nasm_bytecodes+4824, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VPERMIL2PD, 5, {YMMREG,YMMREG,YMMREG,RM_YMM,IMMEDIATE}, nasm_bytecodes+4833, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPERMIL2PS[] = {
    {I_VPERMIL2PS, 5, {XMMREG,XMMREG,RM_XMM,XMMREG,IMMEDIATE}, nasm_bytecodes+4950, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPERMIL2PS, 5, {XMMREG,XMMREG,XMMREG,RM_XMM,IMMEDIATE}, nasm_bytecodes+4959, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPERMIL2PS, 5, {YMMREG,YMMREG,RM_YMM,YMMREG,IMMEDIATE}, nasm_bytecodes+4968, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VPERMIL2PS, 5, {YMMREG,YMMREG,YMMREG,RM_YMM,IMMEDIATE}, nasm_bytecodes+4977, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPERMILMO2PD[] = {
    {I_VPERMILMO2PD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+4734, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPERMILMO2PD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+4743, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPERMILMO2PD, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+4752, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VPERMILMO2PD, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+4761, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPERMILMO2PS[] = {
    {I_VPERMILMO2PS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+4878, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPERMILMO2PS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+4887, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPERMILMO2PS, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+4896, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VPERMILMO2PS, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+4905, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPERMILMZ2PD[] = {
    {I_VPERMILMZ2PD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+4770, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPERMILMZ2PD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+4779, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPERMILMZ2PD, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+4788, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VPERMILMZ2PD, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+4797, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPERMILMZ2PS[] = {
    {I_VPERMILMZ2PS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+4914, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPERMILMZ2PS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+4923, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPERMILMZ2PS, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+4932, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VPERMILMZ2PS, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+4941, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPERMILPD[] = {
    {I_VPERMILPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11773, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPERMILPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+11780, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VPERMILPD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6766, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPERMILPD, 3, {YMMREG,RM_YMM,IMMEDIATE,0,0}, nasm_bytecodes+6774, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPERMILPS[] = {
    {I_VPERMILPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11787, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPERMILPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+11794, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VPERMILPS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6782, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPERMILPS, 3, {YMMREG,RM_YMM,IMMEDIATE,0,0}, nasm_bytecodes+6790, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPERMILTD2PD[] = {
    {I_VPERMILTD2PD, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+4698, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPERMILTD2PD, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+4707, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPERMILTD2PD, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+4716, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VPERMILTD2PD, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+4725, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPERMILTD2PS[] = {
    {I_VPERMILTD2PS, 4, {XMMREG,XMMREG,RM_XMM,XMMREG,0}, nasm_bytecodes+4842, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPERMILTD2PS, 4, {XMMREG,XMMREG,XMMREG,RM_XMM,0}, nasm_bytecodes+4851, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPERMILTD2PS, 4, {YMMREG,YMMREG,RM_YMM,YMMREG,0}, nasm_bytecodes+4860, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VPERMILTD2PS, 4, {YMMREG,YMMREG,YMMREG,RM_YMM,0}, nasm_bytecodes+4869, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPEXTRB[] = {
    {I_VPEXTRB, 3, {REG64,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6806, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    {I_VPEXTRB, 3, {REG32,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6806, IF_AVX|IF_SANDYBRIDGE},
    {I_VPEXTRB, 3, {MEMORY,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6806, IF_AVX|IF_SANDYBRIDGE|IF_SB},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPEXTRD[] = {
    {I_VPEXTRD, 3, {REG64,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6830, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    {I_VPEXTRD, 3, {RM_GPR|BITS32,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6830, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPEXTRQ[] = {
    {I_VPEXTRQ, 3, {RM_GPR|BITS64,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6838, IF_AVX|IF_SANDYBRIDGE|IF_SQ|IF_LONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPEXTRW[] = {
    {I_VPEXTRW, 3, {REG64,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6814, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    {I_VPEXTRW, 3, {REG32,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6814, IF_AVX|IF_SANDYBRIDGE},
    {I_VPEXTRW, 3, {MEMORY,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6814, IF_AVX|IF_SANDYBRIDGE|IF_SW},
    {I_VPEXTRW, 3, {REG64,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6822, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    {I_VPEXTRW, 3, {REG32,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6822, IF_AVX|IF_SANDYBRIDGE},
    {I_VPEXTRW, 3, {MEMORY,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6822, IF_AVX|IF_SANDYBRIDGE|IF_SW},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPHADDD[] = {
    {I_VPHADDD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11815, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPHADDD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11822, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPHADDSW[] = {
    {I_VPHADDSW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11829, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPHADDSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11836, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPHADDW[] = {
    {I_VPHADDW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11801, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPHADDW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11808, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPHMINPOSUW[] = {
    {I_VPHMINPOSUW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11843, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPHSUBD[] = {
    {I_VPHSUBD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11864, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPHSUBD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11871, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPHSUBSW[] = {
    {I_VPHSUBSW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11878, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPHSUBSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11885, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPHSUBW[] = {
    {I_VPHSUBW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11850, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPHSUBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11857, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPINSRB[] = {
    {I_VPINSRB, 4, {XMMREG,XMMREG,REG32,IMMEDIATE,0}, nasm_bytecodes+6846, IF_AVX|IF_SANDYBRIDGE},
    {I_VPINSRB, 3, {XMMREG,REG32,IMMEDIATE,0,0}, nasm_bytecodes+6854, IF_AVX|IF_SANDYBRIDGE},
    {I_VPINSRB, 4, {XMMREG,XMMREG,MEMORY,IMMEDIATE,0}, nasm_bytecodes+6846, IF_AVX|IF_SANDYBRIDGE|IF_SB},
    {I_VPINSRB, 4, {XMMREG,REG32,MEMORY,IMMEDIATE,0}, nasm_bytecodes+6854, IF_AVX|IF_SANDYBRIDGE|IF_SB},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPINSRD[] = {
    {I_VPINSRD, 4, {XMMREG,XMMREG,RM_GPR|BITS32,IMMEDIATE,0}, nasm_bytecodes+6878, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VPINSRD, 3, {XMMREG,RM_GPR|BITS32,IMMEDIATE,0,0}, nasm_bytecodes+6886, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPINSRQ[] = {
    {I_VPINSRQ, 4, {XMMREG,XMMREG,RM_GPR|BITS64,IMMEDIATE,0}, nasm_bytecodes+6894, IF_AVX|IF_SANDYBRIDGE|IF_SQ|IF_LONG},
    {I_VPINSRQ, 3, {XMMREG,RM_GPR|BITS64,IMMEDIATE,0,0}, nasm_bytecodes+6902, IF_AVX|IF_SANDYBRIDGE|IF_SD|IF_LONG},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPINSRW[] = {
    {I_VPINSRW, 4, {XMMREG,XMMREG,REG32,IMMEDIATE,0}, nasm_bytecodes+6862, IF_AVX|IF_SANDYBRIDGE},
    {I_VPINSRW, 3, {XMMREG,REG32,IMMEDIATE,0,0}, nasm_bytecodes+6870, IF_AVX|IF_SANDYBRIDGE},
    {I_VPINSRW, 4, {XMMREG,XMMREG,MEMORY,IMMEDIATE,0}, nasm_bytecodes+6862, IF_AVX|IF_SANDYBRIDGE|IF_SW},
    {I_VPINSRW, 4, {XMMREG,REG32,MEMORY,IMMEDIATE,0}, nasm_bytecodes+6870, IF_AVX|IF_SANDYBRIDGE|IF_SW},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMADDUBSW[] = {
    {I_VPMADDUBSW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11906, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPMADDUBSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11913, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMADDWD[] = {
    {I_VPMADDWD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11892, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPMADDWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11899, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMAXSB[] = {
    {I_VPMAXSB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11920, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPMAXSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11927, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMAXSD[] = {
    {I_VPMAXSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11948, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPMAXSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11955, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMAXSW[] = {
    {I_VPMAXSW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11934, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPMAXSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11941, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMAXUB[] = {
    {I_VPMAXUB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11962, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPMAXUB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11969, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMAXUD[] = {
    {I_VPMAXUD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11990, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPMAXUD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11997, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMAXUW[] = {
    {I_VPMAXUW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+11976, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPMAXUW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+11983, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMINSB[] = {
    {I_VPMINSB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12004, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPMINSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12011, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMINSD[] = {
    {I_VPMINSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12032, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPMINSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12039, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMINSW[] = {
    {I_VPMINSW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12018, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPMINSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12025, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMINUB[] = {
    {I_VPMINUB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12046, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPMINUB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12053, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMINUD[] = {
    {I_VPMINUD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12074, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPMINUD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12081, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMINUW[] = {
    {I_VPMINUW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12060, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPMINUW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12067, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMOVMSKB[] = {
    {I_VPMOVMSKB, 2, {REG64,XMMREG,0,0,0}, nasm_bytecodes+12088, IF_AVX|IF_SANDYBRIDGE|IF_LONG},
    {I_VPMOVMSKB, 2, {REG32,XMMREG,0,0,0}, nasm_bytecodes+12088, IF_AVX|IF_SANDYBRIDGE},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMOVSXBD[] = {
    {I_VPMOVSXBD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12102, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMOVSXBQ[] = {
    {I_VPMOVSXBQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12109, IF_AVX|IF_SANDYBRIDGE|IF_SW},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMOVSXBW[] = {
    {I_VPMOVSXBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12095, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMOVSXDQ[] = {
    {I_VPMOVSXDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12130, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMOVSXWD[] = {
    {I_VPMOVSXWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12116, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMOVSXWQ[] = {
    {I_VPMOVSXWQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12123, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMOVZXBD[] = {
    {I_VPMOVZXBD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12144, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMOVZXBQ[] = {
    {I_VPMOVZXBQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12151, IF_AVX|IF_SANDYBRIDGE|IF_SW},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMOVZXBW[] = {
    {I_VPMOVZXBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12137, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMOVZXDQ[] = {
    {I_VPMOVZXDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12172, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMOVZXWD[] = {
    {I_VPMOVZXWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12158, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMOVZXWQ[] = {
    {I_VPMOVZXWQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12165, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMULDQ[] = {
    {I_VPMULDQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12263, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPMULDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12270, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMULHRSW[] = {
    {I_VPMULHRSW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12193, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPMULHRSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12200, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMULHUW[] = {
    {I_VPMULHUW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12179, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPMULHUW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12186, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMULHW[] = {
    {I_VPMULHW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12207, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPMULHW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12214, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMULLD[] = {
    {I_VPMULLD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12235, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPMULLD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12242, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMULLW[] = {
    {I_VPMULLW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12221, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPMULLW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12228, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPMULUDQ[] = {
    {I_VPMULUDQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12249, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPMULUDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12256, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPOR[] = {
    {I_VPOR, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12277, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPOR, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12284, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSADBW[] = {
    {I_VPSADBW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12291, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSADBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12298, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSHUFB[] = {
    {I_VPSHUFB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12305, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSHUFB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12312, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSHUFD[] = {
    {I_VPSHUFD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6910, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSHUFHW[] = {
    {I_VPSHUFHW, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6918, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSHUFLW[] = {
    {I_VPSHUFLW, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+6926, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSIGNB[] = {
    {I_VPSIGNB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12319, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSIGNB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12326, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSIGND[] = {
    {I_VPSIGND, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12347, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSIGND, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12354, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSIGNW[] = {
    {I_VPSIGNW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12333, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSIGNW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12340, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSLLD[] = {
    {I_VPSLLD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12375, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSLLD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12382, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSLLD, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6982, IF_AVX|IF_SANDYBRIDGE},
    {I_VPSLLD, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+6990, IF_AVX|IF_SANDYBRIDGE},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSLLDQ[] = {
    {I_VPSLLDQ, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6934, IF_AVX|IF_SANDYBRIDGE},
    {I_VPSLLDQ, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+6942, IF_AVX|IF_SANDYBRIDGE},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSLLQ[] = {
    {I_VPSLLQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12389, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSLLQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12396, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSLLQ, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6998, IF_AVX|IF_SANDYBRIDGE},
    {I_VPSLLQ, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7006, IF_AVX|IF_SANDYBRIDGE},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSLLW[] = {
    {I_VPSLLW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12361, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSLLW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12368, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSLLW, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6966, IF_AVX|IF_SANDYBRIDGE},
    {I_VPSLLW, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+6974, IF_AVX|IF_SANDYBRIDGE},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSRAD[] = {
    {I_VPSRAD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12417, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSRAD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12424, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSRAD, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+7030, IF_AVX|IF_SANDYBRIDGE},
    {I_VPSRAD, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7038, IF_AVX|IF_SANDYBRIDGE},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSRAW[] = {
    {I_VPSRAW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12403, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSRAW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12410, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSRAW, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+7014, IF_AVX|IF_SANDYBRIDGE},
    {I_VPSRAW, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7022, IF_AVX|IF_SANDYBRIDGE},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSRLD[] = {
    {I_VPSRLD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12445, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSRLD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12452, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSRLD, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+7062, IF_AVX|IF_SANDYBRIDGE},
    {I_VPSRLD, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7070, IF_AVX|IF_SANDYBRIDGE},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSRLDQ[] = {
    {I_VPSRLDQ, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+6950, IF_AVX|IF_SANDYBRIDGE},
    {I_VPSRLDQ, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+6958, IF_AVX|IF_SANDYBRIDGE},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSRLQ[] = {
    {I_VPSRLQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12459, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSRLQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12466, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSRLQ, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+7078, IF_AVX|IF_SANDYBRIDGE},
    {I_VPSRLQ, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7086, IF_AVX|IF_SANDYBRIDGE},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSRLW[] = {
    {I_VPSRLW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12431, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSRLW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12438, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSRLW, 3, {XMMREG,XMMREG,IMMEDIATE,0,0}, nasm_bytecodes+7046, IF_AVX|IF_SANDYBRIDGE},
    {I_VPSRLW, 2, {XMMREG,IMMEDIATE,0,0,0}, nasm_bytecodes+7054, IF_AVX|IF_SANDYBRIDGE},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSUBB[] = {
    {I_VPSUBB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12487, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSUBB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12494, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSUBD[] = {
    {I_VPSUBD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12515, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSUBD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12522, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSUBQ[] = {
    {I_VPSUBQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12529, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSUBQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12536, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSUBSB[] = {
    {I_VPSUBSB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12543, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSUBSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12550, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSUBSW[] = {
    {I_VPSUBSW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12557, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSUBSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12564, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSUBUSB[] = {
    {I_VPSUBUSB, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12571, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSUBUSB, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12578, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSUBUSW[] = {
    {I_VPSUBUSW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12585, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSUBUSW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12592, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPSUBW[] = {
    {I_VPSUBW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12501, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPSUBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12508, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPTEST[] = {
    {I_VPTEST, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12473, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPTEST, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+12480, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPUNPCKHBW[] = {
    {I_VPUNPCKHBW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12599, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPUNPCKHBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12606, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPUNPCKHDQ[] = {
    {I_VPUNPCKHDQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12627, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPUNPCKHDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12634, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPUNPCKHQDQ[] = {
    {I_VPUNPCKHQDQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12641, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPUNPCKHQDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12648, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPUNPCKHWD[] = {
    {I_VPUNPCKHWD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12613, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPUNPCKHWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12620, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPUNPCKLBW[] = {
    {I_VPUNPCKLBW, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12655, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPUNPCKLBW, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12662, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPUNPCKLDQ[] = {
    {I_VPUNPCKLDQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12683, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPUNPCKLDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12690, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPUNPCKLQDQ[] = {
    {I_VPUNPCKLQDQ, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12697, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPUNPCKLQDQ, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12704, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPUNPCKLWD[] = {
    {I_VPUNPCKLWD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12669, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPUNPCKLWD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12676, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VPXOR[] = {
    {I_VPXOR, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12711, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VPXOR, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12718, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_VRCPPS[] = {
    {I_VRCPPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12725, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VRCPPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+12732, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VRCPSS[] = {
    {I_VRCPSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12739, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VRCPSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12746, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VROUNDPD[] = {
    {I_VROUNDPD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+7094, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VROUNDPD, 3, {YMMREG,RM_YMM,IMMEDIATE,0,0}, nasm_bytecodes+7102, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VROUNDPS[] = {
    {I_VROUNDPS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+7110, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VROUNDPS, 3, {YMMREG,RM_YMM,IMMEDIATE,0,0}, nasm_bytecodes+7118, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VROUNDSD[] = {
    {I_VROUNDSD, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+7126, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VROUNDSD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+7134, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VROUNDSS[] = {
    {I_VROUNDSS, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+7142, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VROUNDSS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+7150, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VRSQRTPS[] = {
    {I_VRSQRTPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12753, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VRSQRTPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+12760, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VRSQRTSS[] = {
    {I_VRSQRTSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12767, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VRSQRTSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12774, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VSHUFPD[] = {
    {I_VSHUFPD, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+7158, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VSHUFPD, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+7166, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VSHUFPD, 4, {YMMREG,YMMREG,RM_YMM,IMMEDIATE,0}, nasm_bytecodes+7174, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VSHUFPD, 3, {YMMREG,RM_YMM,IMMEDIATE,0,0}, nasm_bytecodes+7182, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VSHUFPS[] = {
    {I_VSHUFPS, 4, {XMMREG,XMMREG,RM_XMM,IMMEDIATE,0}, nasm_bytecodes+7190, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VSHUFPS, 3, {XMMREG,RM_XMM,IMMEDIATE,0,0}, nasm_bytecodes+7198, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VSHUFPS, 4, {YMMREG,YMMREG,RM_YMM,IMMEDIATE,0}, nasm_bytecodes+7206, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VSHUFPS, 3, {YMMREG,RM_YMM,IMMEDIATE,0,0}, nasm_bytecodes+7214, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VSQRTPD[] = {
    {I_VSQRTPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12781, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VSQRTPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+12788, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VSQRTPS[] = {
    {I_VSQRTPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12795, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VSQRTPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+12802, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VSQRTSD[] = {
    {I_VSQRTSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12809, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VSQRTSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12816, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VSQRTSS[] = {
    {I_VSQRTSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12823, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VSQRTSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12830, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VSTMXCSR[] = {
    {I_VSTMXCSR, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+12837, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VSUBPD[] = {
    {I_VSUBPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12844, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VSUBPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12851, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VSUBPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+12858, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VSUBPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+12865, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VSUBPS[] = {
    {I_VSUBPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12872, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VSUBPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12879, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VSUBPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+12886, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VSUBPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+12893, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VSUBSD[] = {
    {I_VSUBSD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12900, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    {I_VSUBSD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12907, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VSUBSS[] = {
    {I_VSUBSS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12914, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    {I_VSUBSS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12921, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VTESTPD[] = {
    {I_VTESTPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12942, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VTESTPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+12949, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VTESTPS[] = {
    {I_VTESTPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12928, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VTESTPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+12935, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VUCOMISD[] = {
    {I_VUCOMISD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12956, IF_AVX|IF_SANDYBRIDGE|IF_SQ},
    ITEMPLATE_END
};

static const struct itemplate instrux_VUCOMISS[] = {
    {I_VUCOMISS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12963, IF_AVX|IF_SANDYBRIDGE|IF_SD},
    ITEMPLATE_END
};

static const struct itemplate instrux_VUNPCKHPD[] = {
    {I_VUNPCKHPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12970, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VUNPCKHPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+12977, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VUNPCKHPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+12984, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VUNPCKHPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+12991, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VUNPCKHPS[] = {
    {I_VUNPCKHPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+12998, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VUNPCKHPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+13005, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VUNPCKHPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+13012, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VUNPCKHPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+13019, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VUNPCKLPD[] = {
    {I_VUNPCKLPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+13026, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VUNPCKLPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+13033, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VUNPCKLPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+13040, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VUNPCKLPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+13047, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VUNPCKLPS[] = {
    {I_VUNPCKLPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+13054, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VUNPCKLPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+13061, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VUNPCKLPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+13068, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VUNPCKLPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+13075, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VXORPD[] = {
    {I_VXORPD, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+13082, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VXORPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+13089, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VXORPD, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+13096, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VXORPD, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+13103, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VXORPS[] = {
    {I_VXORPS, 3, {XMMREG,XMMREG,RM_XMM,0,0}, nasm_bytecodes+13110, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VXORPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+13117, IF_AVX|IF_SANDYBRIDGE|IF_SO},
    {I_VXORPS, 3, {YMMREG,YMMREG,RM_YMM,0,0}, nasm_bytecodes+13124, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    {I_VXORPS, 2, {YMMREG,RM_YMM,0,0,0}, nasm_bytecodes+13131, IF_AVX|IF_SANDYBRIDGE|IF_SY},
    ITEMPLATE_END
};

static const struct itemplate instrux_VZEROALL[] = {
    {I_VZEROALL, 0, {0,0,0,0,0}, nasm_bytecodes+15478, IF_AVX|IF_SANDYBRIDGE},
    ITEMPLATE_END
};

static const struct itemplate instrux_VZEROUPPER[] = {
    {I_VZEROUPPER, 0, {0,0,0,0,0}, nasm_bytecodes+15484, IF_AVX|IF_SANDYBRIDGE},
    ITEMPLATE_END
};

static const struct itemplate instrux_WAIT[] = {
    {I_WAIT, 0, {0,0,0,0,0}, nasm_bytecodes+19694, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_WBINVD[] = {
    {I_WBINVD, 0, {0,0,0,0,0}, nasm_bytecodes+19575, IF_486|IF_PRIV},
    ITEMPLATE_END
};

static const struct itemplate instrux_WRMSR[] = {
    {I_WRMSR, 0, {0,0,0,0,0}, nasm_bytecodes+19579, IF_PENT|IF_PRIV},
    ITEMPLATE_END
};

static const struct itemplate instrux_WRSHR[] = {
    {I_WRSHR, 1, {RM_GPR|BITS32,0,0,0,0}, nasm_bytecodes+14290, IF_P6|IF_CYRIX|IF_SMM},
    ITEMPLATE_END
};

static const struct itemplate instrux_XADD[] = {
    {I_XADD, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+18382, IF_486|IF_SM},
    {I_XADD, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+18382, IF_486},
    {I_XADD, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+14296, IF_486|IF_SM},
    {I_XADD, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+14296, IF_486},
    {I_XADD, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+14302, IF_486|IF_SM},
    {I_XADD, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+14302, IF_486},
    {I_XADD, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+14308, IF_X64|IF_SM},
    {I_XADD, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+14308, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_XBTS[] = {
    {I_XBTS, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+14314, IF_386|IF_SW|IF_UNDOC},
    {I_XBTS, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+14314, IF_386|IF_UNDOC},
    {I_XBTS, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+14320, IF_386|IF_SD|IF_UNDOC},
    {I_XBTS, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+14320, IF_386|IF_UNDOC},
    ITEMPLATE_END
};

static const struct itemplate instrux_XCHG[] = {
    {I_XCHG, 2, {REG_AX,REG16,0,0,0}, nasm_bytecodes+19583, IF_8086},
    {I_XCHG, 2, {REG_EAX,REG32NA,0,0,0}, nasm_bytecodes+19587, IF_386},
    {I_XCHG, 2, {REG_RAX,REG64,0,0,0}, nasm_bytecodes+19591, IF_X64},
    {I_XCHG, 2, {REG16,REG_AX,0,0,0}, nasm_bytecodes+19595, IF_8086},
    {I_XCHG, 2, {REG32NA,REG_EAX,0,0,0}, nasm_bytecodes+19599, IF_386},
    {I_XCHG, 2, {REG64,REG_RAX,0,0,0}, nasm_bytecodes+19603, IF_X64},
    {I_XCHG, 2, {REG_EAX,REG_EAX,0,0,0}, nasm_bytecodes+19607, IF_386|IF_NOLONG},
    {I_XCHG, 2, {REG8,MEMORY,0,0,0}, nasm_bytecodes+19611, IF_8086|IF_SM},
    {I_XCHG, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+19611, IF_8086},
    {I_XCHG, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+18387, IF_8086|IF_SM},
    {I_XCHG, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+18387, IF_8086},
    {I_XCHG, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+18392, IF_386|IF_SM},
    {I_XCHG, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+18392, IF_386},
    {I_XCHG, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+18397, IF_X64|IF_SM},
    {I_XCHG, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+18397, IF_X64},
    {I_XCHG, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+19615, IF_8086|IF_SM},
    {I_XCHG, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+19615, IF_8086},
    {I_XCHG, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+18402, IF_8086|IF_SM},
    {I_XCHG, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+18402, IF_8086},
    {I_XCHG, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+18407, IF_386|IF_SM},
    {I_XCHG, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+18407, IF_386},
    {I_XCHG, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+18412, IF_X64|IF_SM},
    {I_XCHG, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+18412, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_XCRYPTCBC[] = {
    {I_XCRYPTCBC, 0, {0,0,0,0,0}, nasm_bytecodes+15496, IF_PENT|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_XCRYPTCFB[] = {
    {I_XCRYPTCFB, 0, {0,0,0,0,0}, nasm_bytecodes+15508, IF_PENT|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_XCRYPTCTR[] = {
    {I_XCRYPTCTR, 0, {0,0,0,0,0}, nasm_bytecodes+15502, IF_PENT|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_XCRYPTECB[] = {
    {I_XCRYPTECB, 0, {0,0,0,0,0}, nasm_bytecodes+15490, IF_PENT|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_XCRYPTOFB[] = {
    {I_XCRYPTOFB, 0, {0,0,0,0,0}, nasm_bytecodes+15514, IF_PENT|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_XGETBV[] = {
    {I_XGETBV, 0, {0,0,0,0,0}, nasm_bytecodes+14608, IF_NEHALEM},
    ITEMPLATE_END
};

static const struct itemplate instrux_XLAT[] = {
    {I_XLAT, 0, {0,0,0,0,0}, nasm_bytecodes+19697, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_XLATB[] = {
    {I_XLATB, 0, {0,0,0,0,0}, nasm_bytecodes+19697, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_XOR[] = {
    {I_XOR, 2, {MEMORY,REG8,0,0,0}, nasm_bytecodes+19619, IF_8086|IF_SM},
    {I_XOR, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+19619, IF_8086},
    {I_XOR, 2, {MEMORY,REG16,0,0,0}, nasm_bytecodes+18417, IF_8086|IF_SM},
    {I_XOR, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+18417, IF_8086},
    {I_XOR, 2, {MEMORY,REG32,0,0,0}, nasm_bytecodes+18422, IF_386|IF_SM},
    {I_XOR, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+18422, IF_386},
    {I_XOR, 2, {MEMORY,REG64,0,0,0}, nasm_bytecodes+18427, IF_X64|IF_SM},
    {I_XOR, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+18427, IF_X64},
    {I_XOR, 2, {REG8,MEMORY,0,0,0}, nasm_bytecodes+12154, IF_8086|IF_SM},
    {I_XOR, 2, {REG8,REG8,0,0,0}, nasm_bytecodes+12154, IF_8086},
    {I_XOR, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+18432, IF_8086|IF_SM},
    {I_XOR, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+18432, IF_8086},
    {I_XOR, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+18437, IF_386|IF_SM},
    {I_XOR, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+18437, IF_386},
    {I_XOR, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+18442, IF_X64|IF_SM},
    {I_XOR, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+18442, IF_X64},
    {I_XOR, 2, {RM_GPR|BITS16,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+14326, IF_8086},
    {I_XOR, 2, {RM_GPR|BITS32,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+14332, IF_386},
    {I_XOR, 2, {RM_GPR|BITS64,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+14338, IF_X64},
    {I_XOR, 2, {REG_AL,IMMEDIATE,0,0,0}, nasm_bytecodes+19623, IF_8086|IF_SM},
    {I_XOR, 2, {REG_AX,IMMEDIATE,0,0,0}, nasm_bytecodes+18447, IF_8086|IF_SM},
    {I_XOR, 2, {REG_EAX,IMMEDIATE,0,0,0}, nasm_bytecodes+18452, IF_386|IF_SM},
    {I_XOR, 2, {REG_RAX,IMMEDIATE,0,0,0}, nasm_bytecodes+18457, IF_X64|IF_SM},
    {I_XOR, 2, {RM_GPR|BITS8,IMMEDIATE,0,0,0}, nasm_bytecodes+18462, IF_8086|IF_SM},
    {I_XOR, 2, {RM_GPR|BITS16,IMMEDIATE,0,0,0}, nasm_bytecodes+14344, IF_8086|IF_SM},
    {I_XOR, 2, {RM_GPR|BITS32,IMMEDIATE,0,0,0}, nasm_bytecodes+14350, IF_386|IF_SM},
    {I_XOR, 2, {RM_GPR|BITS64,IMMEDIATE,0,0,0}, nasm_bytecodes+14356, IF_X64|IF_SM},
    {I_XOR, 2, {MEMORY,IMMEDIATE|BITS8,0,0,0}, nasm_bytecodes+18462, IF_8086|IF_SM},
    {I_XOR, 2, {MEMORY,IMMEDIATE|BITS16,0,0,0}, nasm_bytecodes+14344, IF_8086|IF_SM},
    {I_XOR, 2, {MEMORY,IMMEDIATE|BITS32,0,0,0}, nasm_bytecodes+14350, IF_386|IF_SM},
    ITEMPLATE_END
};

static const struct itemplate instrux_XORPD[] = {
    {I_XORPD, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+15376, IF_WILLAMETTE|IF_SSE2|IF_SO},
    ITEMPLATE_END
};

static const struct itemplate instrux_XORPS[] = {
    {I_XORPS, 2, {XMMREG,RM_XMM,0,0,0}, nasm_bytecodes+14602, IF_KATMAI|IF_SSE},
    ITEMPLATE_END
};

static const struct itemplate instrux_XRSTOR[] = {
    {I_XRSTOR, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+14626, IF_NEHALEM},
    ITEMPLATE_END
};

static const struct itemplate instrux_XSAVE[] = {
    {I_XSAVE, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+14620, IF_NEHALEM},
    ITEMPLATE_END
};

static const struct itemplate instrux_XSETBV[] = {
    {I_XSETBV, 0, {0,0,0,0,0}, nasm_bytecodes+14614, IF_NEHALEM|IF_PRIV},
    ITEMPLATE_END
};

static const struct itemplate instrux_XSHA1[] = {
    {I_XSHA1, 0, {0,0,0,0,0}, nasm_bytecodes+15526, IF_PENT|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_XSHA256[] = {
    {I_XSHA256, 0, {0,0,0,0,0}, nasm_bytecodes+15532, IF_PENT|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_XSTORE[] = {
    {I_XSTORE, 0, {0,0,0,0,0}, nasm_bytecodes+18542, IF_PENT|IF_CYRIX},
    ITEMPLATE_END
};

static const struct itemplate instrux_CMOVcc[] = {
    {I_CMOVcc, 2, {REG16,MEMORY,0,0,0}, nasm_bytecodes+7811, IF_P6|IF_SM},
    {I_CMOVcc, 2, {REG16,REG16,0,0,0}, nasm_bytecodes+7811, IF_P6},
    {I_CMOVcc, 2, {REG32,MEMORY,0,0,0}, nasm_bytecodes+7818, IF_P6|IF_SM},
    {I_CMOVcc, 2, {REG32,REG32,0,0,0}, nasm_bytecodes+7818, IF_P6},
    {I_CMOVcc, 2, {REG64,MEMORY,0,0,0}, nasm_bytecodes+7825, IF_X64|IF_SM},
    {I_CMOVcc, 2, {REG64,REG64,0,0,0}, nasm_bytecodes+7825, IF_X64},
    ITEMPLATE_END
};

static const struct itemplate instrux_Jcc[] = {
    {I_Jcc, 1, {IMMEDIATE|NEAR,0,0,0,0}, nasm_bytecodes+7832, IF_386},
    {I_Jcc, 1, {IMMEDIATE|BITS16|NEAR,0,0,0,0}, nasm_bytecodes+7839, IF_386},
    {I_Jcc, 1, {IMMEDIATE|BITS32|NEAR,0,0,0,0}, nasm_bytecodes+7846, IF_386},
    {I_Jcc, 1, {IMMEDIATE|SHORT,0,0,0,0}, nasm_bytecodes+18468, IF_8086},
    {I_Jcc, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+18467, IF_8086},
    {I_Jcc, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+7847, IF_386},
    {I_Jcc, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+7853, IF_8086},
    {I_Jcc, 1, {IMMEDIATE,0,0,0,0}, nasm_bytecodes+18468, IF_8086},
    ITEMPLATE_END
};

static const struct itemplate instrux_SETcc[] = {
    {I_SETcc, 1, {MEMORY,0,0,0,0}, nasm_bytecodes+14362, IF_386|IF_SB},
    {I_SETcc, 1, {REG8,0,0,0,0}, nasm_bytecodes+14362, IF_386},
    ITEMPLATE_END
};

const struct itemplate * const nasm_instructions[] = {
    instrux_AAA,
    instrux_AAD,
    instrux_AAM,
    instrux_AAS,
    instrux_ADC,
    instrux_ADD,
    instrux_ADDPD,
    instrux_ADDPS,
    instrux_ADDSD,
    instrux_ADDSS,
    instrux_ADDSUBPD,
    instrux_ADDSUBPS,
    instrux_AESDEC,
    instrux_AESDECLAST,
    instrux_AESENC,
    instrux_AESENCLAST,
    instrux_AESIMC,
    instrux_AESKEYGENASSIST,
    instrux_AND,
    instrux_ANDNPD,
    instrux_ANDNPS,
    instrux_ANDPD,
    instrux_ANDPS,
    instrux_ARPL,
    instrux_BB0_RESET,
    instrux_BB1_RESET,
    instrux_BLENDPD,
    instrux_BLENDPS,
    instrux_BLENDVPD,
    instrux_BLENDVPS,
    instrux_BOUND,
    instrux_BSF,
    instrux_BSR,
    instrux_BSWAP,
    instrux_BT,
    instrux_BTC,
    instrux_BTR,
    instrux_BTS,
    instrux_CALL,
    instrux_CBW,
    instrux_CDQ,
    instrux_CDQE,
    instrux_CLC,
    instrux_CLD,
    instrux_CLFLUSH,
    instrux_CLGI,
    instrux_CLI,
    instrux_CLTS,
    instrux_CMC,
    instrux_CMP,
    instrux_CMPEQPD,
    instrux_CMPEQPS,
    instrux_CMPEQSD,
    instrux_CMPEQSS,
    instrux_CMPLEPD,
    instrux_CMPLEPS,
    instrux_CMPLESD,
    instrux_CMPLESS,
    instrux_CMPLTPD,
    instrux_CMPLTPS,
    instrux_CMPLTSD,
    instrux_CMPLTSS,
    instrux_CMPNEQPD,
    instrux_CMPNEQPS,
    instrux_CMPNEQSD,
    instrux_CMPNEQSS,
    instrux_CMPNLEPD,
    instrux_CMPNLEPS,
    instrux_CMPNLESD,
    instrux_CMPNLESS,
    instrux_CMPNLTPD,
    instrux_CMPNLTPS,
    instrux_CMPNLTSD,
    instrux_CMPNLTSS,
    instrux_CMPORDPD,
    instrux_CMPORDPS,
    instrux_CMPORDSD,
    instrux_CMPORDSS,
    instrux_CMPPD,
    instrux_CMPPS,
    instrux_CMPSB,
    instrux_CMPSD,
    instrux_CMPSQ,
    instrux_CMPSS,
    instrux_CMPSW,
    instrux_CMPUNORDPD,
    instrux_CMPUNORDPS,
    instrux_CMPUNORDSD,
    instrux_CMPUNORDSS,
    instrux_CMPXCHG,
    instrux_CMPXCHG16B,
    instrux_CMPXCHG486,
    instrux_CMPXCHG8B,
    instrux_COMEQPD,
    instrux_COMEQPS,
    instrux_COMEQSD,
    instrux_COMEQSS,
    instrux_COMFALSEPD,
    instrux_COMFALSEPS,
    instrux_COMFALSESD,
    instrux_COMFALSESS,
    instrux_COMISD,
    instrux_COMISS,
    instrux_COMLEPD,
    instrux_COMLEPS,
    instrux_COMLESD,
    instrux_COMLESS,
    instrux_COMLTPD,
    instrux_COMLTPS,
    instrux_COMLTSD,
    instrux_COMLTSS,
    instrux_COMNEQPD,
    instrux_COMNEQPS,
    instrux_COMNEQSD,
    instrux_COMNEQSS,
    instrux_COMNLEPD,
    instrux_COMNLEPS,
    instrux_COMNLESD,
    instrux_COMNLESS,
    instrux_COMNLTPD,
    instrux_COMNLTPS,
    instrux_COMNLTSD,
    instrux_COMNLTSS,
    instrux_COMORDPD,
    instrux_COMORDPS,
    instrux_COMORDSD,
    instrux_COMORDSS,
    instrux_COMPD,
    instrux_COMPS,
    instrux_COMSD,
    instrux_COMSS,
    instrux_COMTRUEPD,
    instrux_COMTRUEPS,
    instrux_COMTRUESD,
    instrux_COMTRUESS,
    instrux_COMUEQPD,
    instrux_COMUEQPS,
    instrux_COMUEQSD,
    instrux_COMUEQSS,
    instrux_COMULEPD,
    instrux_COMULEPS,
    instrux_COMULESD,
    instrux_COMULESS,
    instrux_COMULTPD,
    instrux_COMULTPS,
    instrux_COMULTSD,
    instrux_COMULTSS,
    instrux_COMUNEQPD,
    instrux_COMUNEQPS,
    instrux_COMUNEQSD,
    instrux_COMUNEQSS,
    instrux_COMUNLEPD,
    instrux_COMUNLEPS,
    instrux_COMUNLESD,
    instrux_COMUNLESS,
    instrux_COMUNLTPD,
    instrux_COMUNLTPS,
    instrux_COMUNLTSD,
    instrux_COMUNLTSS,
    instrux_COMUNORDPD,
    instrux_COMUNORDPS,
    instrux_COMUNORDSD,
    instrux_COMUNORDSS,
    instrux_CPUID,
    instrux_CPU_READ,
    instrux_CPU_WRITE,
    instrux_CQO,
    instrux_CRC32,
    instrux_CVTDQ2PD,
    instrux_CVTDQ2PS,
    instrux_CVTPD2DQ,
    instrux_CVTPD2PI,
    instrux_CVTPD2PS,
    instrux_CVTPH2PS,
    instrux_CVTPI2PD,
    instrux_CVTPI2PS,
    instrux_CVTPS2DQ,
    instrux_CVTPS2PD,
    instrux_CVTPS2PH,
    instrux_CVTPS2PI,
    instrux_CVTSD2SI,
    instrux_CVTSD2SS,
    instrux_CVTSI2SD,
    instrux_CVTSI2SS,
    instrux_CVTSS2SD,
    instrux_CVTSS2SI,
    instrux_CVTTPD2DQ,
    instrux_CVTTPD2PI,
    instrux_CVTTPS2DQ,
    instrux_CVTTPS2PI,
    instrux_CVTTSD2SI,
    instrux_CVTTSS2SI,
    instrux_CWD,
    instrux_CWDE,
    instrux_DAA,
    instrux_DAS,
    instrux_DB,
    instrux_DD,
    instrux_DEC,
    instrux_DIV,
    instrux_DIVPD,
    instrux_DIVPS,
    instrux_DIVSD,
    instrux_DIVSS,
    instrux_DMINT,
    instrux_DO,
    instrux_DPPD,
    instrux_DPPS,
    instrux_DQ,
    instrux_DT,
    instrux_DW,
    instrux_DY,
    instrux_EMMS,
    instrux_ENTER,
    instrux_EQU,
    instrux_EXTRACTPS,
    instrux_EXTRQ,
    instrux_F2XM1,
    instrux_FABS,
    instrux_FADD,
    instrux_FADDP,
    instrux_FBLD,
    instrux_FBSTP,
    instrux_FCHS,
    instrux_FCLEX,
    instrux_FCMOVB,
    instrux_FCMOVBE,
    instrux_FCMOVE,
    instrux_FCMOVNB,
    instrux_FCMOVNBE,
    instrux_FCMOVNE,
    instrux_FCMOVNU,
    instrux_FCMOVU,
    instrux_FCOM,
    instrux_FCOMI,
    instrux_FCOMIP,
    instrux_FCOMP,
    instrux_FCOMPP,
    instrux_FCOS,
    instrux_FDECSTP,
    instrux_FDISI,
    instrux_FDIV,
    instrux_FDIVP,
    instrux_FDIVR,
    instrux_FDIVRP,
    instrux_FEMMS,
    instrux_FENI,
    instrux_FFREE,
    instrux_FFREEP,
    instrux_FIADD,
    instrux_FICOM,
    instrux_FICOMP,
    instrux_FIDIV,
    instrux_FIDIVR,
    instrux_FILD,
    instrux_FIMUL,
    instrux_FINCSTP,
    instrux_FINIT,
    instrux_FIST,
    instrux_FISTP,
    instrux_FISTTP,
    instrux_FISUB,
    instrux_FISUBR,
    instrux_FLD,
    instrux_FLD1,
    instrux_FLDCW,
    instrux_FLDENV,
    instrux_FLDL2E,
    instrux_FLDL2T,
    instrux_FLDLG2,
    instrux_FLDLN2,
    instrux_FLDPI,
    instrux_FLDZ,
    instrux_FMADDPD,
    instrux_FMADDPS,
    instrux_FMADDSD,
    instrux_FMADDSS,
    instrux_FMSUBPD,
    instrux_FMSUBPS,
    instrux_FMSUBSD,
    instrux_FMSUBSS,
    instrux_FMUL,
    instrux_FMULP,
    instrux_FNCLEX,
    instrux_FNDISI,
    instrux_FNENI,
    instrux_FNINIT,
    instrux_FNMADDPD,
    instrux_FNMADDPS,
    instrux_FNMADDSD,
    instrux_FNMADDSS,
    instrux_FNMSUBPD,
    instrux_FNMSUBPS,
    instrux_FNMSUBSD,
    instrux_FNMSUBSS,
    instrux_FNOP,
    instrux_FNSAVE,
    instrux_FNSTCW,
    instrux_FNSTENV,
    instrux_FNSTSW,
    instrux_FPATAN,
    instrux_FPREM,
    instrux_FPREM1,
    instrux_FPTAN,
    instrux_FRCZPD,
    instrux_FRCZPS,
    instrux_FRCZSD,
    instrux_FRCZSS,
    instrux_FRNDINT,
    instrux_FRSTOR,
    instrux_FSAVE,
    instrux_FSCALE,
    instrux_FSETPM,
    instrux_FSIN,
    instrux_FSINCOS,
    instrux_FSQRT,
    instrux_FST,
    instrux_FSTCW,
    instrux_FSTENV,
    instrux_FSTP,
    instrux_FSTSW,
    instrux_FSUB,
    instrux_FSUBP,
    instrux_FSUBR,
    instrux_FSUBRP,
    instrux_FTST,
    instrux_FUCOM,
    instrux_FUCOMI,
    instrux_FUCOMIP,
    instrux_FUCOMP,
    instrux_FUCOMPP,
    instrux_FWAIT,
    instrux_FXAM,
    instrux_FXCH,
    instrux_FXRSTOR,
    instrux_FXSAVE,
    instrux_FXTRACT,
    instrux_FYL2X,
    instrux_FYL2XP1,
    instrux_GETSEC,
    instrux_HADDPD,
    instrux_HADDPS,
    instrux_HINT_NOP0,
    instrux_HINT_NOP1,
    instrux_HINT_NOP10,
    instrux_HINT_NOP11,
    instrux_HINT_NOP12,
    instrux_HINT_NOP13,
    instrux_HINT_NOP14,
    instrux_HINT_NOP15,
    instrux_HINT_NOP16,
    instrux_HINT_NOP17,
    instrux_HINT_NOP18,
    instrux_HINT_NOP19,
    instrux_HINT_NOP2,
    instrux_HINT_NOP20,
    instrux_HINT_NOP21,
    instrux_HINT_NOP22,
    instrux_HINT_NOP23,
    instrux_HINT_NOP24,
    instrux_HINT_NOP25,
    instrux_HINT_NOP26,
    instrux_HINT_NOP27,
    instrux_HINT_NOP28,
    instrux_HINT_NOP29,
    instrux_HINT_NOP3,
    instrux_HINT_NOP30,
    instrux_HINT_NOP31,
    instrux_HINT_NOP32,
    instrux_HINT_NOP33,
    instrux_HINT_NOP34,
    instrux_HINT_NOP35,
    instrux_HINT_NOP36,
    instrux_HINT_NOP37,
    instrux_HINT_NOP38,
    instrux_HINT_NOP39,
    instrux_HINT_NOP4,
    instrux_HINT_NOP40,
    instrux_HINT_NOP41,
    instrux_HINT_NOP42,
    instrux_HINT_NOP43,
    instrux_HINT_NOP44,
    instrux_HINT_NOP45,
    instrux_HINT_NOP46,
    instrux_HINT_NOP47,
    instrux_HINT_NOP48,
    instrux_HINT_NOP49,
    instrux_HINT_NOP5,
    instrux_HINT_NOP50,
    instrux_HINT_NOP51,
    instrux_HINT_NOP52,
    instrux_HINT_NOP53,
    instrux_HINT_NOP54,
    instrux_HINT_NOP55,
    instrux_HINT_NOP56,
    instrux_HINT_NOP57,
    instrux_HINT_NOP58,
    instrux_HINT_NOP59,
    instrux_HINT_NOP6,
    instrux_HINT_NOP60,
    instrux_HINT_NOP61,
    instrux_HINT_NOP62,
    instrux_HINT_NOP63,
    instrux_HINT_NOP7,
    instrux_HINT_NOP8,
    instrux_HINT_NOP9,
    instrux_HLT,
    instrux_HSUBPD,
    instrux_HSUBPS,
    instrux_IBTS,
    instrux_ICEBP,
    instrux_IDIV,
    instrux_IMUL,
    instrux_IN,
    instrux_INC,
    instrux_INCBIN,
    instrux_INSB,
    instrux_INSD,
    instrux_INSERTPS,
    instrux_INSERTQ,
    instrux_INSW,
    instrux_INT,
    instrux_INT01,
    instrux_INT03,
    instrux_INT1,
    instrux_INT3,
    instrux_INTO,
    instrux_INVD,
    instrux_INVEPT,
    instrux_INVLPG,
    instrux_INVLPGA,
    instrux_INVVPID,
    instrux_IRET,
    instrux_IRETD,
    instrux_IRETQ,
    instrux_IRETW,
    instrux_JCXZ,
    instrux_JECXZ,
    instrux_JMP,
    instrux_JMPE,
    instrux_JRCXZ,
    instrux_LAHF,
    instrux_LAR,
    instrux_LDDQU,
    instrux_LDMXCSR,
    instrux_LDS,
    instrux_LEA,
    instrux_LEAVE,
    instrux_LES,
    instrux_LFENCE,
    instrux_LFS,
    instrux_LGDT,
    instrux_LGS,
    instrux_LIDT,
    instrux_LLDT,
    instrux_LMSW,
    instrux_LOADALL,
    instrux_LOADALL286,
    instrux_LODSB,
    instrux_LODSD,
    instrux_LODSQ,
    instrux_LODSW,
    instrux_LOOP,
    instrux_LOOPE,
    instrux_LOOPNE,
    instrux_LOOPNZ,
    instrux_LOOPZ,
    instrux_LSL,
    instrux_LSS,
    instrux_LTR,
    instrux_LZCNT,
    instrux_MASKMOVDQU,
    instrux_MASKMOVQ,
    instrux_MAXPD,
    instrux_MAXPS,
    instrux_MAXSD,
    instrux_MAXSS,
    instrux_MFENCE,
    instrux_MINPD,
    instrux_MINPS,
    instrux_MINSD,
    instrux_MINSS,
    instrux_MONITOR,
    instrux_MONTMUL,
    instrux_MOV,
    instrux_MOVAPD,
    instrux_MOVAPS,
    instrux_MOVBE,
    instrux_MOVD,
    instrux_MOVDDUP,
    instrux_MOVDQ2Q,
    instrux_MOVDQA,
    instrux_MOVDQU,
    instrux_MOVHLPS,
    instrux_MOVHPD,
    instrux_MOVHPS,
    instrux_MOVLHPS,
    instrux_MOVLPD,
    instrux_MOVLPS,
    instrux_MOVMSKPD,
    instrux_MOVMSKPS,
    instrux_MOVNTDQ,
    instrux_MOVNTDQA,
    instrux_MOVNTI,
    instrux_MOVNTPD,
    instrux_MOVNTPS,
    instrux_MOVNTQ,
    instrux_MOVNTSD,
    instrux_MOVNTSS,
    instrux_MOVQ,
    instrux_MOVQ2DQ,
    instrux_MOVSB,
    instrux_MOVSD,
    instrux_MOVSHDUP,
    instrux_MOVSLDUP,
    instrux_MOVSQ,
    instrux_MOVSS,
    instrux_MOVSW,
    instrux_MOVSX,
    instrux_MOVSXD,
    instrux_MOVUPD,
    instrux_MOVUPS,
    instrux_MOVZX,
    instrux_MPSADBW,
    instrux_MUL,
    instrux_MULPD,
    instrux_MULPS,
    instrux_MULSD,
    instrux_MULSS,
    instrux_MWAIT,
    instrux_NEG,
    instrux_NOP,
    instrux_NOT,
    instrux_OR,
    instrux_ORPD,
    instrux_ORPS,
    instrux_OUT,
    instrux_OUTSB,
    instrux_OUTSD,
    instrux_OUTSW,
    instrux_PABSB,
    instrux_PABSD,
    instrux_PABSW,
    instrux_PACKSSDW,
    instrux_PACKSSWB,
    instrux_PACKUSDW,
    instrux_PACKUSWB,
    instrux_PADDB,
    instrux_PADDD,
    instrux_PADDQ,
    instrux_PADDSB,
    instrux_PADDSIW,
    instrux_PADDSW,
    instrux_PADDUSB,
    instrux_PADDUSW,
    instrux_PADDW,
    instrux_PALIGNR,
    instrux_PAND,
    instrux_PANDN,
    instrux_PAUSE,
    instrux_PAVEB,
    instrux_PAVGB,
    instrux_PAVGUSB,
    instrux_PAVGW,
    instrux_PBLENDVB,
    instrux_PBLENDW,
    instrux_PCLMULHQHQDQ,
    instrux_PCLMULHQLQDQ,
    instrux_PCLMULLQHQDQ,
    instrux_PCLMULLQLQDQ,
    instrux_PCLMULQDQ,
    instrux_PCMOV,
    instrux_PCMPEQB,
    instrux_PCMPEQD,
    instrux_PCMPEQQ,
    instrux_PCMPEQW,
    instrux_PCMPESTRI,
    instrux_PCMPESTRM,
    instrux_PCMPGTB,
    instrux_PCMPGTD,
    instrux_PCMPGTQ,
    instrux_PCMPGTW,
    instrux_PCMPISTRI,
    instrux_PCMPISTRM,
    instrux_PCOMB,
    instrux_PCOMD,
    instrux_PCOMEQB,
    instrux_PCOMEQD,
    instrux_PCOMEQQ,
    instrux_PCOMEQUB,
    instrux_PCOMEQUD,
    instrux_PCOMEQUQ,
    instrux_PCOMEQUW,
    instrux_PCOMEQW,
    instrux_PCOMFALSEB,
    instrux_PCOMFALSED,
    instrux_PCOMFALSEQ,
    instrux_PCOMFALSEUB,
    instrux_PCOMFALSEUD,
    instrux_PCOMFALSEUQ,
    instrux_PCOMFALSEUW,
    instrux_PCOMFALSEW,
    instrux_PCOMGEB,
    instrux_PCOMGED,
    instrux_PCOMGEQ,
    instrux_PCOMGEUB,
    instrux_PCOMGEUD,
    instrux_PCOMGEUQ,
    instrux_PCOMGEUW,
    instrux_PCOMGEW,
    instrux_PCOMGTB,
    instrux_PCOMGTD,
    instrux_PCOMGTQ,
    instrux_PCOMGTUB,
    instrux_PCOMGTUD,
    instrux_PCOMGTUQ,
    instrux_PCOMGTUW,
    instrux_PCOMGTW,
    instrux_PCOMLEB,
    instrux_PCOMLED,
    instrux_PCOMLEQ,
    instrux_PCOMLEUB,
    instrux_PCOMLEUD,
    instrux_PCOMLEUQ,
    instrux_PCOMLEUW,
    instrux_PCOMLEW,
    instrux_PCOMLTB,
    instrux_PCOMLTD,
    instrux_PCOMLTQ,
    instrux_PCOMLTUB,
    instrux_PCOMLTUD,
    instrux_PCOMLTUQ,
    instrux_PCOMLTUW,
    instrux_PCOMLTW,
    instrux_PCOMNEQB,
    instrux_PCOMNEQD,
    instrux_PCOMNEQQ,
    instrux_PCOMNEQUB,
    instrux_PCOMNEQUD,
    instrux_PCOMNEQUQ,
    instrux_PCOMNEQUW,
    instrux_PCOMNEQW,
    instrux_PCOMQ,
    instrux_PCOMTRUEB,
    instrux_PCOMTRUED,
    instrux_PCOMTRUEQ,
    instrux_PCOMTRUEUB,
    instrux_PCOMTRUEUD,
    instrux_PCOMTRUEUQ,
    instrux_PCOMTRUEUW,
    instrux_PCOMTRUEW,
    instrux_PCOMUB,
    instrux_PCOMUD,
    instrux_PCOMUQ,
    instrux_PCOMUW,
    instrux_PCOMW,
    instrux_PDISTIB,
    instrux_PERMPD,
    instrux_PERMPS,
    instrux_PEXTRB,
    instrux_PEXTRD,
    instrux_PEXTRQ,
    instrux_PEXTRW,
    instrux_PF2ID,
    instrux_PF2IW,
    instrux_PFACC,
    instrux_PFADD,
    instrux_PFCMPEQ,
    instrux_PFCMPGE,
    instrux_PFCMPGT,
    instrux_PFMAX,
    instrux_PFMIN,
    instrux_PFMUL,
    instrux_PFNACC,
    instrux_PFPNACC,
    instrux_PFRCP,
    instrux_PFRCPIT1,
    instrux_PFRCPIT2,
    instrux_PFRCPV,
    instrux_PFRSQIT1,
    instrux_PFRSQRT,
    instrux_PFRSQRTV,
    instrux_PFSUB,
    instrux_PFSUBR,
    instrux_PHADDBD,
    instrux_PHADDBQ,
    instrux_PHADDBW,
    instrux_PHADDD,
    instrux_PHADDDQ,
    instrux_PHADDSW,
    instrux_PHADDUBD,
    instrux_PHADDUBQ,
    instrux_PHADDUBW,
    instrux_PHADDUDQ,
    instrux_PHADDUWD,
    instrux_PHADDUWQ,
    instrux_PHADDW,
    instrux_PHADDWD,
    instrux_PHADDWQ,
    instrux_PHMINPOSUW,
    instrux_PHSUBBW,
    instrux_PHSUBD,
    instrux_PHSUBDQ,
    instrux_PHSUBSW,
    instrux_PHSUBW,
    instrux_PHSUBWD,
    instrux_PI2FD,
    instrux_PI2FW,
    instrux_PINSRB,
    instrux_PINSRD,
    instrux_PINSRQ,
    instrux_PINSRW,
    instrux_PMACHRIW,
    instrux_PMACSDD,
    instrux_PMACSDQH,
    instrux_PMACSDQL,
    instrux_PMACSSDD,
    instrux_PMACSSDQH,
    instrux_PMACSSDQL,
    instrux_PMACSSWD,
    instrux_PMACSSWW,
    instrux_PMACSWD,
    instrux_PMACSWW,
    instrux_PMADCSSWD,
    instrux_PMADCSWD,
    instrux_PMADDUBSW,
    instrux_PMADDWD,
    instrux_PMAGW,
    instrux_PMAXSB,
    instrux_PMAXSD,
    instrux_PMAXSW,
    instrux_PMAXUB,
    instrux_PMAXUD,
    instrux_PMAXUW,
    instrux_PMINSB,
    instrux_PMINSD,
    instrux_PMINSW,
    instrux_PMINUB,
    instrux_PMINUD,
    instrux_PMINUW,
    instrux_PMOVMSKB,
    instrux_PMOVSXBD,
    instrux_PMOVSXBQ,
    instrux_PMOVSXBW,
    instrux_PMOVSXDQ,
    instrux_PMOVSXWD,
    instrux_PMOVSXWQ,
    instrux_PMOVZXBD,
    instrux_PMOVZXBQ,
    instrux_PMOVZXBW,
    instrux_PMOVZXDQ,
    instrux_PMOVZXWD,
    instrux_PMOVZXWQ,
    instrux_PMULDQ,
    instrux_PMULHRIW,
    instrux_PMULHRSW,
    instrux_PMULHRWA,
    instrux_PMULHRWC,
    instrux_PMULHUW,
    instrux_PMULHW,
    instrux_PMULLD,
    instrux_PMULLW,
    instrux_PMULUDQ,
    instrux_PMVGEZB,
    instrux_PMVLZB,
    instrux_PMVNZB,
    instrux_PMVZB,
    instrux_POP,
    instrux_POPA,
    instrux_POPAD,
    instrux_POPAW,
    instrux_POPCNT,
    instrux_POPF,
    instrux_POPFD,
    instrux_POPFQ,
    instrux_POPFW,
    instrux_POR,
    instrux_PPERM,
    instrux_PREFETCH,
    instrux_PREFETCHNTA,
    instrux_PREFETCHT0,
    instrux_PREFETCHT1,
    instrux_PREFETCHT2,
    instrux_PREFETCHW,
    instrux_PROTB,
    instrux_PROTD,
    instrux_PROTQ,
    instrux_PROTW,
    instrux_PSADBW,
    instrux_PSHAB,
    instrux_PSHAD,
    instrux_PSHAQ,
    instrux_PSHAW,
    instrux_PSHLB,
    instrux_PSHLD,
    instrux_PSHLQ,
    instrux_PSHLW,
    instrux_PSHUFB,
    instrux_PSHUFD,
    instrux_PSHUFHW,
    instrux_PSHUFLW,
    instrux_PSHUFW,
    instrux_PSIGNB,
    instrux_PSIGND,
    instrux_PSIGNW,
    instrux_PSLLD,
    instrux_PSLLDQ,
    instrux_PSLLQ,
    instrux_PSLLW,
    instrux_PSRAD,
    instrux_PSRAW,
    instrux_PSRLD,
    instrux_PSRLDQ,
    instrux_PSRLQ,
    instrux_PSRLW,
    instrux_PSUBB,
    instrux_PSUBD,
    instrux_PSUBQ,
    instrux_PSUBSB,
    instrux_PSUBSIW,
    instrux_PSUBSW,
    instrux_PSUBUSB,
    instrux_PSUBUSW,
    instrux_PSUBW,
    instrux_PSWAPD,
    instrux_PTEST,
    instrux_PUNPCKHBW,
    instrux_PUNPCKHDQ,
    instrux_PUNPCKHQDQ,
    instrux_PUNPCKHWD,
    instrux_PUNPCKLBW,
    instrux_PUNPCKLDQ,
    instrux_PUNPCKLQDQ,
    instrux_PUNPCKLWD,
    instrux_PUSH,
    instrux_PUSHA,
    instrux_PUSHAD,
    instrux_PUSHAW,
    instrux_PUSHF,
    instrux_PUSHFD,
    instrux_PUSHFQ,
    instrux_PUSHFW,
    instrux_PXOR,
    instrux_RCL,
    instrux_RCPPS,
    instrux_RCPSS,
    instrux_RCR,
    instrux_RDM,
    instrux_RDMSR,
    instrux_RDPMC,
    instrux_RDSHR,
    instrux_RDTSC,
    instrux_RDTSCP,
    instrux_RESB,
    instrux_RESD,
    instrux_RESO,
    instrux_RESQ,
    instrux_REST,
    instrux_RESW,
    instrux_RESY,
    instrux_RET,
    instrux_RETF,
    instrux_RETN,
    instrux_ROL,
    instrux_ROR,
    instrux_ROUNDPD,
    instrux_ROUNDPS,
    instrux_ROUNDSD,
    instrux_ROUNDSS,
    instrux_RSDC,
    instrux_RSLDT,
    instrux_RSM,
    instrux_RSQRTPS,
    instrux_RSQRTSS,
    instrux_RSTS,
    instrux_SAHF,
    instrux_SAL,
    instrux_SALC,
    instrux_SAR,
    instrux_SBB,
    instrux_SCASB,
    instrux_SCASD,
    instrux_SCASQ,
    instrux_SCASW,
    instrux_SFENCE,
    instrux_SGDT,
    instrux_SHL,
    instrux_SHLD,
    instrux_SHR,
    instrux_SHRD,
    instrux_SHUFPD,
    instrux_SHUFPS,
    instrux_SIDT,
    instrux_SKINIT,
    instrux_SLDT,
    instrux_SMI,
    instrux_SMINT,
    instrux_SMINTOLD,
    instrux_SMSW,
    instrux_SQRTPD,
    instrux_SQRTPS,
    instrux_SQRTSD,
    instrux_SQRTSS,
    instrux_STC,
    instrux_STD,
    instrux_STGI,
    instrux_STI,
    instrux_STMXCSR,
    instrux_STOSB,
    instrux_STOSD,
    instrux_STOSQ,
    instrux_STOSW,
    instrux_STR,
    instrux_SUB,
    instrux_SUBPD,
    instrux_SUBPS,
    instrux_SUBSD,
    instrux_SUBSS,
    instrux_SVDC,
    instrux_SVLDT,
    instrux_SVTS,
    instrux_SWAPGS,
    instrux_SYSCALL,
    instrux_SYSENTER,
    instrux_SYSEXIT,
    instrux_SYSRET,
    instrux_TEST,
    instrux_UCOMISD,
    instrux_UCOMISS,
    instrux_UD0,
    instrux_UD1,
    instrux_UD2,
    instrux_UD2A,
    instrux_UD2B,
    instrux_UMOV,
    instrux_UNPCKHPD,
    instrux_UNPCKHPS,
    instrux_UNPCKLPD,
    instrux_UNPCKLPS,
    instrux_VADDPD,
    instrux_VADDPS,
    instrux_VADDSD,
    instrux_VADDSS,
    instrux_VADDSUBPD,
    instrux_VADDSUBPS,
    instrux_VAESDEC,
    instrux_VAESDECLAST,
    instrux_VAESENC,
    instrux_VAESENCLAST,
    instrux_VAESIMC,
    instrux_VAESKEYGENASSIST,
    instrux_VANDNPD,
    instrux_VANDNPS,
    instrux_VANDPD,
    instrux_VANDPS,
    instrux_VBLENDPD,
    instrux_VBLENDPS,
    instrux_VBLENDVPD,
    instrux_VBLENDVPS,
    instrux_VBROADCASTF128,
    instrux_VBROADCASTSD,
    instrux_VBROADCASTSS,
    instrux_VCMPEQPD,
    instrux_VCMPEQPS,
    instrux_VCMPEQSD,
    instrux_VCMPEQSS,
    instrux_VCMPEQ_OSPD,
    instrux_VCMPEQ_OSPS,
    instrux_VCMPEQ_OSSD,
    instrux_VCMPEQ_OSSS,
    instrux_VCMPEQ_UQPD,
    instrux_VCMPEQ_UQPS,
    instrux_VCMPEQ_UQSD,
    instrux_VCMPEQ_UQSS,
    instrux_VCMPEQ_USPD,
    instrux_VCMPEQ_USPS,
    instrux_VCMPEQ_USSD,
    instrux_VCMPEQ_USSS,
    instrux_VCMPFALSEPD,
    instrux_VCMPFALSEPS,
    instrux_VCMPFALSESD,
    instrux_VCMPFALSESS,
    instrux_VCMPFALSE_OSPD,
    instrux_VCMPFALSE_OSPS,
    instrux_VCMPFALSE_OSSD,
    instrux_VCMPFALSE_OSSS,
    instrux_VCMPGEPD,
    instrux_VCMPGEPS,
    instrux_VCMPGESD,
    instrux_VCMPGESS,
    instrux_VCMPGE_OQPD,
    instrux_VCMPGE_OQPS,
    instrux_VCMPGE_OQSD,
    instrux_VCMPGE_OQSS,
    instrux_VCMPGTPD,
    instrux_VCMPGTPS,
    instrux_VCMPGTSD,
    instrux_VCMPGTSS,
    instrux_VCMPGT_OQPD,
    instrux_VCMPGT_OQPS,
    instrux_VCMPGT_OQSD,
    instrux_VCMPGT_OQSS,
    instrux_VCMPLEPD,
    instrux_VCMPLEPS,
    instrux_VCMPLESD,
    instrux_VCMPLESS,
    instrux_VCMPLE_OQPD,
    instrux_VCMPLE_OQPS,
    instrux_VCMPLE_OQSD,
    instrux_VCMPLE_OQSS,
    instrux_VCMPLTPD,
    instrux_VCMPLTPS,
    instrux_VCMPLTSD,
    instrux_VCMPLTSS,
    instrux_VCMPLT_OQPD,
    instrux_VCMPLT_OQPS,
    instrux_VCMPLT_OQSD,
    instrux_VCMPLT_OQSS,
    instrux_VCMPNEQPD,
    instrux_VCMPNEQPS,
    instrux_VCMPNEQSD,
    instrux_VCMPNEQSS,
    instrux_VCMPNEQ_OQPD,
    instrux_VCMPNEQ_OQPS,
    instrux_VCMPNEQ_OQSD,
    instrux_VCMPNEQ_OQSS,
    instrux_VCMPNEQ_OSPD,
    instrux_VCMPNEQ_OSPS,
    instrux_VCMPNEQ_OSSD,
    instrux_VCMPNEQ_OSSS,
    instrux_VCMPNEQ_USPD,
    instrux_VCMPNEQ_USPS,
    instrux_VCMPNEQ_USSD,
    instrux_VCMPNEQ_USSS,
    instrux_VCMPNGEPD,
    instrux_VCMPNGEPS,
    instrux_VCMPNGESD,
    instrux_VCMPNGESS,
    instrux_VCMPNGE_UQPD,
    instrux_VCMPNGE_UQPS,
    instrux_VCMPNGE_UQSD,
    instrux_VCMPNGE_UQSS,
    instrux_VCMPNGTPD,
    instrux_VCMPNGTPS,
    instrux_VCMPNGTSD,
    instrux_VCMPNGTSS,
    instrux_VCMPNGT_UQPD,
    instrux_VCMPNGT_UQPS,
    instrux_VCMPNGT_UQSD,
    instrux_VCMPNGT_UQSS,
    instrux_VCMPNLEPD,
    instrux_VCMPNLEPS,
    instrux_VCMPNLESD,
    instrux_VCMPNLESS,
    instrux_VCMPNLE_UQPD,
    instrux_VCMPNLE_UQPS,
    instrux_VCMPNLE_UQSD,
    instrux_VCMPNLE_UQSS,
    instrux_VCMPNLTPD,
    instrux_VCMPNLTPS,
    instrux_VCMPNLTSD,
    instrux_VCMPNLTSS,
    instrux_VCMPNLT_UQPD,
    instrux_VCMPNLT_UQPS,
    instrux_VCMPNLT_UQSD,
    instrux_VCMPNLT_UQSS,
    instrux_VCMPORDPD,
    instrux_VCMPORDPS,
    instrux_VCMPORDSD,
    instrux_VCMPORDSS,
    instrux_VCMPORD_SPD,
    instrux_VCMPORD_SPS,
    instrux_VCMPORD_SSD,
    instrux_VCMPORD_SSS,
    instrux_VCMPORS_SPD,
    instrux_VCMPORS_SPS,
    instrux_VCMPPD,
    instrux_VCMPPS,
    instrux_VCMPSD,
    instrux_VCMPSS,
    instrux_VCMPTRUEPD,
    instrux_VCMPTRUEPS,
    instrux_VCMPTRUESD,
    instrux_VCMPTRUESS,
    instrux_VCMPTRUE_USPD,
    instrux_VCMPTRUE_USPS,
    instrux_VCMPTRUE_USSD,
    instrux_VCMPTRUE_USSS,
    instrux_VCMPUNORDPD,
    instrux_VCMPUNORDPS,
    instrux_VCMPUNORDSD,
    instrux_VCMPUNORDSS,
    instrux_VCMPUNORD_SPD,
    instrux_VCMPUNORD_SPS,
    instrux_VCMPUNORD_SSD,
    instrux_VCMPUNORD_SSS,
    instrux_VCOMISD,
    instrux_VCOMISS,
    instrux_VCVTDQ2PD,
    instrux_VCVTDQ2PS,
    instrux_VCVTPD2DQ,
    instrux_VCVTPD2PS,
    instrux_VCVTPS2DQ,
    instrux_VCVTPS2PD,
    instrux_VCVTSD2SI,
    instrux_VCVTSD2SS,
    instrux_VCVTSI2SD,
    instrux_VCVTSI2SS,
    instrux_VCVTSS2SD,
    instrux_VCVTSS2SI,
    instrux_VCVTTPD2DQ,
    instrux_VCVTTPS2DQ,
    instrux_VCVTTSD2SI,
    instrux_VCVTTSS2SI,
    instrux_VDIVPD,
    instrux_VDIVPS,
    instrux_VDIVSD,
    instrux_VDIVSS,
    instrux_VDPPD,
    instrux_VDPPS,
    instrux_VERR,
    instrux_VERW,
    instrux_VEXTRACTF128,
    instrux_VEXTRACTPS,
    instrux_VFMADDPD,
    instrux_VFMADDPS,
    instrux_VFMADDSD,
    instrux_VFMADDSS,
    instrux_VFMADDSUBPD,
    instrux_VFMADDSUBPS,
    instrux_VFMSUBADDPD,
    instrux_VFMSUBADDPS,
    instrux_VFMSUBPD,
    instrux_VFMSUBPS,
    instrux_VFMSUBSD,
    instrux_VFMSUBSS,
    instrux_VFNMADDPD,
    instrux_VFNMADDPS,
    instrux_VFNMADDSD,
    instrux_VFNMADDSS,
    instrux_VFNMSUBPD,
    instrux_VFNMSUBPS,
    instrux_VFNMSUBSD,
    instrux_VFNMSUBSS,
    instrux_VHADDPD,
    instrux_VHADDPS,
    instrux_VHSUBPD,
    instrux_VHSUBPS,
    instrux_VINSERTF128,
    instrux_VINSERTPS,
    instrux_VLDDQU,
    instrux_VLDMXCSR,
    instrux_VLDQQU,
    instrux_VMASKMOVDQU,
    instrux_VMASKMOVPD,
    instrux_VMASKMOVPS,
    instrux_VMAXPD,
    instrux_VMAXPS,
    instrux_VMAXSD,
    instrux_VMAXSS,
    instrux_VMCALL,
    instrux_VMCLEAR,
    instrux_VMINPD,
    instrux_VMINPS,
    instrux_VMINSD,
    instrux_VMINSS,
    instrux_VMLAUNCH,
    instrux_VMLOAD,
    instrux_VMMCALL,
    instrux_VMOVAPD,
    instrux_VMOVAPS,
    instrux_VMOVD,
    instrux_VMOVDDUP,
    instrux_VMOVDQA,
    instrux_VMOVDQU,
    instrux_VMOVHLPS,
    instrux_VMOVHPD,
    instrux_VMOVHPS,
    instrux_VMOVLHPS,
    instrux_VMOVLPD,
    instrux_VMOVLPS,
    instrux_VMOVMSKPD,
    instrux_VMOVMSKPS,
    instrux_VMOVNTDQ,
    instrux_VMOVNTDQA,
    instrux_VMOVNTPD,
    instrux_VMOVNTPS,
    instrux_VMOVNTQQ,
    instrux_VMOVQ,
    instrux_VMOVQQA,
    instrux_VMOVQQU,
    instrux_VMOVSD,
    instrux_VMOVSHDUP,
    instrux_VMOVSLDUP,
    instrux_VMOVSS,
    instrux_VMOVUPD,
    instrux_VMOVUPS,
    instrux_VMPSADBW,
    instrux_VMPTRLD,
    instrux_VMPTRST,
    instrux_VMREAD,
    instrux_VMRESUME,
    instrux_VMRUN,
    instrux_VMSAVE,
    instrux_VMULPD,
    instrux_VMULPS,
    instrux_VMULSD,
    instrux_VMULSS,
    instrux_VMWRITE,
    instrux_VMXOFF,
    instrux_VMXON,
    instrux_VORPD,
    instrux_VORPS,
    instrux_VPABSB,
    instrux_VPABSD,
    instrux_VPABSW,
    instrux_VPACKSSDW,
    instrux_VPACKSSWB,
    instrux_VPACKUSDW,
    instrux_VPACKUSWB,
    instrux_VPADDB,
    instrux_VPADDD,
    instrux_VPADDQ,
    instrux_VPADDSB,
    instrux_VPADDSW,
    instrux_VPADDUSB,
    instrux_VPADDUSW,
    instrux_VPADDW,
    instrux_VPALIGNR,
    instrux_VPAND,
    instrux_VPANDN,
    instrux_VPAVGB,
    instrux_VPAVGW,
    instrux_VPBLENDVB,
    instrux_VPBLENDW,
    instrux_VPCMPEQB,
    instrux_VPCMPEQD,
    instrux_VPCMPEQQ,
    instrux_VPCMPEQW,
    instrux_VPCMPESTRI,
    instrux_VPCMPESTRM,
    instrux_VPCMPGTB,
    instrux_VPCMPGTD,
    instrux_VPCMPGTQ,
    instrux_VPCMPGTW,
    instrux_VPCMPISTRI,
    instrux_VPCMPISTRM,
    instrux_VPERM2F128,
    instrux_VPERMIL2PD,
    instrux_VPERMIL2PS,
    instrux_VPERMILMO2PD,
    instrux_VPERMILMO2PS,
    instrux_VPERMILMZ2PD,
    instrux_VPERMILMZ2PS,
    instrux_VPERMILPD,
    instrux_VPERMILPS,
    instrux_VPERMILTD2PD,
    instrux_VPERMILTD2PS,
    instrux_VPEXTRB,
    instrux_VPEXTRD,
    instrux_VPEXTRQ,
    instrux_VPEXTRW,
    instrux_VPHADDD,
    instrux_VPHADDSW,
    instrux_VPHADDW,
    instrux_VPHMINPOSUW,
    instrux_VPHSUBD,
    instrux_VPHSUBSW,
    instrux_VPHSUBW,
    instrux_VPINSRB,
    instrux_VPINSRD,
    instrux_VPINSRQ,
    instrux_VPINSRW,
    instrux_VPMADDUBSW,
    instrux_VPMADDWD,
    instrux_VPMAXSB,
    instrux_VPMAXSD,
    instrux_VPMAXSW,
    instrux_VPMAXUB,
    instrux_VPMAXUD,
    instrux_VPMAXUW,
    instrux_VPMINSB,
    instrux_VPMINSD,
    instrux_VPMINSW,
    instrux_VPMINUB,
    instrux_VPMINUD,
    instrux_VPMINUW,
    instrux_VPMOVMSKB,
    instrux_VPMOVSXBD,
    instrux_VPMOVSXBQ,
    instrux_VPMOVSXBW,
    instrux_VPMOVSXDQ,
    instrux_VPMOVSXWD,
    instrux_VPMOVSXWQ,
    instrux_VPMOVZXBD,
    instrux_VPMOVZXBQ,
    instrux_VPMOVZXBW,
    instrux_VPMOVZXDQ,
    instrux_VPMOVZXWD,
    instrux_VPMOVZXWQ,
    instrux_VPMULDQ,
    instrux_VPMULHRSW,
    instrux_VPMULHUW,
    instrux_VPMULHW,
    instrux_VPMULLD,
    instrux_VPMULLW,
    instrux_VPMULUDQ,
    instrux_VPOR,
    instrux_VPSADBW,
    instrux_VPSHUFB,
    instrux_VPSHUFD,
    instrux_VPSHUFHW,
    instrux_VPSHUFLW,
    instrux_VPSIGNB,
    instrux_VPSIGND,
    instrux_VPSIGNW,
    instrux_VPSLLD,
    instrux_VPSLLDQ,
    instrux_VPSLLQ,
    instrux_VPSLLW,
    instrux_VPSRAD,
    instrux_VPSRAW,
    instrux_VPSRLD,
    instrux_VPSRLDQ,
    instrux_VPSRLQ,
    instrux_VPSRLW,
    instrux_VPSUBB,
    instrux_VPSUBD,
    instrux_VPSUBQ,
    instrux_VPSUBSB,
    instrux_VPSUBSW,
    instrux_VPSUBUSB,
    instrux_VPSUBUSW,
    instrux_VPSUBW,
    instrux_VPTEST,
    instrux_VPUNPCKHBW,
    instrux_VPUNPCKHDQ,
    instrux_VPUNPCKHQDQ,
    instrux_VPUNPCKHWD,
    instrux_VPUNPCKLBW,
    instrux_VPUNPCKLDQ,
    instrux_VPUNPCKLQDQ,
    instrux_VPUNPCKLWD,
    instrux_VPXOR,
    instrux_VRCPPS,
    instrux_VRCPSS,
    instrux_VROUNDPD,
    instrux_VROUNDPS,
    instrux_VROUNDSD,
    instrux_VROUNDSS,
    instrux_VRSQRTPS,
    instrux_VRSQRTSS,
    instrux_VSHUFPD,
    instrux_VSHUFPS,
    instrux_VSQRTPD,
    instrux_VSQRTPS,
    instrux_VSQRTSD,
    instrux_VSQRTSS,
    instrux_VSTMXCSR,
    instrux_VSUBPD,
    instrux_VSUBPS,
    instrux_VSUBSD,
    instrux_VSUBSS,
    instrux_VTESTPD,
    instrux_VTESTPS,
    instrux_VUCOMISD,
    instrux_VUCOMISS,
    instrux_VUNPCKHPD,
    instrux_VUNPCKHPS,
    instrux_VUNPCKLPD,
    instrux_VUNPCKLPS,
    instrux_VXORPD,
    instrux_VXORPS,
    instrux_VZEROALL,
    instrux_VZEROUPPER,
    instrux_WAIT,
    instrux_WBINVD,
    instrux_WRMSR,
    instrux_WRSHR,
    instrux_XADD,
    instrux_XBTS,
    instrux_XCHG,
    instrux_XCRYPTCBC,
    instrux_XCRYPTCFB,
    instrux_XCRYPTCTR,
    instrux_XCRYPTECB,
    instrux_XCRYPTOFB,
    instrux_XGETBV,
    instrux_XLAT,
    instrux_XLATB,
    instrux_XOR,
    instrux_XORPD,
    instrux_XORPS,
    instrux_XRSTOR,
    instrux_XSAVE,
    instrux_XSETBV,
    instrux_XSHA1,
    instrux_XSHA256,
    instrux_XSTORE,
    instrux_CMOVcc,
    instrux_Jcc,
    instrux_SETcc,
};
